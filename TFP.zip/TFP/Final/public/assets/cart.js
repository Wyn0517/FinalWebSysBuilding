/* One cart controller shared by the POS view. Prices and stock are revalidated on the server. */
(function (scope) {
    'use strict';
    const MAX_LINES = 50;
    const MAX_QUANTITY = 2147483647;
    const MAX_TOTAL_CENTS = 9999999999;
    function priceToCents(value) {
        const match = /^(\d{1,8})(?:\.(\d{1,2}))?$/.exec(String(value));
        if (!match) throw new Error('This product has an invalid price. Ask an administrator to check it.');
        return Number(match[1]) * 100 + Number((match[2] || '').padEnd(2, '0'));
    }
    function productId(value) {
        const id = Number(value);
        if (!Number.isSafeInteger(id) || id < 1) throw new Error('This product is not available. Refresh the catalog and try again.');
        return id;
    }
    function matchesProductSearch(product, value) {
        const query = String(value ?? '').trim().toLocaleLowerCase();
        if (!query) return true;
        const identifier = /^#?(\d+)$/.exec(query);
        const matchesId = Boolean(identifier && Number(identifier[1]) === Number(product.id));
        // A leading # explicitly selects an ID. Bare numbers can also occur in names.
        if (query.startsWith('#')) return matchesId;
        return matchesId || String(product.name).toLocaleLowerCase().includes(query);
    }
    function isSearchShortcut(event, dialogOpen = false) {
        return event.key === 'F2' && !event.defaultPrevented && !event.isComposing && !dialogOpen
            && !event.ctrlKey && !event.altKey && !event.metaKey && !event.shiftKey;
    }
    class CartModel {
        constructor(products = []) {
            this.products = new Map();
            this.quantities = new Map();
            for (const value of products) {
                const id = productId(value.id);
                const stock = Number(value.stock);
                if (!Number.isInteger(stock) || stock < 0 || stock > MAX_QUANTITY) throw new Error('A product has an invalid stock quantity.');
                this.products.set(id, Object.freeze({ id, name: String(value.name), unitCents: priceToCents(value.price), stock, image: String(value.image || '') }));
            }
        }
        quantity(id) { return this.quantities.get(productId(id)) || 0; }
        setQuantity(value, quantity) {
            const id = productId(value);
            const product = this.products.get(id);
            if (!product) throw new Error('This product is no longer in the catalog. Refresh the page before checking out.');
            if (!Number.isInteger(quantity) || quantity < 0 || quantity > MAX_QUANTITY) throw new Error('Enter a valid whole-number quantity.');
            if (quantity === 0) { this.quantities.delete(id); return; }
            if (quantity > product.stock) throw new Error(`Only ${product.stock} units of ${product.name} are currently available.`);
            if (!this.quantities.has(id) && this.quantities.size >= MAX_LINES) throw new Error(`An order can contain up to ${MAX_LINES} different products.`);
            const previous = this.quantities.get(id);
            this.quantities.set(id, quantity);
            try { this.summary(); } catch (error) {
                if (previous === undefined) this.quantities.delete(id); else this.quantities.set(id, previous);
                throw error;
            }
        }
        add(id) { this.setQuantity(id, this.quantity(id) + 1); }
        remove(id) { this.quantities.delete(productId(id)); }
        clear() { this.quantities.clear(); }
        lines() {
            return Array.from(this.quantities, ([id, quantity]) => ({ product: this.products.get(id), quantity, subtotalCents: this.products.get(id).unitCents * quantity }));
        }
        summary() {
            let totalCents = 0, units = 0;
            for (const [id, quantity] of this.quantities) {
                const lineCents = this.products.get(id).unitCents * quantity;
                totalCents += lineCents; units += quantity;
                if (!Number.isSafeInteger(totalCents) || totalCents > MAX_TOTAL_CENTS) throw new Error('The order total must not exceed ₱99,999,999.99. Reduce the order before checking out.');
                if (units > MAX_QUANTITY) throw new Error('The order contains too many units. Reduce the quantities before checking out.');
            }
            return { totalCents, units, lineCount: this.quantities.size };
        }
        serialize() { return Array.from(this.quantities, ([product_id, quantity]) => ({ product_id, quantity })); }
        restore(values) {
            const notices = [];
            if (!Array.isArray(values)) return ['The previous order could not be restored. Please add the products again.'];
            for (const value of values) {
                try {
                    if (!value || !Number.isInteger(Number(value.quantity)) || Number(value.quantity) < 1) throw new Error('An invalid item was removed from the previous order.');
                    const id = productId(value.product_id), product = this.products.get(id);
                    if (!product || product.stock === 0) throw new Error('An unavailable item was removed from the previous order.');
                    const requested = this.quantity(id) + Number(value.quantity);
                    const quantity = Math.min(requested, product.stock);
                    if (requested > product.stock) notices.push(`${product.name} was adjusted to its current stock of ${product.stock}. Review the order before checking out.`);
                    this.setQuantity(id, quantity);
                } catch (error) { notices.push(error.message); }
            }
            return notices;
        }
    }
    // The persistent live region announces actions; the visual copy is hidden
    // from assistive technology. Replaced messages cancel their expiry.
    function createCartFeedback(visible, announcement, scheduler) {
        let timer = null;
        const clear = () => {
            if (timer !== null) scheduler.clearTimeout(timer);
            timer = null;
            if (visible) { visible.hidden = true; visible.textContent = ''; }
            if (announcement && announcement !== visible) announcement.textContent = '';
        };
        const show = (message, persistent = false) => {
            clear();
            if (!message) return;
            // Update the always-present live region rather than relying on a
            // newly unhidden element to announce its initial populated content.
            if (announcement) announcement.textContent = message;
            if (visible) {
                visible.textContent = message;
                visible.hidden = false;
                if (!persistent) timer = scheduler.setTimeout(clear, 6000);
            }
        };
        return { show, clear };
    }
    const formatCents = (value) => new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(value / 100);
    if (typeof module !== 'undefined' && module.exports) module.exports = { CartModel, priceToCents, matchesProductSearch, isSearchShortcut, createCartFeedback, MAX_LINES, MAX_QUANTITY, MAX_TOTAL_CENTS };
    if (typeof document === 'undefined') return;
    const root = document.querySelector('[data-pos]');
    if (!root) return;
    const find = selector => root.querySelector(selector);
    const nodes = {
        search: find('[data-catalog-search]'), clearSearch: find('[data-clear-product-search]'), count: find('[data-catalog-count]'), catalogEmpty: find('[data-catalog-empty]'),
        lines: find('[data-cart-lines]'), empty: find('[data-cart-empty]'), clear: find('[data-clear-cart]'),
        template: find('[data-cart-line-template]'), error: find('[data-cart-error]'), feedback: find('[data-cart-feedback]'), announcement: find('[data-cart-announcement]'),
        form: find('[data-checkout-form]'), payload: find('[data-cart-payload]'), customer: find('[data-cart-customer]'),
        checkout: find('[data-checkout-button]'), dialog: find('[data-checkout-dialog]'), confirm: find('[data-review-confirm]')
    };
    const feedback = createCartFeedback(nodes.feedback, nodes.announcement, scope);
    let cart, pending = false, filter = 'all';
    const tiles = Array.from(root.querySelectorAll('[data-product-tile]'));
    const filters = Array.from(root.querySelectorAll('[data-stock-filter]'));
    const feedbackTimers = new WeakMap();
    const showFeedback = (element, className) => {
        if (!element) return;
        scope.clearTimeout(feedbackTimers.get(element));
        element.classList.add(className);
        feedbackTimers.set(element, scope.setTimeout(() => {
            element.classList.remove(className);
            feedbackTimers.delete(element);
        }, 180));
    };
    const showError = (message, focus = false) => {
        if (message) feedback.clear();
        nodes.error.textContent = message; nodes.error.hidden = !message;
        if (message && focus) nodes.error.focus({ preventScroll: false });
    };
    try { cart = new CartModel(JSON.parse(find('[data-pos-catalog]').textContent)); }
    catch (_) { showError('The catalog could not be loaded. Refresh this page, or ask an administrator for help.'); return; }
    const put = (selector, value) => { const target = find(selector); if (target) target.textContent = value; };
    const updateCatalog = () => {
        let visible = 0;
        for (const tile of tiles) {
            const product = cart.products.get(Number(tile.dataset.productId));
            const matches = product && matchesProductSearch(product, nodes.search.value)
                && (filter === 'all' || (filter === 'available' && product.stock > 0) || (filter === 'low' && product.stock <= 5));
            tile.hidden = !matches; if (matches) visible++;
        }
        nodes.count.textContent = `${visible} ${visible === 1 ? 'product' : 'products'}`;
        if (nodes.catalogEmpty) nodes.catalogEmpty.hidden = visible > 0;
        if (nodes.clearSearch) nodes.clearSearch.hidden = nodes.search.value.length === 0;
        filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.stockFilter === filter)));
    };
    const updateTotals = () => {
        const summary = cart.summary();
        nodes.empty.hidden = summary.lineCount > 0;
        nodes.clear.disabled = summary.lineCount === 0 || pending;
        nodes.checkout.disabled = summary.lineCount === 0 || pending;
        nodes.customer.disabled = pending;
        nodes.payload.value = JSON.stringify(cart.serialize());
        put('[data-cart-line-count]', String(summary.lineCount));
        put('[data-cart-units-label]', `(${summary.units} ${summary.units === 1 ? 'item' : 'items'})`);
        put('[data-cart-subtotal]', formatCents(summary.totalCents));
        put('[data-cart-total]', formatCents(summary.totalCents));
        put('[data-mobile-cart-count]', String(summary.units));
        put('[data-mobile-cart-total]', formatCents(summary.totalCents));
        for (const tile of tiles) {
            const id = Number(tile.dataset.productId), product = cart.products.get(id), quantity = cart.quantity(id);
            const button = tile.querySelector('[data-add-product]');
            tile.classList.toggle('is-in-cart', quantity > 0);
            button.disabled = pending || quantity >= product.stock;
            button.querySelector('[data-add-label]').textContent = product.stock === 0 ? 'Unavailable' : quantity >= product.stock ? 'All stock added' : quantity > 0 ? 'Add another' : 'Add to order';
            const count = button.querySelector('[data-product-in-cart]');
            count.hidden = quantity === 0; count.textContent = `×${quantity}`;
            button.setAttribute('aria-label', `${product.name}: ${quantity} in order. ${quantity >= product.stock ? 'No more stock available.' : 'Add one to order.'}`);
        }
    };
    const render = (focusTarget = null, changedId = null) => {
        const summary = cart.summary();
        nodes.lines.replaceChildren();
        for (const line of cart.lines()) {
            const row = nodes.template.content.firstElementChild.cloneNode(true);
            const get = selector => row.querySelector(selector);
            row.dataset.cartProduct = String(line.product.id);
            get('[data-line-image]').src = line.product.image;
            get('[data-line-image]').addEventListener('error', event => { if (!event.target.dataset.fallback) { event.target.dataset.fallback = 'true'; event.target.src = new URL('product-placeholder.svg', document.querySelector('script[src*="assets/cart.js"]').src).href; } });
            get('[data-line-name]').textContent = line.product.name;
            get('[data-line-price]').textContent = `${formatCents(line.product.unitCents)} each`;
            get('[data-line-quantity]').value = String(line.quantity);
            get('[data-line-quantity]').max = String(line.product.stock);
            get('[data-line-quantity]').disabled = pending;
            get('[data-line-quantity]').setAttribute('aria-label', `Quantity ${line.quantity} of ${line.product.name}`);
            get('[data-line-stock]').textContent = `${line.product.stock - line.quantity} remaining`;
            get('[data-line-total]').textContent = formatCents(line.subtotalCents);
            for (const [action, label] of [['decrease', 'Decrease quantity of'], ['increase', 'Increase quantity of'], ['remove', 'Remove']]) {
                const button = get(`[data-line-${action}]`);
                button.setAttribute('aria-label', `${label} ${line.product.name}`);
                button.disabled = pending || (action === 'increase' && line.quantity >= line.product.stock);
                button.addEventListener('click', () => {
                    if (pending) return;
                    try {
                        if (action === 'remove') cart.remove(line.product.id);
                        else cart.setQuantity(line.product.id, cart.quantity(line.product.id) + (action === 'increase' ? 1 : -1));
                        showError('');
                        render({ id: line.product.id, action }, line.product.id);
                        const quantity = cart.quantity(line.product.id);
                        feedback.show(quantity ? `${line.product.name}: ${quantity} in order.` : `${line.product.name} removed from order.`);
                    } catch (error) { showError(error.message); }
                });
            }
            get('[data-line-quantity]').addEventListener('change', event => {
                if (pending) return;
                const input = event.target;
                try {
                    if (!/^[1-9]\d*$/.test(input.value)) throw new Error('Enter a whole-number quantity of at least 1.');
                    const previous = cart.quantity(line.product.id);
                    cart.setQuantity(line.product.id, Number(input.value));
                    const quantity = cart.quantity(line.product.id);
                    input.setAttribute('aria-label', `Quantity ${quantity} of ${line.product.name}`);
                    get('[data-line-stock]').textContent = `${line.product.stock - quantity} remaining`;
                    get('[data-line-total]').textContent = formatCents(line.product.unitCents * quantity);
                    get('[data-line-increase]').disabled = quantity >= line.product.stock;
                    showError(''); updateTotals();
                    if (quantity !== previous) {
                        showFeedback(row, 'is-updated');
                        feedback.show(`${line.product.name}: ${quantity} in order.`);
                    }
                } catch (error) {
                    input.value = String(cart.quantity(line.product.id));
                    showError(error.message);
                }
            });
            nodes.lines.append(row);
            if (line.product.id === changedId) showFeedback(row, 'is-updated');
        }
        updateTotals();
        if (focusTarget) {
            const button = find(`[data-cart-product="${focusTarget.id}"] [data-line-${focusTarget.action}]`);
            if (button && !button.disabled) button.focus({ preventScroll: true });
            else if (!summary.lineCount) nodes.search.focus({ preventScroll: true });
            else nodes.checkout.focus({ preventScroll: true });
        }
    };
    root.querySelectorAll('[data-add-product]').forEach(button => button.addEventListener('click', () => {
        if (pending) return;
        try {
            const id = Number(button.dataset.addProduct);
            cart.add(id); showError(''); render(null, id);
            showFeedback(button, 'is-added');
            feedback.show(`${cart.products.get(id).name} added. ${cart.quantity(id)} in order.`);
        } catch (error) { showError(error.message); }
    }));
    nodes.search.addEventListener('input', updateCatalog);
    nodes.search.addEventListener('search', updateCatalog);
    nodes.clearSearch?.addEventListener('click', () => {
        nodes.search.value = ''; updateCatalog(); nodes.search.focus({ preventScroll: true });
    });
    scope.addEventListener('keydown', event => {
        if (pending || !isSearchShortcut(event, Boolean(document.querySelector('dialog[open]')))) return;
        event.preventDefault();
        nodes.search.focus({ preventScroll: false });
        nodes.search.select();
    });
    filters.forEach(button => button.addEventListener('click', () => { filter = button.dataset.stockFilter; updateCatalog(); }));
    find('[data-reset-catalog]')?.addEventListener('click', () => { filter = 'all'; nodes.search.value = ''; updateCatalog(); nodes.search.focus(); });
    nodes.clear.addEventListener('click', () => { if (!pending) { cart.clear(); showError(''); render(); feedback.show('Order cleared. Ready for a new order.'); nodes.search.focus({ preventScroll: true }); } });
    const buildReview = () => {
        const list = find('[data-review-lines]'); list.replaceChildren();
        for (const line of cart.lines()) {
            const row = document.createElement('li'), name = document.createElement('span'), amount = document.createElement('strong');
            name.textContent = `${line.quantity} × ${line.product.name}`; amount.textContent = formatCents(line.subtotalCents);
            row.append(name, amount); list.append(row);
        }
        put('[data-review-customer]', nodes.customer.selectedOptions[0]?.textContent || 'Walk-in customer');
        put('[data-review-quantity]', String(cart.summary().units));
        put('[data-review-total]', formatCents(cart.summary().totalCents));
    };
    const submit = () => {
        if (pending || !cart.summary().lineCount || !nodes.form.reportValidity()) return;
        nodes.payload.value = JSON.stringify(cart.serialize());
        pending = true; nodes.confirm.disabled = true; nodes.confirm.setAttribute('aria-busy', 'true');
        nodes.checkout.setAttribute('aria-busy', 'true');
        put('[data-checkout-button-label]', 'Recording sale…');
        put('[data-review-confirm-label]', 'Recording sale…');
        feedback.show('Recording sale. Please wait…', true);
        // Keep customer enabled until native form serialization has included it.
        nodes.checkout.disabled = true; nodes.clear.disabled = true;
        if (nodes.dialog.open) nodes.dialog.close();
        HTMLFormElement.prototype.submit.call(nodes.form);
    };
    nodes.form.addEventListener('submit', event => {
        event.preventDefault();
        if (pending) return;
        if (!cart.summary().lineCount) { showError('Add a product before checking out.', true); return; }
        showError(''); buildReview();
        if (typeof nodes.dialog.showModal === 'function') nodes.dialog.showModal();
        else if (scope.confirm(`Record this sale for ${formatCents(cart.summary().totalCents)}? Stock will decrease immediately.`)) submit();
    });
    find('[data-review-cancel]').addEventListener('click', () => nodes.dialog.close());
    nodes.confirm.addEventListener('click', submit);
    nodes.dialog.addEventListener('close', () => { if (!pending) nodes.checkout.focus({ preventScroll: true }); });
    // A restored page retains its in-memory cart and idempotency key. The server safely replays it.
    scope.addEventListener('pageshow', () => {
        pending = false; nodes.confirm.disabled = false; nodes.confirm.removeAttribute('aria-busy');
        nodes.checkout.removeAttribute('aria-busy');
        put('[data-checkout-button-label]', 'Review order');
        put('[data-review-confirm-label]', 'Confirm sale');
        feedback.clear(); render();
    });
    let notices = [];
    try { notices = cart.restore(JSON.parse(find('[data-pos-initial]').textContent)); }
    catch (_) { notices = ['The previous order could not be restored. Please add the products again.']; }
    render(); updateCatalog(); if (notices.length) showError(notices.join(' '));
})(typeof window === 'undefined' ? globalThis : window);
