(() => {
    'use strict';
    const root = document.documentElement;
    const themeToggle = document.querySelector('.theme-toggle');
    const setTheme = (theme, persist = false) => {
        root.dataset.theme = theme;
        if (themeToggle) {
            const label = `Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`;
            themeToggle.setAttribute('aria-label', label);
            themeToggle.title = label;
        }
        if (persist) { try { localStorage.setItem('counterpoint-theme', theme); } catch (_) {} }
    };
    setTheme(root.dataset.theme || 'dark');
    themeToggle?.addEventListener('click', () => setTheme(root.dataset.theme === 'dark' ? 'light' : 'dark', true));
    const preference = window.matchMedia?.('(prefers-color-scheme: light)');
    preference?.addEventListener('change', (event) => {
        try { if (['light', 'dark'].includes(localStorage.getItem('counterpoint-theme'))) return; } catch (_) {}
        setTheme(event.matches ? 'light' : 'dark');
    });
    const menuToggles = Array.from(document.querySelectorAll('.sidebar-toggle'));
    const menuToggle = document.querySelector('.header-sidebar-toggle') || menuToggles[0];
    const sidebar = document.getElementById('workspace-sidebar');
    const navigation = document.getElementById('primary-navigation');
    const backdrop = document.querySelector('.navigation-backdrop');
    const workspaceFrame = document.querySelector('.workspace-frame');
    const mobileNavigation = window.matchMedia?.('(max-width: 980px)');
    let mobileOpen = false;
    const isMobile = () => Boolean(mobileNavigation?.matches);
    // A fixed tooltip lives outside the scrolling sidebar, so labels remain readable.
    const sidebarTooltip = document.getElementById('sidebar-tooltip');
    let tooltipOwner = null, previousDescription = null, hoveredLink = null, focusedLink = null;
    const hideSidebarTooltip = () => {
        if (tooltipOwner) {
            if (previousDescription) tooltipOwner.setAttribute('aria-describedby', previousDescription);
            else tooltipOwner.removeAttribute('aria-describedby');
        }
        tooltipOwner = null; previousDescription = null;
        if (sidebarTooltip) { sidebarTooltip.hidden = true; sidebarTooltip.textContent = ''; }
    };
    const showSidebarTooltip = (link) => {
        hideSidebarTooltip();
        if (!sidebarTooltip || !link || isMobile() || root.dataset.sidebar !== 'compact') return;
        const bounds = link.getBoundingClientRect?.();
        if (!bounds) return;
        tooltipOwner = link; previousDescription = link.getAttribute('aria-describedby');
        const descriptions = new Set((previousDescription || '').split(/\s+/).filter(Boolean));
        descriptions.add('sidebar-tooltip');
        link.setAttribute('aria-describedby', Array.from(descriptions).join(' '));
        sidebarTooltip.textContent = link.dataset.label || link.getAttribute('aria-label') || '';
        sidebarTooltip.hidden = false;
        const size = sidebarTooltip.getBoundingClientRect?.() || { width: 160, height: 36 };
        const width = window.innerWidth || root.clientWidth || 1024;
        const height = window.innerHeight || root.clientHeight || 768;
        const clamp = (value, maximum) => Math.max(8, Math.min(value, maximum));
        sidebarTooltip.style.left = `${clamp(bounds.right + 12, width - size.width - 8)}px`;
        sidebarTooltip.style.top = `${clamp(bounds.top + (bounds.height - size.height) / 2, height - size.height - 8)}px`;
    };
    const dismissSidebarTooltip = () => {
        hoveredLink = null; focusedLink = null; hideSidebarTooltip();
    };
    // Keep old saved preferences compatible with the icon-rail navigation.
    const normalizeSidebar = (value) => value === 'compact' || value === 'hidden' ? 'compact' : 'expanded';
    root.dataset.sidebar = normalizeSidebar(root.dataset.sidebar);
    const syncNavigation = () => {
        dismissSidebarTooltip();
        if (!menuToggle || !sidebar) return;
        const mobile = isMobile();
        const expanded = mobile ? mobileOpen : root.dataset.sidebar === 'expanded';
        const label = mobile
            ? (mobileOpen ? 'Close navigation' : 'Open navigation')
            : (expanded ? 'Collapse sidebar' : 'Expand sidebar');
        menuToggles.forEach((toggle) => {
            toggle.setAttribute('aria-expanded', String(expanded));
            toggle.setAttribute('aria-label', label);
            toggle.title = label;
        });
        // Compact desktop navigation remains fully usable: only its labels collapse.
        sidebar.inert = mobile && !mobileOpen;
        if (sidebar.inert) sidebar.setAttribute('aria-hidden', 'true');
        else sidebar.removeAttribute('aria-hidden');
        const drawerOpen = mobile && mobileOpen;
        if (workspaceFrame) workspaceFrame.inert = drawerOpen;
        if (drawerOpen) {
            sidebar.setAttribute('role', 'dialog');
            sidebar.setAttribute('aria-modal', 'true');
        } else {
            sidebar.removeAttribute('role');
            sidebar.removeAttribute('aria-modal');
        }
        document.body.classList.toggle('navigation-open', drawerOpen);
        navigation?.classList.toggle('is-open', drawerOpen);
        if (backdrop) backdrop.hidden = !drawerOpen;
    };
    const setDesktopNavigation = (expanded) => {
        root.dataset.sidebar = expanded ? 'expanded' : 'compact';
        try { localStorage.setItem('counterpoint-sidebar', root.dataset.sidebar); } catch (_) {}
    };
    const closeNavigation = (restoreFocus = false) => {
        const wasOpen = mobileOpen;
        if (isMobile()) mobileOpen = false;
        syncNavigation();
        if (wasOpen && restoreFocus) menuToggle?.focus?.();
    };
    syncNavigation();
    sidebar?.querySelectorAll('[data-label]').forEach((link) => {
        link.addEventListener('mouseenter', () => { hoveredLink = link; showSidebarTooltip(focusedLink || hoveredLink); });
        link.addEventListener('mouseleave', () => { if (hoveredLink === link) hoveredLink = null; showSidebarTooltip(focusedLink || hoveredLink); });
        link.addEventListener('focus', () => { focusedLink = link; showSidebarTooltip(link); });
        link.addEventListener('blur', () => { if (focusedLink === link) focusedLink = null; showSidebarTooltip(hoveredLink); });
    });
    document.addEventListener('scroll', dismissSidebarTooltip, true);
    window.addEventListener('resize', dismissSidebarTooltip);
    menuToggles.forEach((toggle) => toggle.addEventListener('click', () => {
        if (!sidebar) return;
        if (isMobile()) mobileOpen = !mobileOpen;
        else setDesktopNavigation(root.dataset.sidebar === 'compact');
        syncNavigation();
        if (isMobile()) {
            if (mobileOpen) navigation?.querySelector?.('a')?.focus?.();
            else menuToggle?.focus?.();
        }
    }));
    mobileNavigation?.addEventListener('change', () => {
        const focusWasInSidebar = sidebar?.contains(document.activeElement);
        const focusWasHeaderToggle = document.activeElement === menuToggle;
        mobileOpen = false;
        syncNavigation();
        if (focusWasInSidebar && sidebar?.inert) menuToggle?.focus?.();
        else if (!isMobile() && focusWasHeaderToggle) menuToggles.find(toggle => sidebar?.contains(toggle))?.focus?.();
    });
    document.querySelectorAll('[data-navigation-close]').forEach((button) => button.addEventListener('click', () => closeNavigation(true)));
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            dismissSidebarTooltip();
            document.querySelectorAll('details[open]').forEach((details) => details.removeAttribute('open'));
            if (isMobile() && mobileOpen) closeNavigation(true);
        }
        if (event.key !== 'Tab' || !isMobile() || !mobileOpen || !sidebar) return;
        const controls = Array.from(sidebar.querySelectorAll('a[href], button:not([disabled]), [tabindex="0"]'));
        const first = controls[0], last = controls[controls.length - 1];
        if (!first || !last) return;
        if (event.shiftKey && (document.activeElement === first || !sidebar.contains(document.activeElement))) {
            event.preventDefault(); last.focus();
        } else if (!event.shiftKey && (document.activeElement === last || !sidebar.contains(document.activeElement))) {
            event.preventDefault(); first.focus();
        }
    });
    document.addEventListener('click', (event) => {
        if (isMobile() && mobileOpen && !sidebar?.contains(event.target) && !menuToggles.some((toggle) => toggle.contains(event.target))) closeNavigation();
        document.querySelectorAll('details.account-menu[open]').forEach((details) => { if (!details.contains(event.target)) details.removeAttribute('open'); });
    });
    const confirmation = document.getElementById('confirmation-dialog');
    const hasDialog = confirmation && typeof confirmation.showModal === 'function';
    let pendingConfirmation = null;
    if (hasDialog) {
        confirmation.querySelector('[data-confirm-cancel]').addEventListener('click', () => confirmation.close());
        confirmation.querySelector('[data-confirm-accept]').addEventListener('click', () => {
            const pending = pendingConfirmation;
            confirmation.close();
            if (!pending) return;
            pending.form.dataset.confirmed = 'true';
            pending.form.requestSubmit(pending.submitter || undefined);
        });
        confirmation.addEventListener('close', () => { pendingConfirmation = null; });
    }
    document.querySelectorAll('form[data-confirm]').forEach((form) => form.addEventListener('submit', (event) => {
        if (form.dataset.confirmed === 'true') { delete form.dataset.confirmed; return; }
        if (!hasDialog || typeof form.requestSubmit !== 'function') {
            if (!window.confirm(form.dataset.confirm)) event.preventDefault();
            return;
        }
        event.preventDefault();
        pendingConfirmation = { form, submitter: event.submitter };
        confirmation.querySelector('#confirmation-message').textContent = form.dataset.confirm;
        confirmation.showModal();
    }));
    document.querySelectorAll('[data-notice-close]').forEach((button) => button.addEventListener('click', () => button.closest('.notice')?.remove()));
    document.querySelectorAll('form[data-submit-once]').forEach((form) => form.addEventListener('submit', (event) => {
        if (event.defaultPrevented) return;
        if (form.dataset.submitted === 'true') { event.preventDefault(); return; }
        form.dataset.submitted = 'true';
        form.querySelectorAll('button[type="submit"]').forEach((button) => { button.disabled = true; button.setAttribute('aria-busy', 'true'); });
    }));
    // A restored browser page must remain usable after Back/Forward navigation.
    window.addEventListener('pageshow', () => document.querySelectorAll('form[data-submit-once]').forEach((form) => {
        delete form.dataset.submitted;
        form.querySelectorAll('button[type="submit"]').forEach((button) => { button.disabled = false; button.removeAttribute('aria-busy'); });
    }));
    document.querySelectorAll('img.thumb, img.avatar, img.image-preview, img.form-image, .product-image img').forEach((img) => img.addEventListener('error', () => {
        if (img.dataset.fallbackApplied) return;
        img.dataset.fallbackApplied = 'true';
        const assets = document.querySelector('link[href*="assets/app.css"]')?.href.replace(/app\.css(?:\?.*)?$/, '') || '/assets/';
        img.src = assets + (img.classList.contains('avatar') ? 'avatar-placeholder.svg' : 'product-placeholder.svg');
    }));
    const sale = document.querySelector('[data-sale-form]');
    if (!sale) return;
    const product = sale.querySelector('[name="product_id"]');
    const quantity = sale.querySelector('[name="quantity"]');
    const customer = sale.querySelector('[name="customer_id"]');
    const formatMoney = (cents) => new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(cents / 100);
    const put = (selector, value) => { const target = sale.querySelector(selector); if (target) target.textContent = value; };
    const update = () => {
        const option = product.selectedOptions[0];
        const selected = Boolean(option?.value);
        const stock = selected ? Number(option.dataset.stock) : 0;
        const unitCents = selected ? Math.round(Number(option.dataset.price) * 100) : 0;
        const units = /^\d+$/.test(quantity.value) ? Number(quantity.value) : 0;
        const name = selected ? option.dataset.name : 'Not selected';
        sale.querySelector('[data-stock-preview]').hidden = !selected;
        if (selected) {
            sale.querySelector('[data-sale-image]').src = option.dataset.image;
            put('[data-sale-name]', name);
            put('[data-unit-price]', formatMoney(unitCents));
            put('[data-stock-badge]', `${stock} in stock`);
            sale.querySelector('[data-stock-badge]').className = `badge ${stock <= 5 ? 'warning' : 'success'}`;
        }
        quantity.max = selected ? String(stock) : '';
        sale.querySelector('[data-quantity-warning]').hidden = !selected || units <= stock;
        put('[data-summary-product]', name);
        put('[data-summary-customer]', customer.selectedOptions[0]?.textContent || 'Walk-in customer');
        put('[data-summary-unit]', selected ? formatMoney(unitCents) : '—');
        put('[data-summary-quantity]', units > 0 ? String(units) : '—');
        put('[data-sale-total]', formatMoney(unitCents * units));
    };
    [product, quantity, customer].forEach((input) => { input.addEventListener('input', update); input.addEventListener('change', update); });
    update();
})();
