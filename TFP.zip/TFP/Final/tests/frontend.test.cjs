// Dependency-free behavior checks for the actual shared browser controller.
// These checks exercise DOM contracts; responsive layout still needs a browser.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
function element(extra = {}) {
    const classes = new Set();
    return Object.assign({ dataset: {}, attributes: {}, listeners: {}, hidden: false, textContent: '', disabled: false,
        addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); },
        dispatch(name, event = {}) { this.listeners[name]?.forEach(fn => fn(event)); },
        setAttribute(k, v) { this.attributes[k] = String(v); },
        getAttribute(k) { return this.attributes[k] ?? null; },
        removeAttribute(k) { delete this.attributes[k]; },
        focus() { this.focusCount = (this.focusCount || 0) + 1; },
        contains(target) { return target === this || (this.children || []).some(child => child.contains(target)); },
        classList: {
            toggle(name, force) { const selected = force === undefined ? !classes.has(name) : Boolean(force); if (selected) classes.add(name); else classes.delete(name); return selected; },
            remove(...names) { names.forEach(name => classes.delete(name)); },
            contains(name) { return classes.has(name); }
        }
    }, extra);
}
function fixture({ mobile = true, compact = false, legacy = false, storageUnavailable = false } = {}) {
    const root = element({ dataset: { theme: 'dark', sidebar: legacy ? (compact ? 'hidden' : 'visible') : (compact ? 'compact' : 'expanded') } });
    const toggle = element(), menu = element(), firstLink = element({ dataset: { label: 'Overview' }, getBoundingClientRect() { return { top: 120, right: 96, height: 44 }; } }), railToggle = element(), closeNavigation = railToggle, submit = element();
    const nav = element({ children: [firstLink], querySelector(selector) { return selector === 'a' ? firstLink : null; } });
    const sidebar = element({ children: [railToggle, nav], querySelectorAll(selector) { return selector === '[data-label]' ? [firstLink] : [railToggle, firstLink]; } });
    const tooltip = element({ hidden: true, style: {}, getBoundingClientRect() { return { width: 120, height: 36 }; } });
    const backdrop = element(), body = element(), workspaceFrame = element();
    const product = element({ selectedOptions: [{ value: '1', dataset: { name: 'Notebook · dotted edition', price: '140.00', stock: '3', image: '/media/notebook.jpg' } }] });
    const quantity = element({ value: '2' });
    const customer = element({ selectedOptions: [{ textContent: 'Walk-in customer' }] });
    const fields = new Map([['[name="product_id"]', product], ['[name="quantity"]', quantity], ['[name="customer_id"]', customer]]);
    const sale = element({
        querySelector(selector) { if (!fields.has(selector)) fields.set(selector, element()); return fields.get(selector); },
        querySelectorAll(selector) { return selector === 'button[type="submit"]' ? [submit] : []; }
    });
    const storage = new Map(), windowListeners = {}, documentListeners = {}, preference = element({ matches: false }), mobilePreference = element({ matches: mobile });
    const document = {
        documentElement: root, body, activeElement: null,
        querySelector(selector) { return { '.theme-toggle': toggle, '.header-sidebar-toggle': menu, '.navigation-backdrop': backdrop, '.workspace-frame': workspaceFrame, '[data-sale-form]': sale }[selector] || null; },
        querySelectorAll(selector) { return selector === 'form[data-submit-once]' ? [sale] : selector === '.sidebar-toggle' ? [railToggle, menu] : selector === '[data-navigation-close]' ? [backdrop] : []; },
        getElementById(id) { return id === 'primary-navigation' ? nav : id === 'workspace-sidebar' ? sidebar : id === 'sidebar-tooltip' ? tooltip : null; },
        addEventListener(name, fn) { (documentListeners[name] ||= []).push(fn); },
        dispatch(name, event) { documentListeners[name]?.forEach(fn => fn(event)); }
    };
    [firstLink, closeNavigation, menu].forEach(control => { control.focus = function () { this.focusCount = (this.focusCount || 0) + 1; document.activeElement = this; }; });
    const window = { innerWidth: 1024, innerHeight: 768, matchMedia: query => query.includes('max-width') ? mobilePreference : preference, addEventListener(name, fn) { windowListeners[name] = fn; }, confirm: () => true };
    const context = { document, window, localStorage: { getItem(k) { if (storageUnavailable) throw new Error('Storage unavailable'); return storage.get(k) ?? null; }, setItem(k, v) { if (storageUnavailable) throw new Error('Storage unavailable'); storage.set(k, v); } }, Intl, Number, Boolean, String };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../public/assets/app.js'), 'utf8'), context);
    return { root, toggle, preference, storage, product, quantity, customer, fields, sale, submit, windowListeners, menu, nav, firstLink, railToggle, closeNavigation, document, sidebar, backdrop, body, mobilePreference, workspaceFrame, tooltip, window };
}
test('navigation disclosure opens, focuses its first link and toggles closed', () => {
    const f = fixture();
    f.menu.dispatch('click');
    assert.equal(f.menu.getAttribute('aria-expanded'), 'true');
    assert.equal(f.nav.classList.contains('is-open'), true);
    assert.equal(f.firstLink.focusCount, 1);
    f.menu.dispatch('click');
    assert.equal(f.menu.getAttribute('aria-expanded'), 'false');
    assert.equal(f.nav.classList.contains('is-open'), false);
});
test('Escape closes an open disclosure and restores focus without stealing it when already closed', () => {
    const f = fixture();
    f.menu.dispatch('click');
    f.document.dispatch('keydown', { key: 'Escape' });
    assert.equal(f.menu.getAttribute('aria-expanded'), 'false');
    assert.equal(f.nav.classList.contains('is-open'), false);
    assert.equal(f.menu.focusCount, 1);
    f.document.dispatch('keydown', { key: 'Escape' });
    assert.equal(f.menu.focusCount, 1);
});
test('navigation ignores inside clicks, dismisses outside and its close button restores focus', () => {
    const f = fixture();
    f.menu.dispatch('click');
    f.document.dispatch('click', { target: f.firstLink });
    f.document.dispatch('click', { target: f.menu });
    assert.equal(f.menu.getAttribute('aria-expanded'), 'true');
    f.document.dispatch('click', { target: element() });
    assert.equal(f.menu.getAttribute('aria-expanded'), 'false');
    assert.equal(f.nav.classList.contains('is-open'), false);
    assert.equal(f.menu.focusCount, undefined);
    f.menu.dispatch('click');
    f.closeNavigation.dispatch('click');
    assert.equal(f.nav.classList.contains('is-open'), false);
    assert.equal(f.menu.focusCount, 1);
});
test('both desktop buttons collapse to an accessible icon rail and remember the chosen mode', () => {
    const f = fixture({ mobile: false });
    assert.equal(f.menu.getAttribute('aria-expanded'), 'true');
    assert.equal(f.menu.getAttribute('aria-label'), 'Collapse sidebar');
    assert.equal(f.railToggle.getAttribute('aria-label'), 'Collapse sidebar');
    assert.equal(f.sidebar.inert, false);
    f.railToggle.dispatch('click');
    assert.equal(f.root.dataset.sidebar, 'compact');
    assert.equal(f.storage.get('counterpoint-sidebar'), 'compact');
    assert.equal(f.menu.getAttribute('aria-label'), 'Expand sidebar');
    assert.equal(f.railToggle.getAttribute('aria-expanded'), 'false');
    assert.equal(f.sidebar.inert, false);
    assert.equal(f.sidebar.getAttribute('aria-hidden'), null);
    f.menu.dispatch('click');
    assert.equal(f.root.dataset.sidebar, 'expanded');
    assert.equal(f.railToggle.getAttribute('aria-label'), 'Collapse sidebar');
    assert.equal(f.sidebar.inert, false);
    f.document.dispatch('keydown', { key: 'Escape' });
    assert.equal(f.menu.getAttribute('aria-expanded'), 'true');
});
test('legacy saved sidebar modes map to a usable compact or expanded desktop rail', () => {
    const compact = fixture({ mobile: false, compact: true, legacy: true });
    assert.equal(compact.root.dataset.sidebar, 'compact');
    assert.equal(compact.sidebar.inert, false);
    assert.equal(compact.menu.getAttribute('aria-label'), 'Expand sidebar');
    const expanded = fixture({ mobile: false, legacy: true });
    assert.equal(expanded.root.dataset.sidebar, 'expanded');
    assert.equal(expanded.menu.getAttribute('aria-label'), 'Collapse sidebar');
});
test('mobile drawer closes on a breakpoint change while preserving desktop compact mode', () => {
    const f = fixture({ mobile: false, compact: true });
    assert.equal(f.sidebar.inert, false);
    f.mobilePreference.matches = true;
    f.mobilePreference.dispatch('change');
    assert.equal(f.sidebar.inert, true);
    assert.equal(f.menu.getAttribute('aria-label'), 'Open navigation');
    f.menu.dispatch('click');
    assert.equal(f.menu.getAttribute('aria-expanded'), 'true');
    assert.equal(f.railToggle.getAttribute('aria-label'), 'Close navigation');
    assert.equal(f.body.classList.contains('navigation-open'), true);
    assert.equal(f.workspaceFrame.inert, true);
    assert.equal(f.sidebar.getAttribute('aria-modal'), 'true');
    assert.equal(f.backdrop.hidden, false);
    assert.equal(f.root.dataset.sidebar, 'compact');
    f.mobilePreference.matches = false;
    f.mobilePreference.dispatch('change');
    assert.equal(f.sidebar.inert, false);
    assert.equal(f.menu.getAttribute('aria-label'), 'Expand sidebar');
    assert.equal(f.backdrop.hidden, true);
    assert.equal(f.body.classList.contains('navigation-open'), false);
    assert.equal(f.workspaceFrame.inert, false);
    assert.equal(f.sidebar.getAttribute('role'), null);
    // The focused icon link stays usable in the compact desktop rail.
    assert.equal(f.document.activeElement, f.firstLink);
    f.mobilePreference.matches = true;
    f.mobilePreference.dispatch('change');
    assert.equal(f.menu.getAttribute('aria-expanded'), 'false');
    assert.equal(f.document.activeElement, f.menu);
});
test('mobile drawer wraps keyboard focus and its backdrop restores the toggle', () => {
    const f = fixture();
    assert.equal(f.sidebar.inert, true);
    f.menu.dispatch('click');
    f.railToggle.focus();
    const shiftTab = { key: 'Tab', shiftKey: true, preventDefault() { this.prevented = true; } };
    f.document.dispatch('keydown', shiftTab);
    assert.equal(shiftTab.prevented, true);
    assert.equal(f.document.activeElement, f.firstLink);
    const tab = { key: 'Tab', preventDefault() { this.prevented = true; } };
    f.document.dispatch('keydown', tab);
    assert.equal(tab.prevented, true);
    assert.equal(f.document.activeElement, f.railToggle);
    f.backdrop.dispatch('click');
    assert.equal(f.menu.getAttribute('aria-expanded'), 'false');
    assert.equal(f.document.activeElement, f.menu);
    assert.equal(f.backdrop.hidden, true);
});
test('sidebar remains operable when browser storage is unavailable', () => {
    const f = fixture({ mobile: false, storageUnavailable: true });
    f.menu.dispatch('click');
    assert.equal(f.root.dataset.sidebar, 'compact');
    assert.equal(f.sidebar.inert, false);
    f.menu.dispatch('click');
    assert.equal(f.root.dataset.sidebar, 'expanded');
    assert.equal(f.sidebar.inert, false);
    assert.equal(f.menu.getAttribute('aria-expanded'), 'true');
});
test('compact rail labels remain visible for keyboard focus and preserve existing descriptions', () => {
    const f = fixture({ mobile: false, compact: true });
    f.firstLink.setAttribute('aria-describedby', 'existing-description');
    f.firstLink.dispatch('mouseenter');
    assert.equal(f.tooltip.hidden, false);
    assert.equal(f.tooltip.textContent, 'Overview');
    assert.equal(f.firstLink.getAttribute('aria-describedby'), 'existing-description sidebar-tooltip');
    f.firstLink.dispatch('focus');
    f.firstLink.dispatch('mouseleave');
    assert.equal(f.tooltip.hidden, false);
    f.firstLink.dispatch('blur');
    assert.equal(f.tooltip.hidden, true);
    assert.equal(f.firstLink.getAttribute('aria-describedby'), 'existing-description');
});
test('rail tooltip stays within viewport and dismisses after scroll resize Escape or mode changes', () => {
    const f = fixture({ mobile: false, compact: true });
    f.window.innerWidth = 200; f.window.innerHeight = 120;
    f.firstLink.getBoundingClientRect = () => ({ top: 110, right: 190, height: 44 });
    f.firstLink.dispatch('mouseenter');
    assert.equal(f.tooltip.style.left, '72px');
    assert.equal(f.tooltip.style.top, '76px');
    f.document.dispatch('scroll', {});
    assert.equal(f.tooltip.hidden, true);
    assert.equal(f.firstLink.getAttribute('aria-describedby'), null);
    f.firstLink.dispatch('focus'); f.windowListeners.resize();
    assert.equal(f.tooltip.hidden, true);
    f.firstLink.dispatch('mouseenter'); f.document.dispatch('keydown', { key: 'Escape' });
    assert.equal(f.tooltip.hidden, true);
    f.firstLink.dispatch('focus'); f.menu.dispatch('click');
    assert.equal(f.root.dataset.sidebar, 'expanded');
    assert.equal(f.tooltip.hidden, true);
});
test('expanded menus and mobile drawers use their visible labels without rail tooltips', () => {
    const expanded = fixture({ mobile: false });
    expanded.firstLink.dispatch('mouseenter');
    assert.equal(expanded.tooltip.hidden, true);
    const mobile = fixture({ compact: true });
    mobile.menu.dispatch('click'); mobile.firstLink.dispatch('focus');
    assert.equal(mobile.tooltip.hidden, true);
});
test('sale preview preserves product names and calculates from price and quantity', () => {
    const f = fixture();
    assert.equal(f.fields.get('[data-summary-product]').textContent, 'Notebook · dotted edition');
    assert.match(f.fields.get('[data-sale-total]').textContent, /280\.00/);
    f.quantity.value = '3'; f.quantity.dispatch('input');
    assert.match(f.fields.get('[data-sale-total]').textContent, /420\.00/);
    assert.equal(f.quantity.max, '3');
});
test('excess stock warns and selecting no product clears its preview', () => {
    const f = fixture();
    f.quantity.value = '4'; f.quantity.dispatch('input');
    assert.equal(f.fields.get('[data-quantity-warning]').hidden, false);
    f.quantity.value = '3'; f.quantity.dispatch('input');
    assert.equal(f.fields.get('[data-quantity-warning]').hidden, true);
    f.product.selectedOptions = [{ value: '', dataset: {} }]; f.product.dispatch('change');
    assert.equal(f.fields.get('[data-stock-preview]').hidden, true);
    assert.equal(f.fields.get('[data-summary-product]').textContent, 'Not selected');
});
test('small monetary amounts use cents and customer selection updates review', () => {
    const f = fixture();
    f.product.selectedOptions[0].dataset.price = '0.10';
    f.quantity.value = '3'; f.quantity.dispatch('input');
    assert.match(f.fields.get('[data-sale-total]').textContent, /0\.30/);
    f.customer.selectedOptions = [{ textContent: 'Customer example' }]; f.customer.dispatch('change');
    assert.equal(f.fields.get('[data-summary-customer]').textContent, 'Customer example');
});
test('theme toggle persists choice and saved choice overrides system changes', () => {
    const f = fixture();
    assert.equal(f.toggle.getAttribute('aria-label'), 'Switch to light mode');
    f.toggle.dispatch('click');
    assert.equal(f.root.dataset.theme, 'light');
    assert.equal(f.storage.get('counterpoint-theme'), 'light');
    f.preference.dispatch('change', { matches: false });
    assert.equal(f.root.dataset.theme, 'light');
    f.storage.clear(); f.preference.dispatch('change', { matches: false });
    assert.equal(f.root.dataset.theme, 'dark');
});
test('a second sale submit is stopped and browser restore enables the form again', () => {
    const f = fixture();
    const first = { defaultPrevented: false, preventDefault() { this.defaultPrevented = true; } };
    f.sale.dispatch('submit', first);
    assert.equal(first.defaultPrevented, false);
    assert.equal(f.submit.disabled, true);
    const second = { defaultPrevented: false, preventDefault() { this.defaultPrevented = true; } };
    f.sale.dispatch('submit', second);
    assert.equal(second.defaultPrevented, true);
    f.windowListeners.pageshow();
    assert.equal(f.submit.disabled, false);
    assert.equal(f.sale.dataset.submitted, undefined);
});

test('breakpoint changes move focus to the visible menu button', () => {
    const f = fixture();
    f.menu.focus();
    f.mobilePreference.matches = false;
    f.mobilePreference.dispatch('change');
    assert.equal(f.document.activeElement, f.railToggle);
    f.mobilePreference.matches = true;
    f.mobilePreference.dispatch('change');
    assert.equal(f.document.activeElement, f.menu);
    assert.equal(f.sidebar.inert, true);
});
