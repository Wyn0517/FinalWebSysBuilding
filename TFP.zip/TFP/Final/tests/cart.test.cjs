// Runs against the same cart model used by the browser. No npm packages required.
// Server transaction tests remain necessary; these checks do not replace them.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { CartModel, priceToCents, matchesProductSearch, isSearchShortcut, createCartFeedback, MAX_LINES, MAX_QUANTITY, MAX_TOTAL_CENTS } = require('../public/assets/cart.js');
const catalog = () => [
    { id: 1, name: 'Notebook · large', price: '140.00', stock: 3, image: '/media/notebook.jpg' },
    { id: 2, name: 'Pen', price: '0.10', stock: 10, image: '' },
    { id: 3, name: 'Unavailable item', price: '20.00', stock: 0, image: '' }
];
test('catalog search matches names regardless of case and surrounding spaces', () => {
    const product = catalog()[0];
    assert.equal(matchesProductSearch(product, ' NOTEBOOK '), true);
    assert.equal(matchesProductSearch(product, 'large'), true);
    assert.equal(matchesProductSearch(product, 'pen'), false);
    assert.equal(matchesProductSearch(product, '  '), true);
});
test('hash-prefixed IDs are exact while bare numeric searches also match product names', () => {
    const product = { id: 12, name: 'Notebook' };
    assert.equal(matchesProductSearch(product, '#12'), true);
    assert.equal(matchesProductSearch(product, '12'), true);
    assert.equal(matchesProductSearch(product, ' #0012 '), true);
    assert.equal(matchesProductSearch(product, '#1'), false);
    assert.equal(matchesProductSearch(product, '#12x'), false);
    assert.equal(matchesProductSearch({ id: 3, name: '12-pack pencils' }, '12'), true);
    assert.equal(matchesProductSearch({ id: 3, name: '12-pack pencils' }, '#12'), false);
});
test('F2 search shortcut yields to dialogs, modified keys and composition', () => {
    assert.equal(isSearchShortcut({ key: 'F2' }), true);
    assert.equal(isSearchShortcut({ key: 'F2' }, true), false);
    assert.equal(isSearchShortcut({ key: 'F1' }), false);
    for (const field of ['ctrlKey', 'altKey', 'metaKey', 'shiftKey', 'isComposing', 'defaultPrevented']) {
        assert.equal(isSearchShortcut({ key: 'F2', [field]: true }), false);
    }
});
test('adding a product twice uses one line with the right quantity and cents', () => {
    const cart = new CartModel(catalog());
    cart.add(1); cart.add(1); cart.add(2);
    assert.deepEqual(cart.summary(), { totalCents: 28010, units: 3, lineCount: 2 });
    assert.deepEqual(cart.serialize(), [{ product_id: 1, quantity: 2 }, { product_id: 2, quantity: 1 }]);
    assert.equal(cart.lines()[0].product.name, 'Notebook · large');
});
test('decrease to zero, remove, and clear update all totals', () => {
    const cart = new CartModel(catalog());
    cart.add(1); cart.add(2); cart.setQuantity(1, 0);
    assert.equal(cart.quantity(1), 0);
    assert.equal(cart.summary().totalCents, 10);
    cart.remove(2); assert.equal(cart.summary().lineCount, 0);
    cart.add(1); cart.clear();
    assert.deepEqual(cart.summary(), { totalCents: 0, units: 0, lineCount: 0 });
});
test('stock bounds reject overselling and leave the cart unchanged', () => {
    const cart = new CartModel(catalog());
    cart.setQuantity(1, 3);
    assert.throws(() => cart.add(1), /Only 3 units/);
    assert.throws(() => cart.add(3), /Only 0 units/);
    assert.equal(cart.quantity(1), 3);
    assert.equal(cart.quantity(3), 0);
});
test('fractional, negative, malformed, and excessive quantities are rejected', () => {
    const cart = new CartModel(catalog());
    for (const value of [-1, 1.5, NaN, Infinity, '2', MAX_QUANTITY + 1]) {
        assert.throws(() => cart.setQuantity(1, value), /valid whole-number quantity/);
    }
    assert.equal(cart.summary().lineCount, 0);
});
test('unknown products cannot be added and serialized payload contains no client prices', () => {
    const cart = new CartModel(catalog());
    assert.throws(() => cart.add(999), /no longer in the catalog/);
    cart.add(1);
    assert.deepEqual(Object.keys(cart.serialize()[0]), ['product_id', 'quantity']);
});
test('decimal conversion and repeated low-value items retain exact cents', () => {
    assert.equal(priceToCents('0.1'), 10);
    assert.equal(priceToCents('12'), 1200);
    assert.equal(priceToCents('99999999.99'), MAX_TOTAL_CENTS);
    for (const value of ['1e2', '-1', '0.001', 'text', '100000000.00']) assert.throws(() => priceToCents(value), /invalid price/);
    const cart = new CartModel(catalog());
    cart.setQuantity(2, 3);
    assert.equal(cart.summary().totalCents, 30);
});
test('the monetary ceiling rolls back the attempted change', () => {
    const cart = new CartModel([{ id: 1, name: 'High value item', price: '99999999.99', stock: 2 }, ...catalog().slice(1)]);
    cart.add(1);
    assert.equal(cart.summary().totalCents, MAX_TOTAL_CENTS);
    assert.throws(() => cart.add(1), /total must not exceed/);
    assert.throws(() => cart.add(2), /total must not exceed/);
    assert.deepEqual(cart.serialize(), [{ product_id: 1, quantity: 1 }]);
});
test('the distinct-product limit allows existing-line edits and rejects new lines', () => {
    const products = Array.from({ length: MAX_LINES + 1 }, (_, i) => ({ id: i + 1, name: `Product ${i}`, price: '1.00', stock: 10 }));
    const cart = new CartModel(products);
    for (let i = 1; i <= MAX_LINES; i++) cart.add(i);
    assert.throws(() => cart.add(MAX_LINES + 1), /50 different products/);
    cart.add(1);
    assert.equal(cart.summary().lineCount, MAX_LINES);
    assert.equal(cart.quantity(1), 2);
});
test('the aggregate quantity ceiling also protects zero-price orders', () => {
    const cart = new CartModel([{ id: 1, name: 'Free item A', price: '0.00', stock: MAX_QUANTITY }, { id: 2, name: 'Free item B', price: '0.00', stock: 1 }]);
    cart.setQuantity(1, MAX_QUANTITY);
    assert.throws(() => cart.add(2), /too many units/);
    assert.equal(cart.quantity(2), 0);
    assert.equal(cart.summary().totalCents, 0);
});
test('restored orders merge duplicate ids and clamp changed stock with an explanation', () => {
    const cart = new CartModel(catalog());
    const notices = cart.restore([{ product_id: 1, quantity: 2 }, { product_id: 1, quantity: 2 }, { product_id: 2, quantity: 3 }]);
    assert.equal(cart.quantity(1), 3);
    assert.equal(cart.quantity(2), 3);
    assert.match(notices[0], /adjusted to its current stock/);
});
test('restored orders discard unknown or malformed items and remain reviewable', () => {
    const cart = new CartModel(catalog());
    const notices = cart.restore([{ product_id: 3, quantity: 1 }, { product_id: 99, quantity: 1 }, { product_id: 1, quantity: -1 }, { product_id: 2, quantity: 2 }]);
    assert.equal(notices.length, 3);
    assert.deepEqual(cart.serialize(), [{ product_id: 2, quantity: 2 }]);
    assert.equal(cart.restore(null).length, 1);
});

// Exercise the feedback lifecycle with a controllable clock: stale timers must
// never hide a newer result, and only one live region receives each message.
function feedbackClock() {
    let next = 0;
    const pending = new Map();
    return {
        pending,
        setTimeout(callback) { pending.set(++next, callback); return next; },
        clearTimeout(id) { pending.delete(id); },
        expire() { const callbacks = [...pending.values()]; pending.clear(); callbacks.forEach(callback => callback()); }
    };
}
test('cart feedback updates the persistent announcement channel and replaces stale expiry', () => {
    const visible = { hidden: true, textContent: '' }, fallback = { textContent: '' }, clock = feedbackClock();
    const feedback = createCartFeedback(visible, fallback, clock);
    feedback.show('Notebook added. 1 in order.');
    assert.equal(visible.hidden, false);
    assert.match(visible.textContent, /Notebook added/);
    assert.equal(fallback.textContent, 'Notebook added. 1 in order.');
    const originalTimer = [...clock.pending.keys()][0];
    feedback.show('Notebook: 2 in order.');
    assert.equal(clock.pending.has(originalTimer), false);
    assert.equal(clock.pending.size, 1);
    assert.equal(visible.textContent, 'Notebook: 2 in order.');
    assert.equal(fallback.textContent, 'Notebook: 2 in order.');
    clock.expire();
    assert.equal(visible.hidden, true);
    assert.equal(visible.textContent, '');
    assert.equal(fallback.textContent, '');
});
test('pending checkout feedback stays visible until explicitly cleared or replaced', () => {
    const visible = { hidden: true, textContent: '' }, announcement = { textContent: '' }, clock = feedbackClock();
    const feedback = createCartFeedback(visible, announcement, clock);
    feedback.show('Recording sale. Please wait…', true);
    assert.equal(clock.pending.size, 0);
    clock.expire();
    assert.equal(visible.hidden, false);
    assert.match(visible.textContent, /Recording sale/);
    assert.equal(announcement.textContent, visible.textContent);
    feedback.clear();
    assert.equal(visible.hidden, true);
    assert.equal(visible.textContent, '');
    assert.equal(announcement.textContent, '');
});
test('older views retain their screen-reader feedback without a visible status element', () => {
    const fallback = { textContent: '' }, clock = feedbackClock();
    const feedback = createCartFeedback(null, fallback, clock);
    feedback.show('Pen removed from order.');
    assert.equal(fallback.textContent, 'Pen removed from order.');
    assert.equal(clock.pending.size, 0);
    feedback.show('Order cleared.');
    assert.equal(fallback.textContent, 'Order cleared.');
    feedback.clear();
    assert.equal(fallback.textContent, '');
});
