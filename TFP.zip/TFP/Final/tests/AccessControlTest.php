<?php

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use CodeIgniter\Test\FeatureTestTrait;
use CodeIgniter\Test\TestResponse;

/** Exercises real routes and their configured authentication, role and ownership filters. */
final class AccessControlTest extends CIUnitTestCase
{
    use DatabaseTestTrait;
    use FeatureTestTrait;

    protected $namespace = 'App';
    protected $refresh = true;

    public function testProtectedPagesRequireAuthentication(): void
    {
        foreach (['/', '/pos', '/profile', '/products', '/customers', '/staff', '/sales', '/admin/dashboard', '/admin/products', '/admin/users'] as $path) {
            $this->withSession([])->get($path)->assertRedirectTo(site_url('login'));
        }
    }

    public function testCashierCannotReadManagementThroughLegacyOrAdminUrls(): void
    {
        $id = $this->staff('cashier');
        foreach (['/products', '/products/new', '/products/1/edit', '/customers', '/customers/new', '/staff', '/staff/new', '/admin/dashboard', '/admin/products', '/admin/customers', '/admin/users', '/admin/sales'] as $path) {
            $this->withSession(['user_id' => $id, 'user' => ['role' => 'admin']])->get($path)->assertStatus(403);
        }
    }

    public function testCashierCannotSubmitManagementActionsWithValidCsrf(): void
    {
        $id = $this->staff('cashier');
        foreach (['/products', '/products/1', '/products/1/delete', '/customers', '/customers/1', '/customers/1/delete', '/staff', '/staff/1', '/staff/1/delete', '/admin/products', '/admin/products/1/delete', '/admin/customers', '/admin/users'] as $path) {
            $this->postAs($id, $path, ['role' => 'admin', 'name' => 'Forged product'])->assertStatus(403);
        }
        self::assertSame(0, $this->db->table('products')->countAllResults());
        self::assertSame(0, $this->db->table('customers')->countAllResults());
        self::assertSame(1, $this->db->table('users')->countAllResults());
    }

    public function testEntryRouteChoosesTheDatabaseRole(): void
    {
        $cashier = $this->staff('cashier');
        $admin = $this->staff('admin');
        $this->withSession(['user_id' => $cashier, 'user' => ['role' => 'admin']])->get('/')->assertRedirectTo(site_url('pos'));
        $this->withSession(['user_id' => $admin])->get('/')->assertRedirectTo(site_url('admin/dashboard'));
    }

    public function testInactiveAccountLosesProtectedAccessImmediately(): void
    {
        $id = $this->staff('cashier');
        $this->db->table('users')->where('id', $id)->update(['is_active' => 0]);
        $this->withSession(['user_id' => $id])->get('/pos')->assertRedirectTo(site_url('login'));
    }

    public function testArchivedAccountLosesProtectedAccessImmediately(): void
    {
        $id = $this->staff('cashier');
        $this->db->table('users')->where('id', $id)->update(['deleted_at' => date('Y-m-d H:i:s')]);
        $this->withSession(['user_id' => $id])->get('/sales')->assertRedirectTo(site_url('login'));
    }

    public function testActiveCashierCanUseCheckoutHistoryAndProfile(): void
    {
        $id = $this->staff('cashier');
        foreach (['/pos', '/sales', '/profile'] as $path) {
            $this->withSession(['user_id' => $id])->get($path)->assertStatus(200);
        }
    }

    public function testAdministratorCanUseManagementAndCheckout(): void
    {
        $id = $this->staff('admin');
        foreach (['/admin/dashboard', '/admin/products', '/admin/customers', '/admin/users', '/admin/sales', '/pos'] as $path) {
            $this->withSession(['user_id' => $id])->get($path)->assertStatus(200);
        }
    }

    public function testProfileIgnoresForgedPrivilegesAndOtherAccountIds(): void
    {
        $cashier = $this->staff('cashier');
        $admin = $this->staff('admin');
        $before = $this->user($cashier);
        $this->postAs($cashier, '/profile', [
            'full_name' => 'Updated cashier', 'username' => 'forged_admin', 'role' => 'admin',
            'is_active' => '0', 'id' => $admin, 'user_id' => $admin,
            'password' => '', 'password_confirm' => '', 'current_password' => '',
        ])->assertRedirect();
        $after = $this->user($cashier);
        self::assertSame('Updated cashier', $after['full_name']);
        self::assertSame($before['username'], $after['username']);
        self::assertSame('cashier', $after['role']);
        self::assertSame(1, (int) $after['is_active']);
        self::assertSame($before['password'], $after['password']);
        self::assertSame('Test admin', $this->user($admin)['full_name']);
    }

    public function testProfilePasswordChangeRequiresCurrentPassword(): void
    {
        $id = $this->staff('cashier');
        $hash = $this->user($id)['password'];
        $this->postAs($id, '/profile', [
            'full_name' => 'Test cashier', 'current_password' => 'Incorrect current password',
            'password' => 'A replacement test passphrase 456!', 'password_confirm' => 'A replacement test passphrase 456!',
        ])->assertRedirect();
        self::assertSame($hash, $this->user($id)['password']);
        self::assertTrue(password_verify('IsolatedFixturePassword123!', $this->user($id)['password']));
    }

    public function testProfileCanChangePasswordAndDoesNotFlashIt(): void
    {
        $id = $this->staff('cashier');
        $replacement = 'A replacement test passphrase 456!';
        $this->postAs($id, '/profile', [
            'full_name' => 'Test cashier', 'current_password' => 'IsolatedFixturePassword123!',
            'password' => $replacement, 'password_confirm' => $replacement,
        ])->assertRedirect();
        $hash = $this->user($id)['password'];
        self::assertTrue(password_verify($replacement, $hash));
        self::assertFalse(password_verify('IsolatedFixturePassword123!', $hash));
        self::assertStringNotContainsString($replacement, json_encode($_SESSION, JSON_THROW_ON_ERROR));
    }

    public function testCashierHistoryOnlyShowsTheirOwnTransactions(): void
    {
        $first = $this->staff('cashier');
        $second = $this->staff('cashier');
        $this->receipt($first, 'Own transaction fixture');
        $this->receipt($second, 'Other transaction fixture');
        $response = $this->withSession(['user_id' => $first])->get('/sales');
        $response->assertStatus(200);
        self::assertStringContainsString('Own transaction fixture', $response->response()->getBody());
        self::assertStringNotContainsString('Other transaction fixture', $response->response()->getBody());
    }

    public function testReceiptOwnershipIsEnforcedAndAdministratorMayInspect(): void
    {
        $first = $this->staff('cashier');
        $second = $this->staff('cashier');
        $admin = $this->staff('admin');
        $receipt = $this->receipt($first, 'Receipt ownership fixture');
        $this->withSession(['user_id' => $first])->get('/pos/receipts/' . $receipt)->assertStatus(200);
        $blocked = $this->withSession(['user_id' => $second])->get('/pos/receipts/' . $receipt);
        self::assertContains($blocked->response()->getStatusCode(), [403, 404]);
        $this->withSession(['user_id' => $admin])->get('/pos/receipts/' . $receipt)->assertStatus(200);
    }

    private function postAs(int $id, string $path, array $fields): TestResponse
    {
        $security = service('security');
        $hash = $security->generateHash();
        $token = $security->getTokenName();
        return $this->withSession(['user_id' => $id, $token => $hash])
            ->post($path, array_merge($fields, [$token => $hash]));
    }

    private function staff(string $role): int
    {
        $this->db->table('users')->insert([
            'username' => 'qa_' . $role . '_' . bin2hex(random_bytes(4)), 'full_name' => 'Test ' . $role,
            'password' => password_hash('IsolatedFixturePassword123!', PASSWORD_DEFAULT),
            'role' => $role, 'is_active' => 1, 'created_at' => date('Y-m-d H:i:s'),
        ]);
        return (int) $this->db->insertID();
    }

    private function user(int $id): array
    {
        return $this->db->table('users')->where('id', $id)->get()->getRowArray();
    }

    private function receipt(int $staffId, string $productName): int
    {
        $now = date('Y-m-d H:i:s');
        $staff = $this->user($staffId);
        $key = bin2hex(random_bytes(32));
        $this->db->table('products')->insert(['name' => $productName, 'price' => '12.35', 'stock_quantity' => 9, 'created_at' => $now]);
        $productId = (int) $this->db->insertID();
        $this->db->table('sales')->insert([
            'product_id' => $productId, 'customer_id' => null, 'sold_by' => $staffId, 'quantity' => 1,
            'unit_price' => '12.35', 'total_price' => '12.35', 'product_name' => $productName,
            'customer_name' => null, 'staff_name' => $staff['full_name'], 'request_key' => $key, 'created_at' => $now,
        ]);
        $saleId = (int) $this->db->insertID();
        $this->db->table('receipts')->insert([
            'customer_id' => null, 'sold_by' => $staffId, 'total_price' => '12.35', 'quantity_total' => 1,
            'customer_name' => null, 'staff_name' => $staff['full_name'], 'request_key' => $key, 'created_at' => $now,
        ]);
        $receiptId = (int) $this->db->insertID();
        $this->db->table('receipt_lines')->insert(['receipt_id' => $receiptId, 'sale_id' => $saleId]);
        return $receiptId;
    }
}
