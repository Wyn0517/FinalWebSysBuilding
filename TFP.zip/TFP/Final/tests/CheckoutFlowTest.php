<?php

use App\Libraries\CheckoutService;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;

/** Checkout integration tests run against the isolated test database only. */
final class CheckoutFlowTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected $namespace = 'App';
    protected $refresh = true;
    private int $smallProductId;
    private int $productId;
    private int $customerId;
    private int $staffId;
    private CheckoutService $checkout;

    protected function setUp(): void
    {
        parent::setUp();
        $now = date('Y-m-d H:i:s');
        $this->db->table('products')->insert([
            'name' => 'Small product', 'price' => '0.10',
            'stock_quantity' => 10, 'created_at' => $now,
        ]);
        $this->smallProductId = (int) $this->db->insertID();
        $this->db->table('products')->insert([
            'name' => 'Original product', 'price' => '12.35',
            'stock_quantity' => 10, 'created_at' => $now,
        ]);
        $this->productId = (int) $this->db->insertID();
        $this->db->table('customers')->insert([
            'full_name' => 'Original customer', 'email' => 'checkout@example.test',
            'phone' => null, 'created_at' => $now,
        ]);
        $this->customerId = (int) $this->db->insertID();
        $this->db->table('users')->insert([
            'username' => 'checkout_admin', 'full_name' => 'Original staff',
            'password' => password_hash('OnlyForCheckoutTests123!', PASSWORD_DEFAULT),
            'role' => 'admin', 'is_active' => 1, 'created_at' => $now,
        ]);
        $this->staffId = (int) $this->db->insertID();
        $this->checkout = new CheckoutService($this->db);
    }

    public function testMultipleProductsCreateOneReceiptWithExactDecimalTotal(): void
    {
        $receipt = $this->record($this->cart(), $this->customerId);
        self::assertSame('25.00', $receipt['total_price']);
        self::assertSame(5, (int) $receipt['quantity_total']);
        self::assertSame($this->customerId, (int) $receipt['customer_id']);
        self::assertSame($this->staffId, (int) $receipt['sold_by']);
        self::assertSame(7, $this->stock($this->smallProductId));
        self::assertSame(8, $this->stock($this->productId));
        $this->assertCounts(1, 2, 2);
        $lines = $this->db->table('receipt_lines')->where('receipt_id', $receipt['id'])->get()->getResultArray();
        self::assertCount(2, $lines);
        $saleIds = array_column($lines, 'sale_id');
        $sales = $this->db->table('sales')->whereIn('id', $saleIds)->orderBy('product_id')->get()->getResultArray();
        self::assertSame('0.30', $this->money($sales[0]['total_price']));
        self::assertSame('24.70', $this->money($sales[1]['total_price']));
    }

    public function testCustomerIsOptionalForEveryLine(): void
    {
        $receipt = $this->record($this->cart());
        self::assertNull($receipt['customer_id']);
        self::assertNull($receipt['customer_name']);
        foreach ($this->db->table('sales')->get()->getResultArray() as $sale) {
            self::assertNull($sale['customer_id']);
            self::assertNull($sale['customer_name']);
        }
        $this->assertCounts(1, 2, 2);
    }

    public function testDuplicateProductIdsAreMergedIntoOneSaleLine(): void
    {
        $receipt = $this->record([
            ['product_id' => $this->productId, 'quantity' => 2],
            ['product_id' => $this->productId, 'quantity' => 3],
        ]);
        self::assertSame('61.75', $receipt['total_price']);
        self::assertSame(5, (int) $receipt['quantity_total']);
        self::assertSame(5, $this->stock($this->productId));
        $sale = $this->db->table('sales')->get()->getRowArray();
        self::assertSame(5, (int) $sale['quantity']);
        $this->assertCounts(1, 1, 1);
    }

    public function testEmptyOrMalformedCartIsRejectedBeforeWriting(): void
    {
        $invalidCarts = [
            [], [null], ['not-an-item'], [[]],
            [['product_id' => $this->productId]],
            [['quantity' => 1]],
            [['product_id' => $this->productId, 'quantity' => '2']],
            [['product_id' => $this->productId, 'quantity' => 2.0]],
            [['product_id' => $this->productId, 'quantity' => 2.5]],
            [['product_id' => $this->productId, 'quantity' => 0]],
            [['product_id' => $this->productId, 'quantity' => -1]],
            [['product_id' => $this->productId, 'quantity' => true]],
            [['product_id' => $this->productId, 'quantity' => [1]]],
            [['product_id' => (string) $this->productId, 'quantity' => 1]],
            [['product_id' => 0, 'quantity' => 1]],
        ];
        foreach ($invalidCarts as $items) {
            $this->assertRejected(fn () => $this->record($items));
            $this->assertCounts(0, 0, 0);
            self::assertSame(10, $this->stock($this->smallProductId));
            self::assertSame(10, $this->stock($this->productId));
        }
    }

    public function testMoreThanFiftyDistinctProductsAreRejected(): void
    {
        $items = [
            ['product_id' => $this->smallProductId, 'quantity' => 1],
            ['product_id' => $this->productId, 'quantity' => 1],
        ];
        for ($i = 0; $i < 49; $i++) {
            $this->db->table('products')->insert([
                'name' => 'Extra product ' . $i, 'price' => '0.00',
                'stock_quantity' => 1, 'created_at' => date('Y-m-d H:i:s'),
            ]);
            $items[] = ['product_id' => (int) $this->db->insertID(), 'quantity' => 1];
        }
        $this->assertRejected(fn () => $this->record($items));
        $this->assertCounts(0, 0, 0);
        self::assertSame(10, $this->stock($this->smallProductId));
        self::assertSame(10, $this->stock($this->productId));
    }

    public function testInsufficientSecondLineRollsBackTheWholeCart(): void
    {
        $this->assertRejected(fn () => $this->record([
            ['product_id' => $this->smallProductId, 'quantity' => 3],
            ['product_id' => $this->productId, 'quantity' => 11],
        ]));
        $this->assertUnchangedCart();
    }

    public function testArchivedSecondProductRollsBackTheWholeCart(): void
    {
        $this->db->table('products')->where('id', $this->productId)->update(['deleted_at' => date('Y-m-d H:i:s')]);
        $this->assertRejected(fn () => $this->record($this->cart()));
        $this->assertUnchangedCart();
    }

    public function testArchivedCustomerCannotCompleteCheckout(): void
    {
        $this->db->table('customers')->where('id', $this->customerId)->update(['deleted_at' => date('Y-m-d H:i:s')]);
        $this->assertRejected(fn () => $this->record($this->cart(), $this->customerId));
        $this->assertUnchangedCart();
    }

    public function testInactiveStaffCannotCompleteCheckout(): void
    {
        $this->db->table('users')->where('id', $this->staffId)->update(['is_active' => 0]);
        $this->assertRejected(fn () => $this->record($this->cart()));
        $this->assertUnchangedCart();
    }

    public function testRepeatedRequestReturnsOneReceiptWithoutDeductingTwice(): void
    {
        $key = bin2hex(random_bytes(32));
        $first = $this->record($this->cart(), $this->customerId, $key);
        $again = $this->record($this->cart(), $this->customerId, $key);
        self::assertSame((int) $first['id'], (int) $again['id']);
        self::assertSame('25.00', $again['total_price']);
        self::assertSame(7, $this->stock($this->smallProductId));
        self::assertSame(8, $this->stock($this->productId));
        $this->assertCounts(1, 2, 2);
    }

    public function testCheckoutUsesCurrentDatabasePrices(): void
    {
        $this->db->table('products')->where('id', $this->smallProductId)->update(['price' => '0.25']);
        $receipt = $this->record($this->cart());
        self::assertSame('25.45', $receipt['total_price']);
        $sale = $this->db->table('sales')->where('product_id', $this->smallProductId)->get()->getRowArray();
        self::assertSame('0.25', $this->money($sale['unit_price']));
        self::assertSame('0.75', $this->money($sale['total_price']));
    }

    public function testWholeReceiptTotalOverflowRollsBackEveryLine(): void
    {
        foreach ([$this->smallProductId, $this->productId] as $id) {
            $this->db->table('products')->where('id', $id)->update(['price' => '60000000.00']);
        }
        // Each line fits DECIMAL(10,2); their combined total does not.
        $this->assertRejected(fn () => $this->record([
            ['product_id' => $this->smallProductId, 'quantity' => 1],
            ['product_id' => $this->productId, 'quantity' => 1],
        ]));
        $this->assertUnchangedCart();
    }

    public function testCombinedQuantityOverflowIsRejected(): void
    {
        foreach ([$this->smallProductId, $this->productId] as $id) {
            $this->db->table('products')->where('id', $id)->update(['price' => '0.00', 'stock_quantity' => 2147483647]);
        }
        $this->assertRejected(fn () => $this->record([
            ['product_id' => $this->smallProductId, 'quantity' => 2147483647],
            ['product_id' => $this->productId, 'quantity' => 1],
        ]));
        self::assertSame(2147483647, $this->stock($this->smallProductId));
        self::assertSame(2147483647, $this->stock($this->productId));
        $this->assertCounts(0, 0, 0);
    }

    public function testReceiptAndLineSnapshotsSurviveEditsAndArchival(): void
    {
        $receipt = $this->record($this->cart(), $this->customerId);
        $deleted = date('Y-m-d H:i:s');
        $this->db->table('products')->where('id', $this->productId)->update([
            'name' => 'Changed product', 'price' => '99.00', 'deleted_at' => $deleted,
        ]);
        $this->db->table('customers')->where('id', $this->customerId)->update(['full_name' => 'Changed customer', 'deleted_at' => $deleted]);
        $this->db->table('users')->where('id', $this->staffId)->update(['full_name' => 'Changed staff', 'deleted_at' => $deleted]);
        $stored = $this->db->table('receipts')->where('id', $receipt['id'])->get()->getRowArray();
        self::assertSame('Original customer', $stored['customer_name']);
        self::assertSame('Original staff', $stored['staff_name']);
        self::assertSame('25.00', $this->money($stored['total_price']));
        $sale = $this->db->table('sales')->where('product_id', $this->productId)->get()->getRowArray();
        self::assertSame('Original product', $sale['product_name']);
        self::assertSame('Original customer', $sale['customer_name']);
        self::assertSame('Original staff', $sale['staff_name']);
        self::assertSame('12.35', $this->money($sale['unit_price']));
    }

    public function testReceiptLinkInsertFailureRollsBackReceiptSalesAndStock(): void
    {
        if ($this->db->DBDriver !== 'SQLite3') {
            self::markTestSkipped('Failure injection uses an isolated SQLite trigger.');
        }
        $table = $this->db->prefixTable('receipt_lines');
        $this->db->query('CREATE TRIGGER qa_fail_receipt_link BEFORE INSERT ON "' . $table . '" BEGIN SELECT RAISE(ABORT, \'forced receipt link failure\'); END');
        try {
            try {
                $this->record($this->cart());
                self::fail('The forced link failure must reject the whole checkout.');
            } catch (RuntimeException $exception) {
                self::assertNotSame('', $exception->getMessage());
            }
            $this->assertUnchangedCart();
        } finally {
            $this->db->query('DROP TRIGGER IF EXISTS qa_fail_receipt_link');
        }
    }

    private function cart(): array
    {
        return [
            ['product_id' => $this->smallProductId, 'quantity' => 3],
            ['product_id' => $this->productId, 'quantity' => 2],
        ];
    }

    private function record(array $items, ?int $customerId = null, ?string $key = null): array
    {
        return $this->checkout->record($items, $customerId, $this->staffId, $key ?? bin2hex(random_bytes(32)));
    }

    private function stock(int $productId): int
    {
        return (int) $this->db->table('products')->select('stock_quantity')->where('id', $productId)->get()->getRowArray()['stock_quantity'];
    }

    private function money($amount): string
    {
        return number_format((float) $amount, 2, '.', '');
    }

    private function assertCounts(int $receipts, int $sales, int $links): void
    {
        self::assertSame($receipts, $this->db->table('receipts')->countAllResults());
        self::assertSame($sales, $this->db->table('sales')->countAllResults());
        self::assertSame($links, $this->db->table('receipt_lines')->countAllResults());
    }

    private function assertUnchangedCart(): void
    {
        self::assertSame(10, $this->stock($this->smallProductId));
        self::assertSame(10, $this->stock($this->productId));
        $this->assertCounts(0, 0, 0);
    }

    private function assertRejected(callable $operation): void
    {
        try {
            $operation();
            self::fail('This checkout should have been rejected.');
        } catch (DomainException $exception) {
            self::assertNotSame('', $exception->getMessage());
        }
    }
}
