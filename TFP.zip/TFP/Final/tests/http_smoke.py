#!/usr/bin/env python3
"""Run against a disposable local installation. Creates and archives QA fixtures.

POS_QA_PASSWORD='your admin password' python3 tests/http_smoke.py \
  --base-url http://localhost:8080 --username admin

This is a real HTTP test; it requires a running PHP app and migrated database.
It never prints credentials and does not use browser-side validation.
"""

import argparse
import http.cookiejar
import json
import os
import re
import secrets
import struct
import urllib.error
import urllib.parse
import urllib.request
import zlib
from html.parser import HTMLParser


class FormFields(HTMLParser):
    def __init__(self, text):
        super().__init__()
        self.fields = {}
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        data = dict(attrs)
        if tag == "input" and "name" in data:
            self.fields[data["name"]] = data.get("value", "")


class Browser:
    def __init__(self, base):
        self.base = base.rstrip("/")
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def request(self, path, data=None):
        body = None if data is None else urllib.parse.urlencode(data).encode()
        req = urllib.request.Request(self.base + path, data=body)
        try:
            response = self.opener.open(req, timeout=20)
        except urllib.error.HTTPError as error:
            response = error
        return response.status, response.geturl(), response.read().decode("utf-8", errors="replace")

    def submit(self, path, fields, form_path):
        status, _, page = self.request(form_path)
        assert status == 200, (form_path, status)
        csrf = {k: v for k, v in FormFields(page).fields.items() if "csrf" in k.lower()}
        assert csrf, "CSRF hidden field missing"
        return self.request(path, csrf | fields)

    def submit_file(self, path, fields, form_path, field, filename, payload, mime):
        _, _, page = self.request(form_path)
        csrf = {k: v for k, v in FormFields(page).fields.items() if "csrf" in k.lower()}
        assert csrf, "CSRF hidden field missing"
        boundary = "qa" + secrets.token_hex(16)
        parts = []
        for key, value in (csrf | fields).items():
            parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n').encode())
        parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; filename="{filename}"\r\nContent-Type: {mime}\r\n\r\n').encode() + payload + b'\r\n')
        parts.append(f'--{boundary}--\r\n'.encode())
        request = urllib.request.Request(self.base + path, data=b''.join(parts), headers={"Content-Type": "multipart/form-data; boundary=" + boundary})
        try:
            response = self.opener.open(request, timeout=20)
        except urllib.error.HTTPError as error:
            response = error
        return response.status, response.geturl(), response.read().decode('utf-8', errors='replace')


def check(condition, label):
    if not condition:
        raise AssertionError(label)
    print("PASS", label)


def fixture_id(browser, route, term):
    status, _, page = browser.request(route + "?q=" + urllib.parse.quote(term))
    assert status == 200
    path = r"(?:/staff|/admin/users)" if route == "/staff" else re.escape(route)
    match = re.search(path + r"/(\d+)/edit", page)
    assert match, "Created fixture not found: " + route
    return int(match.group(1))


def stock(browser, product_id):
    status, _, page = browser.request(f"/products/{product_id}/edit")
    assert status == 200
    return int(FormFields(page).fields["stock_quantity"])


def tiny_png():
    def chunk(kind, data):
        return struct.pack('!I', len(data)) + kind + data + struct.pack('!I', zlib.crc32(kind + data) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('!2I5B', 1, 1, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(b'\x00\x71\x95\xff')) + chunk(b'IEND', b'')


def new_key(browser):
    status, _, page = browser.request("/pos")
    assert status == 200
    return FormFields(page).fields["request_key"]


def checkout(browser, items, customer="", key=None, **extra):
    payload = {"cart": json.dumps(items), "customer_id": customer, "request_key": key or new_key(browser)} | extra
    return browser.submit("/pos/checkout", payload, "/pos")


def receipt_id(url):
    found = re.search(r"/pos/receipts/(\d+)$", url)
    assert found, "Checkout did not redirect to a receipt"
    return int(found.group(1))


def contains_receipt(page, identifier):
    return bool(re.search(r'href=[\"\'][^\"\']*/pos/receipts/' + str(identifier) + r'[\"\']', page))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://localhost:8080")
    parser.add_argument("--username", required=True)
    args = parser.parse_args()
    password = os.environ.get("POS_QA_PASSWORD")
    if not password:
        parser.error("Set POS_QA_PASSWORD to a disposable installation administrator password.")

    admin = Browser(args.base_url)
    status, url, _ = admin.request("/pos")
    check(status == 200 and "/login" in url, "Unauthenticated checkout redirects to sign in")
    status, _, page = admin.submit("/login", {"username": args.username, "password": password + "-incorrect"}, "/login")
    check(status == 200 and "incorrect" in page.lower(), "Invalid credentials are rejected")
    status, url, _ = admin.submit("/login", {"username": args.username, "password": password}, "/login")
    check(status == 200 and url.endswith("/admin/dashboard"), "Administrator login redirects to the business dashboard")
    for path in ["/products", "/products/new", "/customers", "/customers/new", "/staff", "/staff/new", "/admin/dashboard", "/admin/products", "/admin/customers", "/admin/users", "/admin/sales", "/sales", "/sales/new", "/pos", "/profile"]:
        check(admin.request(path)[0] == 200, "Administrator page responds: " + path)

    suffix = secrets.token_hex(5)
    name = "QA product A " + suffix
    second_name = "QA product B " + suffix
    customer = "QA customer " + suffix
    product_id = second_id = customer_id = staff_id = None
    admin_receipt = cashier_receipt = None
    try:
        status, _, _ = admin.submit("/products", {"name": name, "price": "-1", "stock_quantity": "7"}, "/products/new")
        check(status == 200 and name not in admin.request("/products?q=" + urllib.parse.quote(name))[2], "Negative product price is rejected")
        for product_name, price, units in [(name, "12.35", "7"), (second_name, "2.40", "3")]:
            status, url, _ = admin.submit("/products", {"name": product_name, "price": price, "stock_quantity": units}, "/products/new")
            check(status == 200 and "/new" not in url, "Create product: " + product_name)
        product_id = fixture_id(admin, "/products", name)
        second_id = fixture_id(admin, "/products", second_name)
        check((stock(admin, product_id), stock(admin, second_id)) == (7, 3), "Both product stocks are stored")
        product_fields = {"name": name, "price": "12.35", "stock_quantity": "7", "stock_original": "7"}
        status, url, _ = admin.submit_file(f"/products/{product_id}", product_fields, f"/products/{product_id}/edit", "image", "invalid.php", b'<?php echo "invalid"; ?>', "application/x-php")
        check(status == 200 and "/edit" in url, "Executable product upload is rejected")
        status, url, _ = admin.submit_file(f"/products/{product_id}", product_fields, f"/products/{product_id}/edit", "image", "qa.png", tiny_png(), "image/png")
        check(status == 200 and "/edit" not in url, "Valid product image is normalized and saved")
        _, _, product_page = admin.request(f"/products/{product_id}/edit")
        media = re.search(r'/media/([a-f0-9]{32}\.(?:jpg|png))', product_page)
        check(bool(media), "Product image has a generated protected-media filename")
        if media:
            response = admin.opener.open(admin.base + media.group(0), timeout=20)
            check(response.status == 200 and response.headers.get_content_type() == "image/png" and response.read().startswith(b'\x89PNG'), "Normalized image displays as PNG")
        admin.submit("/customers", {"full_name": customer, "email": suffix + "@example.test", "phone": "09123456789"}, "/customers/new")
        customer_id = fixture_id(admin, "/customers", suffix)
        admin.submit(f"/customers/{customer_id}", {"full_name": customer, "email": suffix + "@example.test", "phone": "09987654321"}, f"/customers/{customer_id}/edit")
        check("09987654321" in admin.request(f"/customers/{customer_id}/edit")[2], "Customer create and update work")

        staff_password = secrets.token_urlsafe(24)
        staff_name = "QA staff " + suffix
        staff_fields = {"username": "qa_" + suffix, "full_name": staff_name, "password": staff_password, "password_confirm": staff_password, "role": "cashier", "is_active": "1"}
        status, url, _ = admin.submit_file("/staff", staff_fields, "/staff/new", "avatar", "qa.png", tiny_png(), "image/png")
        check(status == 200 and "/new" not in url, "Create cashier with a valid avatar")
        staff_id = fixture_id(admin, "/staff", suffix)
        _, _, staff_page = admin.request(f"/staff/{staff_id}/edit")
        check(staff_password not in staff_page and bool(re.search(r'/media/[a-f0-9]{32}\.png', staff_page)), "Staff password is hidden and avatar uses protected media")
        check("/new" in admin.submit("/staff", staff_fields, "/staff/new")[1], "Duplicate username is rejected")

        cashier = Browser(args.base_url)
        status, url, _ = cashier.submit("/login", {"username": staff_fields["username"], "password": staff_password}, "/login")
        check(status == 200 and url.endswith("/pos"), "Cashier login redirects to checkout")
        for path in ["/products", "/products/new", "/customers", "/staff", "/admin/dashboard", "/admin/products", "/admin/customers", "/admin/users", "/admin/sales"]:
            check(cashier.request(path)[0] == 403, "Cashier cannot access management URL: " + path)
        for path in ["/products", f"/products/{product_id}", f"/products/{product_id}/delete", "/customers", f"/customers/{customer_id}/delete", "/staff", f"/staff/{staff_id}", "/admin/products", "/admin/customers", "/admin/users"]:
            status, _, _ = cashier.submit(path, {"role": "admin", "name": "Forbidden change"}, "/pos")
            check(status == 403, "Valid-CSRF forged management POST is blocked: " + path)
        check((stock(admin, product_id), stock(admin, second_id)) == (7, 3), "Blocked management posts do not change inventory")

        profile_name = "QA cashier profile " + suffix
        _, _, profile = cashier.submit("/profile", {"full_name": profile_name, "role": "admin", "username": "forged_admin", "is_active": "0", "id": "1", "user_id": "1", "password": "", "password_confirm": "", "current_password": ""}, "/profile")
        check(profile_name in profile and cashier.request("/admin/dashboard")[0] == 403, "Profile edit ignores forged account IDs and privileges")
        _, _, staff_page = admin.request(f"/staff/{staff_id}/edit")
        check(FormFields(staff_page).fields.get("username") == staff_fields["username"] and profile_name in staff_page, "Only the cashier's own permitted profile fields changed")
        probe = Browser(args.base_url)
        check(probe.submit("/login", {"username": staff_fields["username"], "password": staff_password}, "/login")[1].endswith("/pos"), "A blank profile password preserves the existing password")
        new_password = secrets.token_urlsafe(24)
        cashier.submit("/profile", {"full_name": profile_name, "current_password": "wrong", "password": new_password, "password_confirm": new_password}, "/profile")
        check(staff_password not in cashier.request("/profile")[2] and new_password not in cashier.request("/profile")[2], "Profile validation never redisplays password values")
        cashier.submit("/profile", {"full_name": profile_name, "current_password": staff_password, "password": new_password, "password_confirm": new_password}, "/profile")
        probe = Browser(args.base_url)
        check(probe.submit("/login", {"username": staff_fields["username"], "password": new_password}, "/login")[1].endswith("/pos"), "Current-password verification permits a legitimate password change")
        staff_password = new_password

        status, url, page = checkout(admin, [{"product_id": product_id, "quantity": 1}, {"product_id": second_id, "quantity": 1}], customer_id)
        admin_receipt = receipt_id(url)
        check(status == 200 and "14.75" in page and name in page and second_name in page, "Administrator multi-product receipt records both lines and the correct total")
        check(cashier.request(f"/pos/receipts/{admin_receipt}")[0] in [403, 404], "Cashier cannot inspect another staff member's receipt")
        key = new_key(cashier)
        cart = [{"product_id": product_id, "quantity": 2, "price": "0.01"}, {"product_id": second_id, "quantity": 1, "unit_price": "0.01"}]
        status, url, page = checkout(cashier, cart, customer_id, key, total_price="0.01", sold_by="1", role="admin")
        cashier_receipt = receipt_id(url)
        check(status == 200 and "27.10" in page and customer in page and profile_name in page, "Checkout ignores forged prices, totals and staff fields")
        check((stock(admin, product_id), stock(admin, second_id)) == (4, 1), "Multi-product checkout deducts each exact quantity")
        check(admin.request(f"/pos/receipts/{cashier_receipt}")[0] == 200, "Administrator can inspect a cashier receipt")
        status, repeat_url, _ = checkout(cashier, cart, customer_id, key)
        check(status == 200 and receipt_id(repeat_url) == cashier_receipt and (stock(admin, product_id), stock(admin, second_id)) == (4, 1), "Repeated multi-product submission returns the original receipt without deductions")
        _, _, own_history = cashier.request("/sales")
        check(contains_receipt(own_history, cashier_receipt) and not contains_receipt(own_history, admin_receipt), "Cashier history contains only their permitted receipt")
        _, _, all_history = admin.request("/admin/sales")
        check(contains_receipt(all_history, cashier_receipt) and contains_receipt(all_history, admin_receipt), "Administrator history includes both staff members' receipts")

        for quantity in [0, -1, 1.5, "abc", 999999999]:
            status, url, _ = checkout(cashier, [{"product_id": product_id, "quantity": quantity}])
            check(status == 200 and url.endswith("/pos") and (stock(admin, product_id), stock(admin, second_id)) == (4, 1), "Invalid cart quantity leaves inventory unchanged: " + str(quantity))
        for malformed in ["not json", "[]", "{}"]:
            cashier.submit("/pos/checkout", {"cart": malformed, "customer_id": "", "request_key": new_key(cashier)}, "/pos")
            check((stock(admin, product_id), stock(admin, second_id)) == (4, 1), "Malformed cart payload is rejected: " + malformed)
        checkout(cashier, [{"product_id": product_id, "quantity": 1}], "2147483647")
        check(stock(admin, product_id) == 4, "Unavailable customer causes a complete rollback")
        checkout(cashier, [{"product_id": product_id, "quantity": 1}], key=secrets.token_hex(32))
        check(stock(admin, product_id) == 4, "Unissued checkout key cannot record a sale")

        stale_key = new_key(cashier)
        admin.submit(f"/products/{second_id}", {"name": second_name, "price": "2.40", "stock_quantity": "0", "stock_original": "1"}, f"/products/{second_id}/edit")
        status, url, _ = checkout(cashier, [{"product_id": product_id, "quantity": 1}, {"product_id": second_id, "quantity": 1}], key=stale_key)
        check(status == 200 and url.endswith("/pos") and (stock(admin, product_id), stock(admin, second_id)) == (4, 0), "Stale second-product stock rolls back the first-product deduction")
        admin.submit(f"/products/{second_id}", {"name": second_name, "price": "2.40", "stock_quantity": "1", "stock_original": "0"}, f"/products/{second_id}/edit")

        status, _, _ = cashier.request("/pos/checkout", {"cart": json.dumps([{ "product_id": product_id, "quantity": 1}]), "request_key": new_key(cashier)})
        check(status in [400, 403] and stock(admin, product_id) == 4, "Checkout without a CSRF token is rejected")
        staff_update = staff_fields | {"full_name": profile_name, "password": "", "password_confirm": "", "is_active": "0"}
        admin.submit(f"/staff/{staff_id}", staff_update, f"/staff/{staff_id}/edit")
        check("/login" in cashier.request("/pos")[1], "Disabling an account immediately revokes its active checkout session")
    finally:
        if staff_id:
            admin.submit(f"/staff/{staff_id}/delete", {}, "/staff")
        if customer_id:
            admin.submit(f"/customers/{customer_id}/delete", {}, "/customers")
        for identifier in [product_id, second_id]:
            if identifier:
                admin.submit(f"/products/{identifier}/delete", {}, "/products")
    if cashier_receipt:
        status, _, page = admin.request(f"/pos/receipts/{cashier_receipt}")
        check(status == 200 and name in page and second_name in page and customer in page and profile_name in page, "Receipt snapshots remain readable after related records are archived")
    admin.submit("/logout", {}, "/admin/dashboard")
    check("/login" in admin.request("/admin/dashboard")[1], "Logout ends access to protected management")
    print("HTTP smoke checks completed; archived QA fixtures and their receipts remain in this disposable database.")


if __name__ == "__main__":
    main()
