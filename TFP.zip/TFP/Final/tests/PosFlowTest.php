<?php

use App\Libraries\SaleService;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;

/** Database-backed checks; use the isolated SQLite tests group, never live data. */
final class PosFlowTest extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected $namespace = 'App';
    protected $refresh = true;
    private int $productId;
    private int $customerId;
    private int $staffId;
    private SaleService $sales;

    protected function setUp(): void
    {
        parent::setUp();
        $now = date('Y-m-d H:i:s');
        $this->db->table('products')->insert([
            'name' => 'Original product', 'price' => '12.35',
            'stock_quantity' => 10, 'created_at' => $now,
        ]);
        $this->productId = (int) $this->db->insertID();
        $this->db->table('customers')->insert([
            'full_name' => 'Original customer', 'email' => 'customer@example.test',
            'phone' => null, 'created_at' => $now,
        ]);
        $this->customerId = (int) $this->db->insertID();
        $this->db->table('users')->insert([
            'username' => 'test_admin', 'full_name' => 'Original staff',
            'password' => password_hash('OnlyForIsolatedTests123!', PASSWORD_DEFAULT),
            'role' => 'admin', 'is_active' => 1, 'created_at' => $now,
        ]);
        $this->staffId = (int) $this->db->insertID();
        $this->sales = new SaleService($this->db);
    }

    public function testSaleUsesDatabasePriceAndDeductsExactStock(): void
    {
        $sale = $this->record(3, $this->customerId);
        self::assertSame('37.05', $sale['total_price']);
        self::assertSame('12.35', $sale['unit_price']);
        self::assertSame($this->staffId, $sale['sold_by']);
        self::assertSame(7, $this->stock());
        self::assertSame(1, $this->db->table('sales')->countAllResults());
    }

    public function testWalkInCustomerIsOptional(): void
    {
        $sale = $this->record(1);
        self::assertNull($sale['customer_id']);
        self::assertNull($sale['customer_name']);
        self::assertSame(9, $this->stock());
    }

    public function testSmallDecimalPriceIsCalculatedExactly(): void
    {
        $this->db->table('products')->where('id', $this->productId)->update(['price' => '0.10']);
        self::assertSame('0.30', $this->record(3)['total_price']);
    }

    public function testZeroPriceIsAValidSale(): void
    {
        $this->db->table('products')->where('id', $this->productId)->update(['price' => '0.00']);
        self::assertSame('0.00', $this->record(2)['total_price']);
        self::assertSame(8, $this->stock());
    }

    public function testInsufficientStockDoesNotWriteAnything(): void
    {
        $this->assertRejected(fn () => $this->record(11));
        self::assertSame(10, $this->stock());
        self::assertSame(0, $this->db->table('sales')->countAllResults());
    }

    public function testNonpositiveQuantitiesAreRejected(): void
    {
        foreach ([0, -1, -2147483648] as $quantity) {
            $this->assertRejected(fn () => $this->record($quantity));
        }
        self::assertSame(10, $this->stock());
        self::assertSame(0, $this->db->table('sales')->countAllResults());
    }

    public function testInvalidRequestKeyIsRejected(): void
    {
        $this->assertRejected(fn () => $this->sales->record($this->productId, null, $this->staffId, 1, 'invalid'));
        self::assertSame(10, $this->stock());
    }

    public function testRepeatedSubmissionReturnsOneSale(): void
    {
        $key = bin2hex(random_bytes(32));
        $first = $this->record(3, null, $key);
        $again = $this->record(3, null, $key);
        self::assertSame((int) $first['id'], (int) $again['id']);
        self::assertSame(7, $this->stock());
        self::assertSame(1, $this->db->table('sales')->countAllResults());
    }

    public function testArchivedProductCannotBeSold(): void
    {
        $this->db->table('products')->where('id', $this->productId)->update(['deleted_at' => date('Y-m-d H:i:s')]);
        $this->assertRejected(fn () => $this->record(1));
        self::assertSame(10, $this->stock());
    }

    public function testUnavailableCustomerRollsBackStock(): void
    {
        $this->db->table('customers')->where('id', $this->customerId)->update(['deleted_at' => date('Y-m-d H:i:s')]);
        $this->assertRejected(fn () => $this->record(2, $this->customerId));
        self::assertSame(10, $this->stock());
        self::assertSame(0, $this->db->table('sales')->countAllResults());
    }

    public function testInactiveStaffCannotCompleteSale(): void
    {
        $this->db->table('users')->where('id', $this->staffId)->update(['is_active' => 0]);
        $this->assertRejected(fn () => $this->record(2));
        self::assertSame(10, $this->stock());
    }

    public function testMaximumTotalOverflowRollsBackStock(): void
    {
        $this->db->table('products')->where('id', $this->productId)->update(['price' => '99999999.99']);
        $this->assertRejected(fn () => $this->record(2));
        self::assertSame(10, $this->stock());
    }

    public function testReceiptsRetainOriginalNamesAfterEditsAndArchival(): void
    {
        $sale = $this->record(1, $this->customerId);
        $deleted = date('Y-m-d H:i:s');
        $this->db->table('products')->where('id', $this->productId)->update(['name' => 'Changed product', 'price' => '99.00', 'deleted_at' => $deleted]);
        $this->db->table('customers')->where('id', $this->customerId)->update(['full_name' => 'Changed customer', 'deleted_at' => $deleted]);
        $this->db->table('users')->where('id', $this->staffId)->update(['full_name' => 'Changed staff', 'deleted_at' => $deleted]);
        $stored = $this->db->table('sales')->where('id', $sale['id'])->get()->getRowArray();
        self::assertSame('Original product', $stored['product_name']);
        self::assertSame('Original customer', $stored['customer_name']);
        self::assertSame('Original staff', $stored['staff_name']);
        self::assertSame('12.35', number_format((float) $stored['unit_price'], 2, '.', ''));
    }

    public function testDatabaseInsertFailureRollsBackInventory(): void
    {
        if ($this->db->DBDriver !== 'SQLite3') {
            self::markTestSkipped('Failure injection uses an isolated SQLite trigger.');
        }
        $table = $this->db->prefixTable('sales');
        $this->db->query('CREATE TRIGGER qa_fail_sale BEFORE INSERT ON "' . $table . '" BEGIN SELECT RAISE(ABORT, \'forced test failure\'); END');
        try {
            try {
                $this->record(4);
                self::fail('The forced insert failure must reject the sale.');
            } catch (RuntimeException $e) {
                self::assertNotSame('', $e->getMessage());
            }
            self::assertSame(10, $this->stock());
            self::assertSame(0, $this->db->table('sales')->countAllResults());
        } finally {
            $this->db->query('DROP TRIGGER IF EXISTS qa_fail_sale');
        }
    }

    private function record(int $quantity, ?int $customerId = null, ?string $key = null): array
    {
        return $this->sales->record($this->productId, $customerId, $this->staffId, $quantity, $key ?? bin2hex(random_bytes(32)));
    }

    private function stock(): int
    {
        return (int) $this->db->table('products')->select('stock_quantity')->where('id', $this->productId)->get()->getRowArray()['stock_quantity'];
    }

    private function assertRejected(callable $operation): void
    {
        try {
            $operation();
            self::fail('This sale should have been rejected.');
        } catch (DomainException $e) {
            self::assertNotSame('', $e->getMessage());
        }
    }
}
