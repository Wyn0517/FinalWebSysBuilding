"""SQLite transaction-strategy experiments; this does NOT execute PHP or CodeIgniter."""
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import sqlite3


class Rejected(Exception):
    pass


def main():
    with TemporaryDirectory(prefix='pos-sql-') as temporary:
        path = Path(temporary) / 'atomicity.sqlite'

        def connect():
            database = sqlite3.connect(path, timeout=20)
            database.execute('PRAGMA foreign_keys=ON')
            return database

        with connect() as database:
            database.executescript('''
                CREATE TABLE products(id INTEGER PRIMARY KEY, stock_quantity INTEGER NOT NULL CHECK(stock_quantity>=0), price DECIMAL(10,2) NOT NULL, deleted_at TEXT);
                CREATE TABLE users(id INTEGER PRIMARY KEY);
                CREATE TABLE receipts(id INTEGER PRIMARY KEY, sold_by INTEGER NOT NULL REFERENCES users(id), total_price DECIMAL(10,2), quantity_total INTEGER, request_key TEXT NOT NULL UNIQUE);
                CREATE TABLE sales(id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id), sold_by INTEGER NOT NULL REFERENCES users(id), quantity INTEGER NOT NULL, total_price DECIMAL(10,2), request_key TEXT NOT NULL UNIQUE);
                CREATE TABLE receipt_lines(id INTEGER PRIMARY KEY, receipt_id INTEGER NOT NULL REFERENCES receipts(id), sale_id INTEGER NOT NULL UNIQUE REFERENCES sales(id));
                INSERT INTO products VALUES(1,10,12.35,NULL),(2,6,2.40,NULL);
                INSERT INTO users VALUES(1);
            ''')

        def counts():
            with connect() as database:
                return {
                    'stock': [row[0] for row in database.execute('SELECT stock_quantity FROM products ORDER BY id')],
                    'receipts': database.execute('SELECT count(*) FROM receipts').fetchone()[0],
                    'sales': database.execute('SELECT count(*) FROM sales').fetchone()[0],
                    'links': database.execute('SELECT count(*) FROM receipt_lines').fetchone()[0],
                }

        def reset(stock=(10, 6)):
            with connect() as database:
                database.executescript('DELETE FROM receipt_lines; DELETE FROM receipts; DELETE FROM sales;')
                database.executemany('UPDATE products SET stock_quantity=? WHERE id=?', [(stock[0], 1), (stock[1], 2)])

        def checkout(key, items=((1, 1), (2, 1))):
            database = connect()
            try:
                database.execute('BEGIN')
                prices = []
                for product, quantity in sorted(items):
                    changed = database.execute('UPDATE products SET stock_quantity=stock_quantity-? WHERE id=? AND deleted_at IS NULL AND stock_quantity>=?', (quantity, product, quantity)).rowcount
                    if changed != 1:
                        raise Rejected('stock')
                    price = database.execute('SELECT price FROM products WHERE id=?', (product,)).fetchone()[0]
                    cents = int(Decimal(str(price)) * 100)
                    prices.append((product, quantity, cents * quantity))
                total = sum(line[2] for line in prices)
                amount = lambda cents: f'{cents // 100}.{cents % 100:02}'
                receipt = database.execute('INSERT INTO receipts(sold_by,total_price,quantity_total,request_key) VALUES(1,?,?,?)', (amount(total), sum(line[1] for line in prices), key)).lastrowid
                for product, quantity, subtotal in prices:
                    sale = database.execute('INSERT INTO sales(product_id,sold_by,quantity,total_price,request_key) VALUES(?,1,?,?,?)', (product, quantity, amount(subtotal), key + '-' + str(product))).lastrowid
                    database.execute('INSERT INTO receipt_lines(receipt_id,sale_id) VALUES(?,?)', (receipt, sale))
                database.commit()
                return 'recorded'
            except Rejected:
                database.rollback()
                return 'stock-rejected'
            except sqlite3.IntegrityError:
                database.rollback()
                return 'constraint-rolled-back'
            finally:
                database.close()

        with ThreadPoolExecutor(max_workers=12) as executor:
            results = list(executor.map(checkout, [str(i) for i in range(32)]))
        competing = counts()
        assert competing == {'stock': [4, 0], 'receipts': 6, 'sales': 12, 'links': 12}, competing
        assert results.count('recorded') == 6

        reset()
        with ThreadPoolExecutor(max_workers=8) as executor:
            retries = list(executor.map(checkout, ['same-key'] * 8))
        duplicate = counts()
        assert duplicate == {'stock': [9, 5], 'receipts': 1, 'sales': 2, 'links': 2}, duplicate
        assert retries.count('recorded') == 1

        reset((10, 0))
        before = counts()
        assert checkout('insufficient-second') == 'stock-rejected'
        assert counts() == before, 'The first product deduction must roll back when the second product has no stock.'

        reset()
        with connect() as database:
            database.executescript('''
                CREATE TRIGGER fail_second_link BEFORE INSERT ON receipt_lines
                WHEN (SELECT product_id FROM sales WHERE id=NEW.sale_id)=2
                BEGIN SELECT RAISE(ABORT,'forced second line failure'); END;
            ''')
        before = counts()
        assert checkout('forced-second-line') == 'constraint-rolled-back'
        assert counts() == before, 'Both products, header, sales and receipt links must roll back together.'
        with connect() as database:
            database.execute('DROP TRIGGER fail_second_link')

        # Retain the original single-product concurrent stock experiment too.
        reset()
        with ThreadPoolExecutor(max_workers=12) as executor:
            legacy = list(executor.map(lambda key: checkout(key, ((1, 1),)), ['single-' + str(i) for i in range(32)]))
        single = counts()
        assert single == {'stock': [0, 6], 'receipts': 10, 'sales': 10, 'links': 10}, single
        assert legacy.count('recorded') == 10

        print(json.dumps({
            'scope': 'SQLite SQL transaction strategy only; PHP application and CodeIgniter driver not executed',
            'single_product': {'parallel_buyers': 32, 'initial_stock': 10, 'receipts': 10, 'remaining_stock': 0},
            'multi_product': {'parallel_carts': 32, 'initial_stock': [10, 6], 'completed_receipts': 6, 'sale_lines': 12, 'remaining_stock': [4, 0]},
            'duplicate_cart': {'parallel_attempts': 8, 'completed_receipts': 1, 'sale_lines': 2, 'remaining_stock': [9, 5]},
            'insufficient_second_product': 'first deduction rolled back; no receipt or sales persisted',
            'forced_second_line_failure': 'all deductions, receipt header, sales and links rolled back',
            'result': 'PASS',
        }, indent=2))


if __name__ == '__main__':
    main()
