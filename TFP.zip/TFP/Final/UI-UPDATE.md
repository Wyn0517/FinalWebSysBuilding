# Apply the reference layout update

This update uses your dashboard and expanded/compact sidebar screenshots as the layout reference. It keeps Counterpoint's **Graphite + Cobalt** dark and **Porcelain + Cobalt** light themes, with a restrained frosted finish. Revenue, the chart, store summary, recent sale items and stock attention now form one organized dashboard. Finance-specific wallet and credit data from the reference are replaced by actual POS information.

The four requested principles guide the implementation:

| Principle | Application |
| --- | --- |
| Simplicity | One main New sale action; compact quick links; fewer repeated labels; checkout focused on products and the current order. |
| Consistency | Shared controls, spacing, icons, field sizes, state colors and button styles across both themes. |
| Visual hierarchy | Today's revenue leads; the revenue chart is central; store details and recent activity remain secondary. |
| Feedback | Visible cart outcomes, one screen-reader announcement channel, loading labels/spinner, stock errors, selected products and existing success/error notices. |

## Preview before updating

Inside **TFP/Final**, open **UI-PREVIEW.html** directly in Chrome. No PHP server or sign-in is needed. The preview embeds the actual current views, CSS and scripts with sample fixtures. Use its page and theme buttons, collapse the sidebar and try the cart. Forms cannot sign in, record sales or change your database. This fixture preview does not execute PHP.

## Update your existing installation

1. Stop the server and back up your current `C:\xampp\htdocs\Final` folder.
2. Extract the new ZIP in a separate location. Open its `TFP\Final` folder.
3. Copy **app** and **public** into your existing `C:\xampp\htdocs\Final`, merging and replacing files when Windows asks. Copy tests/docs too if you maintain those locally.
4. **Keep your current `.env` and entire `writable` folder.** They hold settings, the database, accounts and uploads.
5. This interface update adds no migration. If your installation already has the multi-product cart and receipts, use your existing account and database.
6. In VS Code's PowerShell terminal, run:

   ```powershell
   cd C:\xampp\htdocs\Final
   & "C:\xampp\php\php.exe" .\spark serve --host 127.0.0.1 --port 8080
   ```

7. Open **http://localhost:8080/login** and press **Ctrl+F5** to load the new assets.

If upgrading from an older release without cart/receipt tables, first apply the retained additive migration once:

```powershell
& "C:\xampp\php\php.exe" .\spark migrate --all
```

Inspect any migration error before continuing. Keep the existing database; do not reset or delete it.

## What to try

- On desktop, use the single menu button at the top of the sidebar. The duplicate button beside Workspace in the header has been removed from desktop view. It switches between an expanded menu and an **icon rail**, keeping all destinations available. Hover over or keyboard-focus a rail icon for its label. The menu scrolls independently when space is limited; Checkout and your account stay in the bottom section. Your desktop choice is remembered; older saved visibility choices are mapped to the new states.
- On mobile, the header menu button opens a separate drawer; it hides while the drawer is open. Close the drawer using its X button, Escape or the dimmed area outside. Focus stays inside the open drawer and returns to the header button on dismissal.
- Explore the revenue card and its transaction/unit/product links. Choose **7**, **14** or **30 days** for the chart; focus or hover a day for the exact amount, or open it to see its sales. Long charts scroll within their panel.
- Use store-summary quick links, recent sale-item receipt links and low-stock inventory links.
- Search products by name or ID such as **#12**, use the stock filters, or press **F2** to focus search. Clear-search and selected-product feedback remain.
- Add products, change quantities, remove a line and clear the order. One inline status describes each outcome; errors replace stale success feedback. Checkout displays **Recording sale…** while submitting.
- Check both themes, forms, tables, receipts and profile. Inputs and menus remain readable; reduced motion/transparency preferences have fallbacks.

## Layout correction in this package

The sidebar now uses three constrained rows: its header, a scrollable navigation region, and a separate footer. This fixes Checkout/account controls extending outside the rounded sidebar. Icon labels render outside the scrolling region and dismiss when scrolling, resizing or changing modes. The old tooltip CSS was removed.

The desktop header no longer repeats the sidebar menu button. Mobile uses a header opener and a drawer X close control, with only one shown at a time.

Additional fixes protect long product names/prices, arrange small-screen cart amounts/actions on a separate row, and keep the account dropdown scrollable inside shorter viewports. The existing palette, checkout flow, roles, accounts and database behavior are retained.

## Verification

**34 JavaScript tests passed:** 17 shared-controller tests and 17 cart/search/feedback tests. Preview guards, embedded-script syntax, structural CSS and source-preservation checks passed. All 73 non-view PHP application files are unchanged. PHP execution, real browser rendering and MySQL remain unverified here; see **docs/VERIFICATION.md**.
