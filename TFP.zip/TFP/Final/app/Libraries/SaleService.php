<?php

namespace App\Libraries;

use CodeIgniter\Database\BaseConnection;
use DomainException;
use RuntimeException;
use Throwable;

/** A single transaction owns both the inventory deduction and the immutable sale. */
class SaleService
{
    public function __construct(private ?BaseConnection $db = null)
    {
        $this->db ??= db_connect();
    }

    public function record(int $productId, ?int $customerId, int $staffId, int $quantity, string $requestKey): array
    {
        if ($productId < 1 || $staffId < 1 || ($customerId !== null && $customerId < 1)
            || $quantity < 1 || $quantity > 2147483647 || !preg_match('/^[a-f0-9]{64}$/D', $requestKey)) {
            throw new DomainException('Choose a valid product, customer and whole-number quantity.');
        }

        if ($existing = $this->existing($requestKey, $staffId)) {
            return $existing;
        }

        try {
            $this->db->resetTransStatus();
            if (!$this->db->transBegin()) {
                throw new RuntimeException('Transaction start failed');
            }
        } catch (Throwable $e) {
            log_message('error', 'A sale transaction could not be started.');
            throw new RuntimeException('The sale could not be started. Please try again.');
        }

        try {
            // Start with a write, avoiding SQLite read-to-write upgrade races. InnoDB
            // locks this product row; SQLite serializes writers. The predicate is
            // evaluated by the database after any competing writer has finished.
            $updated = $this->db->table('products')
                ->where('id', $productId)->where('deleted_at', null)
                ->where('stock_quantity >=', $quantity)
                ->set('stock_quantity', 'stock_quantity - ' . $quantity, false)
                ->set('updated_at', date('Y-m-d H:i:s'))->update();

            if (!$updated) {
                throw new RuntimeException('Inventory could not be updated. Please try again.');
            }
            if ($this->db->affectedRows() !== 1) {
                throw new DomainException('Insufficient stock, or this product is no longer available. Refresh and check the available quantity.');
            }

            $product = $this->db->table('products')->where('id', $productId)->get()->getRowArray();
            $staff = $this->db->table('users')->where('id', $staffId)->where('deleted_at', null)
                ->where('is_active', 1)->get()->getRowArray();
            if (!$staff) {
                throw new DomainException('Your account is no longer active. Sign in again.');
            }
            $customer = null;
            if ($customerId !== null) {
                $customer = $this->db->table('customers')->where('id', $customerId)
                    ->where('deleted_at', null)->get()->getRowArray();
                if (!$customer) {
                    throw new DomainException('That customer is no longer available. Choose another customer or use walk-in.');
                }
            }

            $unitCents = self::cents((string) $product['price']);
            // Division avoids overflowing a PHP integer before checking DECIMAL(10,2).
            if ($unitCents > 0 && $quantity > intdiv(9999999999, $unitCents)) {
                throw new DomainException('This sale exceeds the maximum transaction total of ₱99,999,999.99. Reduce the quantity.');
            }
            $totalCents = $unitCents * $quantity;
            $sale = [
                'product_id' => $productId, 'customer_id' => $customerId,
                'sold_by' => $staffId, 'quantity' => $quantity,
                'unit_price' => self::decimal($unitCents),
                'total_price' => self::decimal($totalCents),
                'product_name' => $product['name'],
                'customer_name' => $customer['full_name'] ?? null,
                'staff_name' => $staff['full_name'],
                'request_key' => $requestKey, 'created_at' => date('Y-m-d H:i:s'),
            ];
            if (!$this->db->table('sales')->insert($sale) || !$this->db->transStatus()) {
                throw new RuntimeException('The sale could not be saved. No inventory was deducted.');
            }
            $sale['id'] = $this->db->insertID();
            if (!$this->db->transCommit()) {
                throw new RuntimeException('The sale could not be completed. Please check sales history before retrying.');
            }
            return $sale;
        } catch (Throwable $e) {
            try {
                $this->db->transRollback();
                $this->db->resetTransStatus();
            } catch (Throwable $rollbackError) {
                log_message('error', 'The database connection was interrupted during sale recovery.');
                throw new RuntimeException('The sale could not be confirmed. Check sales history before retrying.');
            }
            // A simultaneous retry may have won the unique request_key constraint.
            if ($existing = $this->existing($requestKey, $staffId)) {
                return $existing;
            }
            if ($e instanceof DomainException) {
                throw $e;
            }
            log_message('error', 'A sale transaction failed; database recovery was requested.');
            throw new RuntimeException('The sale could not be confirmed. Check sales history before retrying.');
        }
    }

    private function existing(string $key, int $staffId): ?array
    {
        try {
            $result = $this->db->table('sales')->where('request_key', $key)->where('sold_by', $staffId)->get();
            if ($result === false) {
                throw new RuntimeException('Sales lookup failed');
            }
            return $result->getRowArray();
        } catch (Throwable $e) {
            log_message('error', 'A sale submission could not be checked against sales history.');
            throw new RuntimeException('Sales history is temporarily unavailable. Check it before retrying this sale.');
        }
    }

    private static function cents(string $value): int
    {
        if (!preg_match('/^(\d{1,8})(?:\.(\d{1,2}))?$/D', $value, $parts)) {
            throw new DomainException('The product price is invalid. Ask an administrator to correct it.');
        }
        return ((int) $parts[1] * 100) + (int) str_pad($parts[2] ?? '', 2, '0');
    }

    private static function decimal(int $cents): string
    {
        return intdiv($cents, 100) . '.' . str_pad((string) ($cents % 100), 2, '0', STR_PAD_LEFT);
    }
}
