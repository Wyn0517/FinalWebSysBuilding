<?php

namespace App\Libraries;

use CodeIgniter\HTTP\Files\UploadedFile;
use InvalidArgumentException;
use RuntimeException;

/** Normalizes accepted raster images into fresh, display-ready files outside public/. */
class ImageUpload
{
    public function store(?UploadedFile $file): ?string
    {
        if ($file === null || $file->getError() === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if (!$file->isValid() || $file->getSize() > 2 * 1024 * 1024) {
            throw new InvalidArgumentException('Choose a valid image no larger than 2 MB.');
        }
        $extensions = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];
        $extension = strtolower($file->getClientExtension());
        if (!isset($extensions[$extension]) || $file->getMimeType() !== $extensions[$extension]) {
            throw new InvalidArgumentException('Use a JPEG, PNG, or WebP image with a matching file extension.');
        }
        $size = @getimagesize($file->getTempName());
        if (!$size || $size[0] < 1 || $size[1] < 1 || $size[0] > 6000 || $size[1] > 6000 || $size[0] * $size[1] > 20000000) {
            throw new InvalidArgumentException('The image is unreadable or exceeds the 6000-pixel or 20-megapixel limit.');
        }
        if (!extension_loaded('gd')) {
            throw new RuntimeException('Image processing is unavailable. Ask the administrator to enable PHP GD.');
        }
        $source = @imagecreatefromstring(file_get_contents($file->getTempName()));
        if ($source === false) {
            throw new InvalidArgumentException('This image could not be read. Try another JPEG, PNG, or WebP file.');
        }
        $scale = min(1, 1200 / max($size[0], $size[1]));
        $width = max(1, (int) round($size[0] * $scale));
        $height = max(1, (int) round($size[1] * $scale));
        $target = imagecreatetruecolor($width, $height);
        imagealphablending($target, false);
        imagesavealpha($target, true);
        imagecopyresampled($target, $source, 0, 0, 0, 0, $width, $height, $size[0], $size[1]);
        $directory = WRITEPATH . 'uploads';
        if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
            imagedestroy($source);
            imagedestroy($target);
            throw new RuntimeException('The image could not be saved. Please contact the administrator.');
        }
        $name = bin2hex(random_bytes(16)) . ($extension === 'jpg' || $extension === 'jpeg' ? '.jpg' : '.png');
        $saved = str_ends_with($name, '.jpg') ? imagejpeg($target, $directory . '/' . $name, 88) : imagepng($target, $directory . '/' . $name, 7);
        imagedestroy($source);
        imagedestroy($target);
        if (!$saved) {
            throw new RuntimeException('The image could not be saved. Please try again.');
        }
        chmod($directory . '/' . $name, 0640);
        return $name;
    }

    public function remove(?string $name): void
    {
        if ($name && preg_match('/\A[a-f0-9]{32}\.(?:png|jpg)\z/', $name)) {
            $path = WRITEPATH . 'uploads/' . $name;
            if (is_file($path)) {
                @unlink($path);
            }
        }
    }
}
