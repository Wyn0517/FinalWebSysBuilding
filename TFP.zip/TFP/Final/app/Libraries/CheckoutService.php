<?php

namespace App\Libraries;

use CodeIgniter\Database\BaseConnection;
use DomainException;
use RuntimeException;
use Throwable;

/** Commits an entire cart and its assignment-compatible sales rows together. */
class CheckoutService
{
    private const MAX_CENTS = 9999999999;
    private const MAX_QUANTITY = 2147483647;

    public function __construct(private ?BaseConnection $db = null)
    {
        $this->db ??= db_connect();
    }

    /** @param list<array{product_id:int, quantity:int}> $items */
    public function record(array $items, ?int $customerId, int $staffId, string $requestKey): array
    {
        $items = self::normalizeItems($items);
        if ($staffId < 1 || ($customerId !== null && $customerId < 1)
            || !preg_match('/\A[a-f0-9]{64}\z/', $requestKey)) {
            throw new DomainException('Choose a valid customer and submit a current checkout form.');
        }
        if ($receipt = $this->existing($requestKey, $staffId)) {
            return $receipt;
        }
        try {
            $this->db->resetTransStatus();
            if (!$this->db->transBegin()) {
                throw new RuntimeException('Transaction start failed');
            }
        } catch (Throwable $e) {
            log_message('error', 'A cart transaction could not be started.');
            throw new RuntimeException('Checkout could not be started. Please try again.');
        }

        try {
            $now = date('Y-m-d H:i:s');
            // Write first for SQLite, and lock products in the same order for InnoDB.
            // The guarded UPDATE checks stock after any competing sale has finished.
            foreach ($items as $item) {
                $updated = $this->db->table('products')->where('id', $item['product_id'])
                    ->where('deleted_at', null)->where('stock_quantity >=', $item['quantity'])
                    ->set('stock_quantity', 'stock_quantity - ' . $item['quantity'], false)
                    ->set('updated_at', $now)->update();
                if (!$updated) {
                    throw new RuntimeException('Inventory update failed');
                }
                if ($this->db->affectedRows() !== 1) {
                    throw new DomainException('One or more items have insufficient stock or are no longer available. Review your cart and try again.');
                }
            }

            $staff = $this->activeRecord('users', $staffId, true);
            if (!$staff) {
                throw new DomainException('Your account is no longer active. Sign in again.');
            }
            $customer = $customerId === null ? null : $this->activeRecord('customers', $customerId);
            if ($customerId !== null && !$customer) {
                throw new DomainException('That customer is no longer available. Choose another customer or use walk-in.');
            }

            $totalCents = 0;
            $quantityTotal = 0;
            $sales = [];
            foreach ($items as $item) {
                $result = $this->db->table('products')->where('id', $item['product_id'])->get();
                if ($result === false || !($product = $result->getRowArray())) {
                    throw new RuntimeException('Product lookup failed');
                }
                $unitCents = self::cents((string) $product['price']);
                if ($unitCents > 0 && $item['quantity'] > intdiv(self::MAX_CENTS - $totalCents, $unitCents)) {
                    throw new DomainException('The cart total exceeds ₱99,999,999.99. Reduce the quantity or split the purchase.');
                }
                $lineCents = $unitCents * $item['quantity'];
                $totalCents += $lineCents;
                $quantityTotal += $item['quantity'];
                $sales[] = [
                    'product_id' => $item['product_id'], 'customer_id' => $customerId,
                    'sold_by' => $staffId, 'quantity' => $item['quantity'],
                    'unit_price' => self::decimal($unitCents), 'total_price' => self::decimal($lineCents),
                    'product_name' => $product['name'], 'customer_name' => $customer['full_name'] ?? null,
                    'staff_name' => $staff['full_name'], 'created_at' => $now,
                    'request_key' => hash('sha256', $requestKey . ':' . $item['product_id']),
                ];
            }
            $receipt = [
                'customer_id' => $customerId, 'sold_by' => $staffId,
                'total_price' => self::decimal($totalCents), 'quantity_total' => $quantityTotal,
                'created_at' => $now, 'request_key' => $requestKey,
                'customer_name' => $customer['full_name'] ?? null, 'staff_name' => $staff['full_name'],
            ];
            if (!$this->db->table('receipts')->insert($receipt)) {
                throw new RuntimeException('Receipt insert failed');
            }
            $receipt['id'] = (int) $this->db->insertID();
            foreach ($sales as $sale) {
                if (!$this->db->table('sales')->insert($sale)) {
                    throw new RuntimeException('Sale insert failed');
                }
                $saleId = (int) $this->db->insertID();
                if (!$this->db->table('receipt_lines')->insert(['receipt_id' => $receipt['id'], 'sale_id' => $saleId])) {
                    throw new RuntimeException('Receipt line insert failed');
                }
            }
            if (!$this->db->transStatus() || !$this->db->transCommit()) {
                throw new RuntimeException('Checkout commit failed');
            }
            return $receipt;
        } catch (Throwable $e) {
            try {
                if (!$this->db->transRollback()) {
                    throw new RuntimeException('Checkout rollback failed');
                }
                $this->db->resetTransStatus();
            } catch (Throwable $rollbackError) {
                log_message('error', 'The database connection was interrupted during cart recovery.');
                throw new RuntimeException('Checkout could not be confirmed. Check transaction history before retrying.');
            }
            // A simultaneous retry may have completed the same receipt first.
            if ($receipt = $this->existing($requestKey, $staffId)) {
                return $receipt;
            }
            if ($e instanceof DomainException) {
                throw $e;
            }
            log_message('error', 'A cart transaction failed; database recovery was requested.');
            throw new RuntimeException('Checkout could not be confirmed. Check transaction history before retrying.');
        }
    }

    /** Validate integer-only data, merge repeated products, and acquire locks consistently. */
    public static function normalizeItems(array $items): array
    {
        if ($items === [] || !array_is_list($items) || count($items) > 200) {
            throw new DomainException('Add between 1 and 50 different products to the cart.');
        }
        $normalized = [];
        $quantityTotal = 0;
        foreach ($items as $item) {
            if (!is_array($item) || !isset($item['product_id'], $item['quantity'])
                || !is_int($item['product_id']) || !is_int($item['quantity'])
                || $item['product_id'] < 1 || $item['product_id'] > self::MAX_QUANTITY
                || $item['quantity'] < 1 || $item['quantity'] > self::MAX_QUANTITY) {
                throw new DomainException('Every cart item needs a valid product and a positive whole-number quantity.');
            }
            if ($quantityTotal > self::MAX_QUANTITY - $item['quantity']) {
                throw new DomainException('The cart contains too many units. Reduce the quantities.');
            }
            $quantityTotal += $item['quantity'];
            $id = $item['product_id'];
            $normalized[$id] = ['product_id' => $id, 'quantity' => ($normalized[$id]['quantity'] ?? 0) + $item['quantity']];
            if (count($normalized) > 50) {
                throw new DomainException('A checkout can contain at most 50 different products.');
            }
        }
        ksort($normalized, SORT_NUMERIC);
        return array_values($normalized);
    }

    /** Lock related records until checkout completes, so access and snapshots stay current. */
    private function activeRecord(string $table, int $id, bool $staff = false): ?array
    {
        $builder = $this->db->table($table)->select('id, full_name')->where('id', $id)->where('deleted_at', null);
        if ($staff) {
            $builder->where('is_active', 1);
        }
        $sql = $builder->getCompiledSelect();
        if ($this->db->DBDriver === 'MySQLi') {
            $sql .= ' FOR UPDATE';
        }
        $result = $this->db->query($sql);
        if ($result === false) {
            throw new RuntimeException('Related account lookup failed');
        }
        return $result->getRowArray();
    }

    private function existing(string $key, int $staffId): ?array
    {
        try {
            $result = $this->db->table('receipts')->where('request_key', $key)->where('sold_by', $staffId)->get();
            if ($result === false) {
                throw new RuntimeException('Receipt lookup failed');
            }
            $receipt = $result->getRowArray();
            if ($receipt !== null) {
                // SQLite returns numeric affinity values; keep the service result stable.
                $receipt['id'] = (int) $receipt['id'];
                $receipt['sold_by'] = (int) $receipt['sold_by'];
                $receipt['customer_id'] = $receipt['customer_id'] === null ? null : (int) $receipt['customer_id'];
                $receipt['quantity_total'] = (int) $receipt['quantity_total'];
                $receipt['total_price'] = self::decimal(self::cents((string) $receipt['total_price']));
            }
            return $receipt;
        } catch (Throwable $e) {
            log_message('error', 'A checkout submission could not be checked against transaction history.');
            throw new RuntimeException('Transaction history is temporarily unavailable. Check it before retrying checkout.');
        }
    }

    private static function cents(string $value): int
    {
        if (!preg_match('/\A(\d{1,8})(?:\.(\d{1,2}))?\z/', $value, $parts)) {
            throw new DomainException('A product has an invalid price. Ask an administrator to correct it.');
        }
        return (int) $parts[1] * 100 + (int) str_pad($parts[2] ?? '', 2, '0');
    }

    private static function decimal(int $cents): string
    {
        return intdiv($cents, 100) . '.' . str_pad((string) ($cents % 100), 2, '0', STR_PAD_LEFT);
    }
}
