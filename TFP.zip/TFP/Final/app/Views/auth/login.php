<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php $errors = session('errors') ?? []; ?>
<div class="login-layout login-experience">
    <section class="login-brand-stage" aria-labelledby="login-stage-title">
        <div class="login-stage-copy"><p class="login-stage-eyebrow">Counterpoint POS</p><h1 class="login-stage-title" id="login-stage-title">Your counter.<br><span>All in order.</span></h1><p class="login-stage-description">Products, customers and sales in one clear workspace.</p></div>
        <div class="login-visual" aria-hidden="true">
            <svg class="login-art" viewBox="0 0 600 390" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs><linearGradient id="login-card-light" x1="190" y1="70" x2="415" y2="340" gradientUnits="userSpaceOnUse"><stop stop-color="var(--elevated)"/><stop offset="1" stop-color="var(--surface)"/></linearGradient><linearGradient id="login-brand-light" x1="260" y1="155" x2="345" y2="255" gradientUnits="userSpaceOnUse"><stop stop-color="var(--accent)"/><stop offset="1" stop-color="var(--accent)" stop-opacity=".4"/></linearGradient></defs>
                <ellipse cx="306" cy="341" rx="164" ry="18" fill="var(--accent)" opacity=".08"/>
                <circle cx="300" cy="197" r="166" stroke="var(--border)" stroke-dasharray="3 8" opacity=".6"/>
                <circle cx="300" cy="197" r="126" stroke="var(--border)" opacity=".45"/>
                <g transform="rotate(-12 280 205)"><rect x="154" y="99" width="240" height="244" rx="26" fill="var(--surface)" stroke="var(--border)"/><rect x="173" y="120" width="202" height="200" rx="17" fill="var(--elevated)" opacity=".6"/></g>
                <g transform="rotate(8 315 194)"><rect x="201" y="64" width="238" height="264" rx="26" fill="url(#login-card-light)" stroke="var(--border)"/><rect x="221" y="84" width="198" height="224" rx="16" stroke="var(--border)"/><rect x="239" y="107" width="61" height="7" rx="3.5" fill="var(--muted)" opacity=".25"/><rect x="239" y="121" width="39" height="5" rx="2.5" fill="var(--muted)" opacity=".14"/><rect x="270" y="176" width="24" height="63" rx="5" fill="url(#login-brand-light)"/><rect x="302" y="151" width="24" height="88" rx="5" fill="url(#login-brand-light)"/><rect x="334" y="194" width="24" height="45" rx="5" fill="url(#login-brand-light)"/><rect x="240" y="273" width="153" height="5" rx="2.5" fill="var(--muted)" opacity=".17"/><rect x="262" y="286" width="110" height="4" rx="2" fill="var(--muted)" opacity=".1"/></g>
                <circle cx="449" cy="107" r="5" fill="var(--accent)" opacity=".65"/><circle cx="132" cy="244" r="4" fill="var(--accent)" opacity=".35"/><rect x="447" y="277" width="11" height="11" rx="3" transform="rotate(22 447 277)" fill="var(--accent)" opacity=".28"/>
            </svg>
        </div>
    </section>

    <div class="login-form-stage">
        <section class="panel login-panel" aria-labelledby="login-title">
            <div class="login-heading"><span class="login-access-badge"><?= icon('shield', 16) ?> Staff sign in</span><h2 id="login-title">Welcome back</h2><p class="muted">Sign in to your store workspace.</p></div>
            <form action="<?= site_url('login') ?>" method="post" class="stack-form login-form" data-submit-once>
                <?= csrf_field() ?>
                <div class="field"><label for="username">Username</label><div class="input-shell"><span class="input-icon"><?= icon('user', 18) ?></span><input id="username" name="username" value="<?= esc(form_value('username', ''), 'attr') ?>" autocomplete="username" maxlength="50" placeholder="Enter your username" required autofocus<?= isset($errors['username']) ? ' aria-invalid="true" aria-describedby="username-error"' : '' ?>></div><?php if (isset($errors['username'])): ?><p class="field-error" id="username-error"><?= esc($errors['username']) ?></p><?php endif ?></div>
                <div class="field"><label for="password">Password</label><div class="input-shell"><span class="input-icon"><?= icon('lock', 18) ?></span><input type="password" id="password" name="password" autocomplete="current-password" placeholder="Enter your password" required<?= isset($errors['password']) ? ' aria-invalid="true" aria-describedby="password-error"' : '' ?>></div><?php if (isset($errors['password'])): ?><p class="field-error" id="password-error"><?= esc($errors['password']) ?></p><?php endif ?></div>
                <button class="button primary full-width" type="submit"><span>Sign in</span><?= icon('arrow-right', 18) ?></button>
            </form>
            <p class="login-note">Need an account? Your administrator can help.</p>
        </section>
    </div>
</div>
<?= $this->endSection() ?>
