<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php $editing = ! empty($item); $errors = session('errors') ?? []; $value = static fn (string $key, $fallback = '') => esc(form_value($key, $item[$key] ?? $fallback)); ?>
<a class="breadcrumb" href="<?= site_url('products') ?>"><?= icon('arrow-left', 16) ?> Products</a>
<header class="page-header"><div><p class="eyebrow">Inventory</p><h1><?= $editing ? 'Edit product' : 'Add product' ?></h1><p class="muted"><?= $editing ? 'Update product information or adjust available inventory.' : 'Create a product with a price and starting stock quantity.' ?></p></div></header>
<div class="form-layout">
    <form class="panel" method="post" enctype="multipart/form-data" action="<?= site_url($editing ? 'products/' . (int) $item['id'] : 'products') ?>">
        <?= csrf_field() ?>
        <?php if ($editing): ?><input type="hidden" name="stock_original" value="<?= esc(form_value('stock_original', $item['stock_quantity']), 'attr') ?>"><?php endif ?>
        <div class="form-section"><h2>Product details</h2><div class="form-grid">
            <div class="field span-two"><label for="name">Product name <span aria-hidden="true">*</span></label><input id="name" name="name" value="<?= $value('name') ?>" required maxlength="100" autocomplete="off" <?= isset($errors['name']) ? 'aria-invalid="true" aria-describedby="name-error"' : '' ?>><?php if (isset($errors['name'])): ?><p id="name-error" class="field-error"><?= esc($errors['name']) ?></p><?php endif ?></div>
            <div class="field"><label for="price">Unit price in PHP <span aria-hidden="true">*</span></label><input id="price" name="price" type="number" min="0" max="99999999.99" step="0.01" inputmode="decimal" value="<?= $value('price', '0.00') ?>" required <?= isset($errors['price']) ? 'aria-invalid="true" aria-describedby="price-error"' : '' ?>><?php if (isset($errors['price'])): ?><p id="price-error" class="field-error"><?= esc($errors['price']) ?></p><?php endif ?></div>
            <div class="field"><label for="stock_quantity">Available stock <span aria-hidden="true">*</span></label><input id="stock_quantity" name="stock_quantity" type="number" min="0" step="1" inputmode="numeric" value="<?= $value('stock_quantity', '0') ?>" required <?= isset($errors['stock_quantity']) ? 'aria-invalid="true" aria-describedby="stock-error"' : '' ?>><?php if (isset($errors['stock_quantity'])): ?><p id="stock-error" class="field-error"><?= esc($errors['stock_quantity']) ?></p><?php endif ?></div>
            <div class="field span-two"><label for="image">Product image <span class="optional">Optional</span></label><?php if ($editing && ! empty($item['image'])): ?><img class="form-image" src="<?= esc(media_url($item['image']), 'attr') ?>" alt="Current product image"><?php endif ?><input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp" aria-describedby="image-hint<?= isset($errors['image']) ? ' image-error' : '' ?>"><p id="image-hint" class="hint">JPEG, PNG, or WebP. Maximum 2 MB. <?= $editing ? 'Leave empty to keep the current image.' : 'A placeholder appears when no image is added.' ?></p><?php if (isset($errors['image'])): ?><p id="image-error" class="field-error"><?= esc($errors['image']) ?></p><?php endif ?></div>
        </div></div>
        <div class="form-actions"><a class="button secondary" href="<?= site_url('products') ?>">Cancel</a><button class="button primary" type="submit"><?= icon('check', 18) ?> <?= $editing ? 'Save changes' : 'Create product' ?></button></div>
    </form>
    <aside class="form-aside"><p class="eyebrow">Inventory notes</p><h3>Ready for the shelf</h3><p>Stock is counted in whole units. Each recorded sale automatically reduces the available quantity.</p><p>Products with 5 or fewer units are marked as low stock.</p><?php if ($editing): ?><p>Archiving a product removes it from the catalog while preserving its sales history.</p><?php endif ?></aside>
</div>
<?= $this->endSection() ?>
