<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php $stockFilter = $stockFilter ?? 'all'; $hasProductFilters = ($q ?? '') !== '' || $stockFilter !== 'all'; ?>
<header class="page-header">
    <div><p class="eyebrow">Inventory</p><h1>Products</h1><p class="muted">Keep your catalog clear and your stock ready for the next sale.</p></div>
    <a class="button primary" href="<?= site_url('products/new') ?>"><?= icon('plus') ?> Add product</a>
</header>
<section class="panel" aria-label="Product catalog">
    <div class="panel-header product-toolbar"><h2>Product catalog</h2>
        <form class="search-form" method="get" action="<?= site_url('products') ?>" role="search">
            <label class="sr-only" for="product-search">Search products</label><?= icon('search', 18) ?>
            <input id="product-search" name="q" type="search" value="<?= esc($q ?? '') ?>" placeholder="Search products…" maxlength="100">
            <label class="sr-only" for="stock-filter">Stock status</label><select class="stock-filter" id="stock-filter" name="stock"><?php foreach (['all' => 'All stock', 'available' => 'Available', 'low' => 'Low stock', 'out' => 'Out of stock'] as $filterValue => $filterLabel): ?><option value="<?= esc($filterValue, 'attr') ?>"<?= $stockFilter === $filterValue ? ' selected' : '' ?>><?= esc($filterLabel) ?></option><?php endforeach ?></select>
            <button class="button secondary small" type="submit">Apply</button>
            <?php if ($hasProductFilters): ?><a class="text-link" href="<?= site_url('products') ?>">Clear</a><?php endif ?>
        </form>
    </div>
    <?php
    $filterChips = [];
    $productFilterUrl = static fn (array $params): string => site_url('products') . ($params ? '?' . http_build_query($params) : '');
    if (!empty($q) || ($q ?? '') === '0') {
        $filterChips[] = ['label' => 'Search: ' . $q, 'url' => $productFilterUrl($stockFilter === 'all' ? [] : ['stock' => $stockFilter])];
    }
    if ($stockFilter !== 'all') {
        $stockLabels = ['available' => 'Available', 'low' => 'Low stock', 'out' => 'Out of stock'];
        $filterChips[] = ['label' => $stockLabels[$stockFilter] ?? $stockFilter, 'url' => $productFilterUrl(($q ?? '') !== '' ? ['q' => $q] : [])];
    }
    ?>
    <?= view('components/active_filters', ['filterChips' => $filterChips]) ?>
    <?php if (empty($items)): ?>
        <div class="empty-state"><?= icon('package', 36) ?><h3><?= !$hasProductFilters ? 'Your catalog starts here' : 'No matching products' ?></h3><p><?= !$hasProductFilters ? 'Add your first product to start tracking inventory and recording sales.' : 'Try another name or clear the search to see your catalog.' ?></p><a class="button secondary" href="<?= site_url(!$hasProductFilters ? 'products/new' : 'products') ?>"><?= !$hasProductFilters ? 'Add a product' : 'Clear search' ?></a></div>
    <?php else: ?>
        <div class="table-wrap"><table class="data-table"><thead><tr><th scope="col">Product</th><th scope="col" class="numeric">Unit price</th><th scope="col" class="numeric">Available stock</th><th scope="col">Status</th><th scope="col" class="text-right">Actions</th></tr></thead><tbody>
        <?php foreach ($items as $product): ?>
            <tr><td><div class="cell-main"><img class="thumb" src="<?= esc(media_url($product['image'] ?? null), 'attr') ?>" alt="" loading="lazy"><div><strong><?= esc($product['name']) ?></strong><span class="cell-sub">Product #<?= esc((string) $product['id']) ?></span></div></div></td>
                <td class="numeric"><?= money($product['price']) ?></td><td class="numeric"><?= esc(number_format((int) $product['stock_quantity'])) ?></td>
                <td><?php if ((int) $product['stock_quantity'] === 0): ?><span class="badge danger">Out of stock</span><?php elseif ((int) $product['stock_quantity'] <= 5): ?><span class="badge warning">Low stock</span><?php else: ?><span class="badge success">In stock</span><?php endif ?></td>
                <td><div class="row-actions"><a class="button secondary small" href="<?= site_url('products/' . (int) $product['id'] . '/edit') ?>" aria-label="Edit <?= esc($product['name'], 'attr') ?>"><?= icon('edit', 16) ?> Edit</a><form method="post" action="<?= site_url('products/' . (int) $product['id'] . '/delete') ?>" data-confirm="Archive this product? It will no longer be available for new sales. Past sales will be kept."><?= csrf_field() ?><button class="button danger small" type="submit" aria-label="Archive <?= esc($product['name'], 'attr') ?>"><?= icon('trash', 16) ?><span class="sr-only">Archive</span></button></form></div></td>
            </tr>
        <?php endforeach ?>
        </tbody></table></div>
        <?php if (isset($pager)): ?><div class="pagination-wrap"><?= $pager->only(['q', 'stock'])->links() ?></div><?php endif ?>
    <?php endif ?>
</section>
<?= $this->endSection() ?>
