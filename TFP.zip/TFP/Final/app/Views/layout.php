<!doctype html>
<html lang="en" data-theme="dark" data-sidebar="expanded">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="dark light">
    <title><?= esc($title ?? 'Workspace') ?> · Counterpoint POS</title>
    <script>try{const t=localStorage.getItem('counterpoint-theme');document.documentElement.dataset.theme=t==='light'||t==='dark'?t:(window.matchMedia&&matchMedia('(prefers-color-scheme: light)').matches?'light':'dark')}catch(e){}try{const s=localStorage.getItem('counterpoint-sidebar');document.documentElement.dataset.sidebar=s==='compact'||s==='hidden'?'compact':'expanded'}catch(e){}</script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/app.css') ?>?v=cobalt-menu-9">
    <link rel="stylesheet" href="<?= base_url('assets/studio.css') ?>?v=cobalt-menu-9">
    <script src="<?= base_url('assets/app.js') ?>?v=cobalt-menu-9" defer></script>
</head>
<?php
$currentUser = session('user');
$isAdmin = ($currentUser['role'] ?? '') === 'admin';
$currentPath = trim(uri_string(), '/');
$isCheckout = $currentPath === 'pos';
$activeSection = match (true) {
    $currentPath === '' || $currentPath === 'admin/dashboard' => 'overview',
    preg_match('~^(?:admin/)?products(?:/|$)~', $currentPath) === 1 => 'products',
    preg_match('~^(?:admin/)?customers(?:/|$)~', $currentPath) === 1 => 'customers',
    preg_match('~^(?:staff|admin/users)(?:/|$)~', $currentPath) === 1 => 'staff',
    preg_match('~^(?:admin/)?sales(?:/|$)~', $currentPath) === 1 => 'sales',
    str_starts_with($currentPath, 'pos') => 'checkout',
    $currentPath === 'profile' => 'profile',
    default => '',
};
$sectionLabel = match ($activeSection) {
    'overview' => 'Business overview',
    'products' => 'Product catalog',
    'customers' => 'Customers',
    'staff' => 'Staff & access',
    'sales' => $isAdmin ? 'Sales history' : 'My sales',
    'checkout' => 'Point of sale',
    'profile' => 'My profile',
    default => 'Workspace',
};
?>
<body class="<?= !$currentUser ? 'signed-out' : ($isAdmin ? 'admin-workspace' : 'cashier-workspace') ?><?= $isCheckout ? ' checkout-workspace' : '' ?>">
<a class="skip-link" href="#main">Skip to content</a>
<?php if ($currentUser): ?>
<aside class="workspace-sidebar" id="workspace-sidebar" aria-label="Workspace sidebar">
    <div class="sidebar-top"><a class="brand sidebar-brand" href="<?= site_url('/') ?>" aria-label="Counterpoint home" title="Counterpoint home"><span class="brand-mark" aria-hidden="true"><span></span><span></span><span></span></span><span class="sidebar-label sidebar-brand-label">counterpoint</span></a><button class="icon-button sidebar-toggle sidebar-rail-toggle" type="button" aria-label="Collapse sidebar" title="Collapse sidebar" aria-expanded="true" aria-controls="workspace-sidebar"><span class="sidebar-expand-icon" aria-hidden="true"><?= icon('menu', 19) ?></span><span class="sidebar-close-icon" aria-hidden="true"><?= icon('x', 19) ?></span></button></div>
    <div class="sidebar-scroll">
    <div class="sidebar-workspace"><span class="workspace-symbol"><?= icon('shopping-bag', 20) ?></span><span class="sidebar-label"><strong>Retail workspace</strong><small><?= $isAdmin ? 'Store management' : 'Point of sale' ?></small></span></div>
    <nav class="primary-navigation" id="primary-navigation" aria-label="Main navigation">
        <div class="navigation-heading"><span class="nav-group-label sidebar-label">Workspace</span></div>
        <?php
        $navigation = $isAdmin
            ? ['overview' => ['admin/dashboard', 'Overview', 'dashboard'], 'products' => ['admin/products', 'Products', 'package'], 'customers' => ['admin/customers', 'Customers', 'users'], 'staff' => ['admin/users', 'Staff', 'shield'], 'sales' => ['admin/sales', 'Sales history', 'receipt']]
            : ['checkout' => ['pos', 'Checkout', 'shopping-bag'], 'sales' => ['sales', 'My sales', 'receipt'], 'profile' => ['profile', 'My profile', 'user']];
        foreach ($navigation as $section => [$path, $label, $symbol]): $selected = $section === $activeSection;
        ?>
        <a class="nav-link<?= $selected ? ' active' : '' ?>" href="<?= site_url($path) ?>" aria-label="<?= esc($label, 'attr') ?>" data-label="<?= esc($label, 'attr') ?>"<?= $selected ? ' aria-current="page"' : '' ?>><?= icon($symbol, 19) ?><span class="sidebar-label"><?= esc($label) ?></span><?php if ($selected): ?><span class="nav-active-dot" aria-hidden="true"></span><?php endif ?></a>
        <?php endforeach ?>
        <?php if ($isAdmin): ?>
        <div class="navigation-divider"></div><span class="nav-group-label sidebar-label">Personal</span>
        <a class="nav-link<?= $activeSection === 'profile' ? ' active' : '' ?>" href="<?= site_url('profile') ?>" aria-label="My profile" data-label="My profile"<?= $activeSection === 'profile' ? ' aria-current="page"' : '' ?>><?= icon('user', 19) ?><span class="sidebar-label">My profile</span></a>
        <?php endif ?>
    </nav>
    </div>
    <div class="sidebar-bottom">
        <?php if ($isAdmin): ?><a class="sidebar-pos-link" href="<?= site_url('pos') ?>" aria-label="Checkout" data-label="Checkout"<?= $isCheckout ? ' aria-current="page"' : '' ?>><span class="sidebar-pos-symbol"><?= icon('shopping-bag', 20) ?></span><span class="sidebar-label"><strong>Checkout</strong><small>Start a new sale</small></span><?= icon('arrow-up-right', 17) ?></a><?php endif ?>
        <a class="sidebar-account" href="<?= site_url('profile') ?>" aria-label="My profile" data-label="My profile"><img class="avatar" src="<?= esc(media_url($currentUser['avatar'] ?? null, 'avatar'), 'attr') ?>" alt=""><span class="sidebar-label"><strong><?= esc($currentUser['full_name']) ?></strong><small><?= $isAdmin ? 'Administrator' : 'Cashier' ?></small></span><?= icon('chevron-right', 15) ?></a>
    </div>
</aside>
<div class="sidebar-tooltip" id="sidebar-tooltip" role="tooltip" hidden></div>
<button class="navigation-backdrop" type="button" data-navigation-close aria-label="Close sidebar" tabindex="-1" hidden></button>
<?php endif ?>
<div class="workspace-frame">
<header class="app-header">
    <div class="nav-shell">
        <?php if (!$currentUser): ?>
        <a class="brand" href="<?= site_url('/') ?>" aria-label="Counterpoint home"><span class="brand-mark" aria-hidden="true"><span></span><span></span><span></span></span><span>counterpoint<span class="brand-detail">YOUR EVERYDAY, IN ORDER.</span></span></a>
        <?php else: ?>
        <div class="header-location"><button class="icon-button mobile-menu-toggle sidebar-toggle header-sidebar-toggle" type="button" aria-label="Collapse sidebar" title="Collapse sidebar" aria-expanded="true" aria-controls="workspace-sidebar"><?= icon('menu', 20) ?></button><div class="header-breadcrumb"><span>Workspace</span><?= icon('chevron-right', 14) ?><strong><?= esc($sectionLabel) ?></strong></div></div>
        <?php endif ?>
        <div class="nav-tools">
            <?php if (!$currentUser): ?><span class="login-topline">Thoughtfully built for your counter.</span><?php endif ?>
            <button class="icon-button theme-toggle" type="button" aria-label="Switch color theme" title="Switch color theme"><span class="theme-sun"><?= icon('sun') ?></span><span class="theme-moon"><?= icon('moon') ?></span></button>
            <?php if ($currentUser): ?>
            <details class="account-menu">
                <summary aria-label="Staff account menu"><img class="avatar" src="<?= esc(media_url($currentUser['avatar'] ?? null, 'avatar'), 'attr') ?>" alt=""><span class="account-label"><?= esc($currentUser['full_name']) ?><small><?= $isAdmin ? 'Administrator' : 'Cashier' ?></small></span><?= icon('chevron-down', 14) ?></summary>
                <div class="account-dropdown"><p>Signed in as <strong><?= esc($currentUser['username']) ?></strong></p><a class="button secondary full-width" href="<?= site_url('profile') ?>"><?= icon('user', 16) ?> My profile</a><form action="<?= site_url('logout') ?>" method="post"><?= csrf_field() ?><button class="button secondary full-width" type="submit"><?= icon('log-out', 16) ?> Sign out</button></form></div>
            </details>
            <?php endif ?>
        </div>
    </div>
</header>
<main id="main" class="main-shell" tabindex="-1">
    <?php foreach (['success', 'error'] as $messageType): if ($message = session()->getFlashdata($messageType)): ?>
    <div class="notice <?= esc($messageType) ?>" role="<?= $messageType === 'error' ? 'alert' : 'status' ?>"><?= icon($messageType === 'error' ? 'alert-circle' : 'check-circle', 20) ?><span><?= esc($message) ?></span><button class="notice-close" type="button" data-notice-close aria-label="Dismiss message"><?= icon('x', 16) ?></button></div>
    <?php endif; endforeach ?>
    <?= $this->renderSection('content') ?>
</main>
<footer class="app-footer"><span>Counterpoint POS</span><span><?= !$currentUser ? 'A clearer view of your counter.' : ($isAdmin ? 'Manage the details. See the whole store.' : 'Ready for your next customer.') ?></span></footer>
</div>
<dialog class="confirm-dialog" id="confirmation-dialog" aria-labelledby="confirmation-title" aria-describedby="confirmation-message">
    <div class="dialog-symbol"><?= icon('alert-circle', 24) ?></div><h2 id="confirmation-title">Confirm this change</h2><p id="confirmation-message"></p>
    <div class="dialog-actions"><button class="button secondary" type="button" data-confirm-cancel>Cancel</button><button class="button danger" type="button" data-confirm-accept>Confirm</button></div>
</dialog>
<?= $this->renderSection('scripts') ?>
</body>
</html>
