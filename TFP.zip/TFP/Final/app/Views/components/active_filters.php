<?php if (!empty($filterChips)): ?>
<div class="active-filters" aria-label="Active filters">
    <span class="active-filters-label">Filtered by</span>
    <?php foreach ($filterChips as $chip): ?>
    <a class="filter-chip" href="<?= esc($chip['url'], 'attr') ?>" aria-label="<?= esc('Remove ' . $chip['label'] . ' filter', 'attr') ?>"><span><?= esc($chip['label']) ?></span><?= icon('x', 13) ?></a>
    <?php endforeach ?>
</div>
<?php endif ?>
