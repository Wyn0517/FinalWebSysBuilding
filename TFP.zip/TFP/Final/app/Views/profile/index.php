<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php $errors = session('errors') ?? []; ?>
<div class="page-header"><div><p class="eyebrow">Your workspace</p><h1>My profile</h1><p class="muted">Keep your name, profile image, and sign-in details up to date.</p></div></div>
<div class="form-layout">
    <form class="panel profile-panel" action="<?= site_url('profile') ?>" method="post" enctype="multipart/form-data" data-submit-once>
        <?= csrf_field() ?>
        <div class="form-section">
            <h2>Profile details</h2>
            <img class="form-image avatar" src="<?= esc(media_url($item['avatar'] ?? null, 'avatar'), 'attr') ?>" alt="Your current profile image">
            <div class="form-grid">
                <div class="field span-two"><label for="profile-name">Full name <span class="required" aria-hidden="true">*</span></label><input id="profile-name" name="full_name" value="<?= esc(form_value('full_name', $item['full_name']), 'attr') ?>" required maxlength="100" autocomplete="name"<?= isset($errors['full_name']) ? ' aria-invalid="true" aria-describedby="profile-name-error"' : '' ?>><?php if (isset($errors['full_name'])): ?><p class="field-error" id="profile-name-error"><?= esc($errors['full_name']) ?></p><?php endif ?></div>
                <div class="field"><label for="profile-username">Username</label><input id="profile-username" value="<?= esc($item['username'], 'attr') ?>" readonly aria-describedby="profile-username-help"><p class="hint" id="profile-username-help">Your administrator manages this sign-in name.</p></div>
                <div class="field"><label for="profile-role">Access level</label><input id="profile-role" value="<?= $item['role'] === 'admin' ? 'Administrator' : 'Cashier' ?>" readonly aria-describedby="profile-role-help"><p class="hint" id="profile-role-help">Only an administrator can manage access.</p></div>
                <div class="field span-two"><label for="profile-avatar">Profile image <span class="optional">Optional</span></label><input type="file" id="profile-avatar" name="avatar" accept="image/jpeg,image/png,image/webp" aria-describedby="profile-avatar-help<?= isset($errors['avatar']) ? ' profile-avatar-error' : '' ?>"<?= isset($errors['avatar']) ? ' aria-invalid="true"' : '' ?>><p class="hint" id="profile-avatar-help">JPEG, PNG, or WebP. Maximum 2 MB. Leave empty to keep your current image.</p><?php if (isset($errors['avatar'])): ?><p class="field-error" id="profile-avatar-error"><?= esc($errors['avatar']) ?></p><?php endif ?></div>
            </div>
        </div>
        <div class="form-section">
            <h2>Change password</h2><p class="hint">Leave all password fields empty to keep your current password.</p>
            <div class="form-grid">
                <div class="field span-two"><label for="current-password">Current password</label><input type="password" id="current-password" name="current_password" autocomplete="current-password" maxlength="72"<?= isset($errors['current_password']) ? ' aria-invalid="true" aria-describedby="current-password-error"' : '' ?>><?php if (isset($errors['current_password'])): ?><p class="field-error" id="current-password-error"><?= esc($errors['current_password']) ?></p><?php endif ?></div>
                <div class="field"><label for="new-password">New password</label><input type="password" id="new-password" name="password" autocomplete="new-password" minlength="12" maxlength="72" aria-describedby="new-password-help<?= isset($errors['password']) ? ' new-password-error' : '' ?>"<?= isset($errors['password']) ? ' aria-invalid="true"' : '' ?>><p class="hint" id="new-password-help">At least 12 characters and at most 72 bytes.</p><?php if (isset($errors['password'])): ?><p class="field-error" id="new-password-error"><?= esc($errors['password']) ?></p><?php endif ?></div>
                <div class="field"><label for="confirm-password">Confirm new password</label><input type="password" id="confirm-password" name="password_confirm" autocomplete="new-password" minlength="12" maxlength="72"<?= isset($errors['password_confirm']) ? ' aria-invalid="true" aria-describedby="confirm-password-error"' : '' ?>><?php if (isset($errors['password_confirm'])): ?><p class="field-error" id="confirm-password-error"><?= esc($errors['password_confirm']) ?></p><?php endif ?></div>
            </div>
        </div>
        <div class="form-actions"><a class="button secondary" href="<?= site_url(($item['role'] ?? '') === 'admin' ? 'admin/dashboard' : 'pos') ?>">Back to workspace</a><button class="button primary" type="submit"><?= icon('check', 18) ?> Save profile</button></div>
    </form>
    <aside class="form-aside"><p class="eyebrow">Personal account</p><h3>Your details, securely managed</h3><p>Your profile applies to this staff account. Existing transactions retain the name recorded when the sale was completed.</p><p>Changing a password requires your current password. For changes to your username, role, or access status, contact an administrator.</p></aside>
</div>
<?= $this->endSection() ?>
