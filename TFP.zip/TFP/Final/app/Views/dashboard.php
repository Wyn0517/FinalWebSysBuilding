<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php
$todayHistoryUrl = site_url('admin/sales') . '?' . http_build_query(['from' => $todayDate, 'to' => $todayDate]);
$lowStockUrl = site_url('admin/products') . '?stock=low';
?>
<div class="overview-page">
    <header class="dashboard-hero page-header">
        <div class="dashboard-hero-copy">
            <p class="dashboard-greeting"><?= esc($greeting) ?></p>
            <h1>Business overview</h1>
        </div>
        <div class="dashboard-date dashboard-date-pill"><?= icon('calendar', 15) ?><span><?= esc($reportDate) ?></span><small><?= esc($reportTimezone) ?></small></div>
        <a class="button primary" href="<?= site_url('pos') ?>"><?= icon('plus', 18) ?> New sale</a>
    </header>

    <div class="dashboard-board">
        <section class="panel overview-revenue" aria-labelledby="today-revenue-title">
            <header class="overview-card-heading"><h2 id="today-revenue-title">Today at a glance</h2><?= icon('chart', 18) ?></header>
            <a class="revenue-balance" href="<?= esc($todayHistoryUrl, 'attr') ?>">
                <span class="overview-revenue-label">Today's revenue</span>
                <strong class="overview-revenue-value"><?= money($todayTotal) ?></strong>
                <span class="overview-revenue-caption">View completed sales <?= icon('arrow-up-right', 15) ?></span>
            </a>
            <nav class="overview-mini-metrics" aria-label="Today's business metrics">
                <a class="overview-mini-metric" href="<?= esc($todayHistoryUrl, 'attr') ?>"><span class="mini-metric-icon"><?= icon('receipt', 18) ?></span><span><span class="mini-metric-label">Transactions</span><small>Completed checkouts</small></span><strong><?= esc(number_format($todayReceiptCount)) ?></strong></a>
                <a class="overview-mini-metric" href="<?= esc($todayHistoryUrl, 'attr') ?>"><span class="mini-metric-icon"><?= icon('shopping-bag', 18) ?></span><span><span class="mini-metric-label">Units sold</span><small>Across <?= esc(number_format($todaySaleCount)) ?> <?= $todaySaleCount === 1 ? 'sale item' : 'sale items' ?></small></span><strong><?= esc(number_format($todayUnitCount)) ?></strong></a>
                <a class="overview-mini-metric" href="<?= site_url('admin/products') ?>"><span class="mini-metric-icon"><?= icon('package', 18) ?></span><span><span class="mini-metric-label">Active products</span><small>In your catalog</small></span><strong><?= esc(number_format($productCount)) ?></strong></a>
            </nav>
        </section>

        <figure class="trend-panel panel" aria-labelledby="trend-title" aria-describedby="trend-description">
            <figcaption class="trend-header">
                <div class="section-heading"><h2 id="trend-title">Revenue over time</h2></div>
                <nav class="trend-controls" aria-label="Revenue date range">
                    <?php foreach ([7, 14, 30] as $range): ?><a class="trend-range-link" href="<?= esc(site_url('admin/dashboard') . '?days=' . $range, 'attr') ?>"<?= $rangeDays === $range ? ' aria-current="page"' : '' ?>><?= $range ?> days</a><?php endforeach ?>
                </nav>
            </figcaption>
            <div class="trend-summary"><div><strong class="period-revenue"><?= money($periodTotal) ?></strong><span class="period-caption"><?= esc($periodStart) ?> – <?= esc($periodEnd) ?></span></div><span class="chart-legend"><span aria-hidden="true"></span>Completed sales</span></div>
            <p class="sr-only" id="trend-description">Revenue from completed sales for each day in <?= esc($reportTimezone) ?>. Focus or hover over a day for its exact amount. Open a day to see its sales. <?= $rangeDays > 7 ? 'The chart scrolls horizontally.' : '' ?></p>
            <div class="trend-scroll"<?= $rangeDays > 7 ? ' tabindex="0" role="region" aria-label="Daily revenue chart, scroll horizontally to view all days"' : '' ?>>
                <ol class="trend-bars<?= $rangeDays > 7 ? ' wide-trend' : '' ?>" style="--trend-days: <?= (int) $rangeDays ?>" aria-label="Revenue by day">
                    <?php foreach ($trend as $index => $day): $tooltipId = 'trend-day-tooltip-' . $index; $dayUrl = site_url('admin/sales') . '?' . http_build_query(['from' => $day['date'], 'to' => $day['date']]); ?>
                    <li class="trend-day <?= $day['isToday'] ? 'is-today' : '' ?>">
                        <a class="trend-day-link" href="<?= esc($dayUrl, 'attr') ?>" aria-label="<?= esc('View sales for ' . $day['fullDate'], 'attr') ?>" aria-describedby="<?= esc($tooltipId, 'attr') ?>">
                            <span class="trend-value"><?= money($day['total']) ?></span><span class="trend-track" aria-hidden="true"><span class="trend-bar" style="height: <?= esc($day['height'], 'attr') ?>%"></span></span><span class="trend-label"><?= esc($rangeDays > 7 ? $day['shortDate'] : $day['label']) ?><?= $day['isToday'] ? ' · Today' : '' ?></span>
                        </a>
                        <span class="trend-tooltip" role="tooltip" id="<?= esc($tooltipId, 'attr') ?>"><strong><?= esc($day['fullDate']) ?></strong><span><?= money($day['total']) ?></span></span>
                    </li>
                    <?php endforeach ?>
                </ol>
            </div>
            <?php if (!$hasPeriodSales): ?><div class="trend-empty"><span><?= icon('chart', 16) ?></span><p>No sales recorded in this period.</p></div><?php else: ?><p class="trend-explainer"><?= icon('info', 14) ?> Select a day to view its sales.</p><?php endif ?>
        </figure>

        <aside class="panel operations-panel" aria-label="Store summary">
            <div class="store-summary-head"><h2>Store summary</h2></div>
            <div class="operations-list">
                <a class="operations-row" href="<?= site_url('admin/customers') ?>"><span><span class="operation-icon"><?= icon('users', 18) ?></span>Customer records</span><strong><?= esc(number_format($customerCount)) ?></strong><?= icon('arrow-up-right', 16) ?></a>
                <a class="operations-row" href="<?= esc($lowStockUrl, 'attr') ?>"><span><span class="operation-icon"><?= icon('package', 18) ?></span>Low-stock products</span><strong class="<?= $lowStockCount ? 'text-warning' : '' ?>"><?= esc(number_format($lowStockCount)) ?></strong><?= icon('arrow-up-right', 16) ?></a>
            </div>
            <div class="inventory-summary <?= $lowStockCount ? 'needs-attention' : 'inventory-healthy' ?>"><?= icon($lowStockCount ? 'alert-circle' : 'check-circle', 17) ?><p><?= $lowStockCount ? 'Low stock means 5 units or fewer.' : ($productCount ? 'No low-stock products right now.' : 'Add a product to begin tracking stock.') ?></p></div>
            <nav class="dashboard-shortcuts summary-actions" aria-label="Quick actions">
                <span class="nav-group-label">Quick actions</span>
                <a class="dashboard-shortcut summary-action" href="<?= site_url('admin/products/new') ?>"><?= icon('plus', 16) ?><span>Add product</span><?= icon('arrow-up-right', 15) ?></a>
                <a class="dashboard-shortcut summary-action" href="<?= site_url('admin/customers/new') ?>"><?= icon('users', 16) ?><span>Add customer</span><?= icon('arrow-up-right', 15) ?></a>
                <a class="dashboard-shortcut summary-action" href="<?= site_url('admin/sales') ?>"><?= icon('receipt', 16) ?><span>Sales history</span><?= icon('arrow-up-right', 15) ?></a>
            </nav>
        </aside>

        <section class="panel recent-sales-panel" aria-labelledby="recent-sales-title">
            <div class="panel-header table-heading"><h2 id="recent-sales-title">Recent sale items</h2><a class="text-link" href="<?= site_url('admin/sales') ?>">View all <?= icon('arrow-right', 16) ?></a></div>
            <?php if ($recentSales): ?>
            <div class="table-wrap"><table class="data-table"><caption class="sr-only">One product per row. Several sale items may belong to the same receipt.</caption><thead><tr><th scope="col">Sale item</th><th scope="col">Product</th><th scope="col" class="number">Amount</th><th scope="col"><span class="sr-only">Details</span></th></tr></thead><tbody>
                <?php foreach ($recentSales as $sale): $saleDate = substr($sale['created_at'], 0, 10); $receiptId = (int) ($sale['receipt_id'] ?? 0); $detailUrl = $receiptId > 0 ? site_url('pos/receipts/' . $receiptId) : site_url('admin/sales') . '?' . http_build_query(['q' => $sale['product_name'], 'from' => $saleDate, 'to' => $saleDate]); ?>
                <tr><td><span class="sale-reference">#<?= esc(str_pad((string) $sale['id'], 5, '0', STR_PAD_LEFT)) ?></span><span class="cell-sub"><?= esc(date('M j · g:i a', strtotime($sale['created_at']))) ?></span></td><td><span class="sale-product-name"><?= esc($sale['product_name']) ?></span><span class="cell-sub"><?= esc($sale['quantity']) ?> <?= (int) $sale['quantity'] === 1 ? 'unit' : 'units' ?> · <?= esc($sale['customer_name'] ?: 'Walk-in customer') ?></span></td><td class="number strong"><?= money($sale['total_price']) ?></td><td><a class="sale-detail-link" href="<?= esc($detailUrl, 'attr') ?>" aria-label="<?= esc($receiptId > 0 ? 'View receipt ' . $receiptId : 'View historical sales for ' . $sale['product_name'], 'attr') ?>"><?= icon('arrow-up-right', 17) ?><span class="sr-only"><?= $receiptId > 0 ? 'Receipt #' . esc((string) $receiptId) : 'View history' ?></span></a></td></tr>
                <?php endforeach ?>
            </tbody></table></div>
            <?php else: ?><div class="empty-state"><span class="empty-state-symbol"><?= icon('receipt', 30) ?></span><h3>Your first sale starts here</h3><p>Completed sale items will appear here automatically.</p><a class="button secondary small" href="<?= site_url('pos') ?>">Open checkout <?= icon('arrow-right', 16) ?></a></div><?php endif ?>
        </section>

        <section class="panel stock-panel" id="stock-attention" aria-labelledby="stock-title">
            <div class="panel-header"><h2 id="stock-title">Low stock</h2><a class="stock-count-link" href="<?= esc($lowStockUrl, 'attr') ?>" aria-label="View all low-stock products"><?= esc($lowStockCount) ?> <?= icon('arrow-up-right', 14) ?></a></div>
            <?php if ($lowStockProducts): ?><div class="stock-list">
                <?php foreach ($lowStockProducts as $product): ?><a class="stock-row" href="<?= site_url('admin/products/' . (int) $product['id'] . '/edit') ?>"><img class="thumb" src="<?= esc(media_url($product['image'] ?? null), 'attr') ?>" alt=""><span class="stock-product-copy"><strong><?= esc($product['name']) ?></strong><small><?= money($product['price']) ?> per unit</small></span><span class="stock-quantity <?= (int) $product['stock_quantity'] === 0 ? 'out-of-stock' : '' ?>"><strong><?= esc($product['stock_quantity']) ?></strong><small><?= (int) $product['stock_quantity'] === 0 ? 'out of stock' : 'units left' ?></small></span></a><?php endforeach ?>
            </div><a class="stock-panel-footer" href="<?= esc($lowStockUrl, 'attr') ?>">Review inventory <?= icon('arrow-right', 15) ?></a><?php else: ?><div class="empty-state compact"><span class="empty-state-symbol"><?= icon('check-circle', 30) ?></span><h3><?= $productCount ? 'A well-stocked store' : 'A clear start' ?></h3><p><?= $productCount ? 'Products with 5 units or fewer will appear here.' : 'Add your first product to start tracking inventory.' ?></p><a class="text-link" href="<?= site_url('admin/products') ?>">Browse inventory <?= icon('arrow-right', 16) ?></a></div><?php endif ?>
        </section>
    </div>
</div>
<?= $this->endSection() ?>
