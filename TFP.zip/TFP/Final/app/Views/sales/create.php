<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php $errors = session('errors') ?? []; $selectedProduct = (string) form_value('product_id', ''); $selectedCustomer = (string) form_value('customer_id', ''); ?>
<a class="breadcrumb" href="<?= site_url('sales') ?>"><?= icon('arrow-left', 15) ?> Sales history</a>
<div class="page-header"><div><p class="eyebrow">AT THE COUNTER</p><h1>Record a sale</h1><p class="muted">Select a product, check the details, and make it official.</p></div><span class="subtle-label"><?= icon('lock', 15) ?> Staff transaction</span></div>
<?php if (!$products): ?>
<section class="panel empty-state large"><?= icon('package', 34) ?><h2>Your counter needs a product</h2><p>Add a product to your inventory before recording a sale.</p><?php if ((session('user')['role'] ?? '') === 'admin'): ?><a class="button primary" href="<?= site_url('products/new') ?>"><?= icon('plus', 18) ?> Add product</a><?php else: ?><p>Ask your administrator to add products before recording a sale.</p><?php endif ?></section>
<?php else: ?>
<form action="<?= site_url('sales') ?>" method="post" class="sale-layout" data-sale-form data-submit-once>
    <?= csrf_field() ?><input type="hidden" name="request_key" value="<?= esc($requestKey, 'attr') ?>">
    <section class="panel sale-details">
        <div class="panel-header"><div><p class="eyebrow">01 / TRANSACTION DETAILS</p><h2>What are we selling?</h2></div><?= icon('shopping-bag', 22) ?></div>
        <div class="form-section">
            <div class="field"><label for="product_id">Product <span class="required">*</span></label><select id="product_id" name="product_id" required aria-describedby="product-help<?= isset($errors['product_id']) ? ' product_id-error' : '' ?>"<?= isset($errors['product_id']) ? ' aria-invalid="true"' : '' ?>><option value="">Choose a product</option><?php foreach ($products as $product): ?><option value="<?= esc($product['id'], 'attr') ?>" data-name="<?= esc($product['name'], 'attr') ?>" data-price="<?= esc($product['price'], 'attr') ?>" data-stock="<?= esc($product['stock_quantity'], 'attr') ?>" data-image="<?= esc(media_url($product['image'] ?? null), 'attr') ?>"<?= $selectedProduct === (string) $product['id'] ? ' selected' : '' ?><?= (int) $product['stock_quantity'] === 0 ? ' disabled' : '' ?>><?= esc($product['name']) ?> · <?= money($product['price']) ?><?= (int) $product['stock_quantity'] === 0 ? ' · Out of stock' : '' ?></option><?php endforeach ?></select><p class="hint" id="product-help">Current pricing and stock are checked again when you submit.</p><?php if (isset($errors['product_id'])): ?><p class="field-error" id="product_id-error"><?= esc($errors['product_id']) ?></p><?php endif ?></div>
            <div class="stock-preview" data-stock-preview hidden><img class="thumb large-thumb" data-sale-image src="<?= base_url('assets/product-placeholder.svg') ?>" alt=""><div><span class="cell-main" data-sale-name></span><span class="cell-sub">Unit price <strong data-unit-price></strong></span></div><span class="badge" data-stock-badge></span></div>
            <div class="form-grid">
                <div class="field"><label for="quantity">Quantity <span class="required">*</span></label><input type="number" id="quantity" name="quantity" value="<?= esc(form_value('quantity', '1'), 'attr') ?>" min="1" step="1" required inputmode="numeric" aria-describedby="quantity-help<?= isset($errors['quantity']) ? ' quantity-error' : '' ?>"<?= isset($errors['quantity']) ? ' aria-invalid="true"' : '' ?>><p class="hint" id="quantity-help">Whole units only.</p><?php if (isset($errors['quantity'])): ?><p class="field-error" id="quantity-error"><?= esc($errors['quantity']) ?></p><?php endif ?><p class="field-error" data-quantity-warning hidden>Requested quantity exceeds available stock.</p></div>
                <div class="field"><label for="customer_id">Customer <span class="optional">Optional</span></label><select id="customer_id" name="customer_id"<?= isset($errors['customer_id']) ? ' aria-invalid="true" aria-describedby="customer_id-error"' : '' ?>><option value="">Walk-in customer</option><?php foreach ($customers as $customer): ?><option value="<?= esc($customer['id'], 'attr') ?>"<?= $selectedCustomer === (string) $customer['id'] ? ' selected' : '' ?>><?= esc($customer['full_name']) ?></option><?php endforeach ?></select><?php if (isset($errors['customer_id'])): ?><p class="field-error" id="customer_id-error"><?= esc($errors['customer_id']) ?></p><?php endif ?></div>
            </div>
        </div>
        <div class="sale-guidance"><?= icon('info', 18) ?><p>Recording this sale immediately deducts the quantity from inventory. Check the product and quantity before confirming.</p></div>
    </section>
    <aside class="panel sale-summary" aria-labelledby="summary-title">
        <p class="eyebrow">02 / REVIEW & CONFIRM</p><h2 id="summary-title">Sale summary</h2>
        <dl class="summary-lines"><div><dt>Product</dt><dd data-summary-product>Not selected</dd></div><div><dt>Customer</dt><dd data-summary-customer>Walk-in customer</dd></div><div><dt>Unit price</dt><dd data-summary-unit>—</dd></div><div><dt>Quantity</dt><dd data-summary-quantity>—</dd></div><div><dt>Recorded by</dt><dd><?= esc(session('user')['full_name']) ?></dd></div></dl>
        <div class="sale-total"><span>Total amount</span><strong data-sale-total aria-live="polite"><?= money(0) ?></strong><span class="hint">PHP · Product price × quantity</span></div>
        <button type="submit" class="button primary full-width" data-sale-submit><?= icon('check', 18) ?> Confirm & record sale</button><a class="cancel-link" href="<?= site_url('sales') ?>">Cancel transaction</a><noscript><p class="hint">Your final total will be calculated securely when you confirm this sale.</p></noscript>
    </aside>
</form>
<?php endif ?>
<?= $this->endSection() ?>
