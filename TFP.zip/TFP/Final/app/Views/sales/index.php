<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php $isAdmin = (session('user')['role'] ?? '') === 'admin'; $historyPath = $isAdmin ? 'admin/sales' : 'sales'; $hasFilters = $q !== '' || $from !== '' || $to !== '' || $sort !== 'newest'; ?>
<div class="page-header"><div><p class="eyebrow">Transaction ledger</p><h1><?= $isAdmin ? 'Sales history' : 'My sales' ?></h1><p class="muted"><?= $isAdmin ? 'A clear record of every item sold, with the original details intact.' : 'Review the sales you recorded and open their checkout receipts.' ?></p></div><a class="button primary" href="<?= site_url('pos') ?>"><?= icon('shopping-bag', 18) ?> Open checkout</a></div>
<?php if ($filterError): ?><div class="notice error" role="alert"><?= icon('alert-circle', 20) ?><span><?= esc($filterError) ?></span></div><?php endif ?>
<section class="panel" aria-label="Sales records">
    <div class="list-toolbar"><div><h2>Recorded sales</h2><p class="muted small-text">One row per product. Cart items link to their shared receipt.</p></div><span class="badge muted"><?= $isAdmin ? 'All staff' : 'Your transactions' ?></span></div>
    <form action="<?= site_url($historyPath) ?>" method="get" class="history-filters" role="search">
        <div class="field history-query"><label for="sales-search">Search records</label><input type="search" id="sales-search" name="q" value="<?= esc($q, 'attr') ?>" placeholder="Product, customer, or staff" maxlength="100"></div>
        <div class="field"><label for="sales-from">From date</label><input type="date" id="sales-from" name="from" value="<?= esc($from, 'attr') ?>"></div>
        <div class="field"><label for="sales-to">To date</label><input type="date" id="sales-to" name="to" value="<?= esc($to, 'attr') ?>"></div>
        <div class="field"><label for="sales-sort">Sort order</label><select id="sales-sort" name="sort"><option value="newest"<?= $sort === 'newest' ? ' selected' : '' ?>>Newest first</option><option value="oldest"<?= $sort === 'oldest' ? ' selected' : '' ?>>Oldest first</option></select></div>
        <div class="filter-actions"><button type="submit" class="button secondary"><?= icon('filter', 16) ?> Apply</button><?php if ($hasFilters): ?><a class="text-link" href="<?= site_url($historyPath) ?>">Clear</a><?php endif ?></div>
    </form>
    <?php
    $filterChips = [];
    $currentFilters = array_filter(['q' => $q, 'from' => $from, 'to' => $to, 'sort' => $sort === 'newest' ? '' : $sort], static fn ($value) => $value !== '');
    $historyFilterUrl = static fn (array $params): string => site_url($historyPath) . ($params ? '?' . http_build_query($params) : '');
    if ($q !== '') {
        $filterChips[] = ['label' => 'Search: ' . $q, 'url' => $historyFilterUrl(array_diff_key($currentFilters, ['q' => true]))];
    }
    if ($from !== '' || $to !== '') {
        $dateLabel = $from !== '' && $to !== '' ? $from . ' – ' . $to : ($from !== '' ? 'From ' . $from : 'Until ' . $to);
        $filterChips[] = ['label' => $dateLabel, 'url' => $historyFilterUrl(array_diff_key($currentFilters, ['from' => true, 'to' => true]))];
    }
    if ($sort === 'oldest') {
        $filterChips[] = ['label' => 'Oldest first', 'url' => $historyFilterUrl(array_diff_key($currentFilters, ['sort' => true]))];
    }
    ?>
    <?= view('components/active_filters', ['filterChips' => $filterChips]) ?>
    <?php if ($items): ?>
    <div class="table-wrap"><table class="data-table sales-table"><thead><tr><th scope="col">Transaction</th><th scope="col">Product</th><th scope="col">Customer</th><th scope="col">Staff member</th><th scope="col" class="number">Qty</th><th scope="col" class="number">Line total</th></tr></thead><tbody><?php foreach ($items as $sale): ?><tr><td><?php if ($sale['receipt_id'] !== null): ?><a class="text-link mono" href="<?= site_url('pos/receipts/' . (int) $sale['receipt_id']) ?>">#R<?= esc(str_pad((string) $sale['receipt_id'], 5, '0', STR_PAD_LEFT)) ?> <?= icon('arrow-up-right', 14) ?></a><?php else: ?><span class="cell-main mono">#S<?= esc(str_pad((string) $sale['id'], 5, '0', STR_PAD_LEFT)) ?></span><?php endif ?><span class="cell-sub"><?= esc(date('M j, Y', strtotime($sale['created_at']))) ?><br><?= esc(date('g:i a', strtotime($sale['created_at']))) ?></span></td><td><span class="cell-main"><?= esc($sale['product_name']) ?></span><span class="cell-sub"><?= money($sale['unit_price']) ?> / unit</span></td><td><?= esc($sale['customer_name'] ?: 'Walk-in customer') ?></td><td><?= esc($sale['staff_name']) ?></td><td class="number mono"><?= esc($sale['quantity']) ?></td><td class="number strong mono"><?= money($sale['total_price']) ?></td></tr><?php endforeach ?></tbody></table></div>
    <div class="pagination-wrap"><?= $pager->only(['q', 'from', 'to', 'sort'])->links() ?></div>
    <?php else: ?><div class="empty-state large"><?= icon('receipt', 32) ?><h3><?= $hasFilters ? 'No matching sales' : 'Your ledger is ready' ?></h3><p><?= $hasFilters ? 'Adjust the search or date range to find the records you need.' : 'Completed checkouts and their product details will appear here.' ?></p><?php if ($hasFilters): ?><a class="button secondary" href="<?= site_url($historyPath) ?>">Clear filters</a><?php else: ?><a class="button primary" href="<?= site_url('pos') ?>">Open checkout <?= icon('arrow-right', 16) ?></a><?php endif ?></div><?php endif ?>
</section>
<?= $this->endSection() ?>
