<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<a class="breadcrumb" href="<?= site_url('pos') ?>"><?= icon('arrow-left', 15) ?> Back to counter</a>
<div class="page-header">
    <div><p class="eyebrow">Transaction recorded</p><h1>Receipt #<?= esc($receipt['id']) ?></h1><p class="muted">Your sale is saved and inventory has been updated.</p></div>
    <a class="button primary" href="<?= site_url('pos') ?>"><?= icon('plus', 18) ?> New sale</a>
</div>
<section class="panel receipt-panel" aria-labelledby="receipt-heading">
    <div class="panel-header"><div><h2 id="receipt-heading">Sale details</h2><p class="muted"><?= esc(date('M j, Y · g:i A', strtotime($receipt['created_at']))) ?> · <?= esc(date_default_timezone_get()) ?></p></div><span class="badge success"><?= icon('check', 14) ?> Completed</span></div>
    <dl class="receipt-metadata summary-lines">
        <div><dt>Customer</dt><dd><?= esc($receipt['customer_name'] ?? 'Walk-in customer') ?></dd></div>
        <div><dt>Recorded by</dt><dd><?= esc($receipt['staff_name']) ?></dd></div>
        <div><dt>Total units</dt><dd><?= esc($receipt['quantity_total']) ?></dd></div>
    </dl>
    <div class="table-wrap">
        <table class="data-table receipt-table"><thead><tr><th scope="col">Product</th><th scope="col" class="numeric">Unit price</th><th scope="col" class="numeric">Quantity</th><th scope="col" class="numeric">Amount</th></tr></thead>
            <tbody><?php foreach ($lines as $line): ?><tr><td><span class="cell-main"><?= esc($line['product_name']) ?></span><span class="cell-sub">Sale #<?= esc($line['id']) ?></span></td><td class="numeric"><?= money($line['unit_price']) ?></td><td class="numeric"><?= esc($line['quantity']) ?></td><td class="numeric"><strong><?= money($line['total_price']) ?></strong></td></tr><?php endforeach ?></tbody>
            <tfoot><tr><th scope="row" colspan="3">Total</th><td class="numeric"><strong><?= money($receipt['total_price']) ?></strong></td></tr></tfoot>
        </table>
    </div>
    <div class="form-actions"><p class="hint">PHP · Original product prices and names are retained on this receipt.</p><a class="button secondary" href="<?= site_url('sales') ?>"><?= icon('receipt', 16) ?> View sales history</a></div>
</section>
<?= $this->endSection() ?>
