<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php
$errors = session('errors') ?? [];
$selectedCustomer = isset($selectedCustomer) && is_scalar($selectedCustomer) ? (string) $selectedCustomer : form_value('customer_id', '');
$catalogData = array_map(static fn (array $product): array => [
    'id' => (int) $product['id'],
    'name' => (string) $product['name'],
    'price' => (string) $product['price'],
    'stock' => (int) $product['stock_quantity'],
    'image' => media_url($product['image'] ?? null),
], $products);
?>
<div class="pos-page" data-pos>
    <div class="page-header pos-heading">
        <div><h1>Point of sale</h1><p class="muted">Choose products, then review your order.</p></div>
        <div class="pos-heading-meta"><a class="button secondary" href="<?= site_url('sales') ?>"><?= icon('receipt', 17) ?> Sales history</a></div>
    </div>
    <noscript><div class="notice error" role="status"><?= icon('info', 18) ?><span>The shopping cart needs JavaScript. You can still <a class="text-link" href="<?= site_url('sales/new') ?>">record a single-product sale</a>.</span></div></noscript>
    <?php if (isset($errors['cart'])): ?><div class="notice error" role="alert"><?= icon('alert-circle', 19) ?><span><?= esc($errors['cart']) ?></span></div><?php endif ?>
    <div class="cart-error notice error" data-cart-error role="alert" tabindex="-1" hidden></div>
    <div class="pos-workspace">
        <section class="pos-catalog" aria-labelledby="product-catalog-title">
            <div class="pos-catalog-head"><div class="pos-catalog-title"><h2 id="product-catalog-title">Products</h2></div><span class="pos-results" data-catalog-count aria-live="polite"><?= count($products) ?> <?= count($products) === 1 ? 'product' : 'products' ?></span></div>
            <div class="pos-toolbar">
                <div class="search-form pos-search">
                    <?= icon('search', 18) ?><label class="sr-only" for="catalog-search">Search products by name or ID</label><input type="search" id="catalog-search" placeholder="Search products or #ID" autocomplete="off" data-catalog-search maxlength="100" aria-describedby="product-search-hint"><button class="catalog-search-clear" type="button" data-clear-product-search aria-label="Clear product search" title="Clear product search" hidden><?= icon('x', 16) ?></button><span class="search-shortcut" aria-hidden="true"><kbd>F2</kbd></span><span class="sr-only" id="product-search-hint">Search by product name or ID, such as #12. Press F2 to focus search.</span>
                </div>
                <div class="pos-filters" role="group" aria-label="Filter products by stock"><button class="pos-filter" type="button" data-stock-filter="all" aria-pressed="true"><?= icon('package', 15) ?><span>All products</span></button><button class="pos-filter" type="button" data-stock-filter="available" aria-pressed="false"><?= icon('check', 15) ?><span>Available</span></button><button class="pos-filter" type="button" data-stock-filter="low" aria-pressed="false"><?= icon('alert-circle', 15) ?><span>Low stock</span></button></div>
            </div>
            <?php if ($products): ?>
            <div class="product-grid" data-product-grid>
                <?php foreach ($products as $product): $stock = (int) $product['stock_quantity']; ?>
                <article class="product-tile<?= $stock === 0 ? ' unavailable' : '' ?>" data-product-tile data-product-id="<?= (int) $product['id'] ?>">
                    <div class="product-image"><img src="<?= esc(media_url($product['image'] ?? null), 'attr') ?>" alt="" loading="lazy" width="320" height="240"><span class="product-code">#<?= (int) $product['id'] ?></span><?php if ($stock <= 5): ?><span class="badge <?= $stock === 0 ? 'danger' : 'warning' ?>"><?= $stock === 0 ? 'Out of stock' : 'Low stock' ?></span><?php endif ?></div>
                    <div class="product-tile-body">
                        <h2 class="product-tile-name"><?= esc($product['name']) ?></h2>
                        <div class="product-tile-meta"><strong class="product-price"><?= money($product['price']) ?></strong><span class="product-stock muted"><span class="product-stock-dot<?= $stock === 0 ? ' is-empty' : ($stock <= 5 ? ' is-low' : '') ?>" aria-hidden="true"></span><?= esc(number_format($stock)) ?> in stock</span></div>
                        <button class="button secondary product-add" type="button" data-add-product="<?= (int) $product['id'] ?>"<?= $stock === 0 ? ' disabled' : '' ?> aria-label="Add <?= esc($product['name'], 'attr') ?> to cart"><span class="product-add-icon"><?= icon('plus', 16) ?></span><span data-add-label><?= $stock === 0 ? 'Unavailable' : 'Add to order' ?></span><span class="product-in-cart" data-product-in-cart hidden></span></button>
                    </div>
                </article>
                <?php endforeach ?>
            </div>
            <div class="panel empty-state" data-catalog-empty hidden><?= icon('search', 29) ?><h2>No products found</h2><p>Try another name or change the stock filter.</p><button class="button secondary" type="button" data-reset-catalog>Clear filters</button></div>
            <?php else: ?><div class="panel empty-state large"><?= icon('package', 34) ?><h2>Your catalog is waiting</h2><p>Ask an administrator to add products before taking your first order.</p><?php if ((session('user')['role'] ?? '') === 'admin'): ?><a class="button primary" href="<?= site_url('products/new') ?>"><?= icon('plus', 17) ?> Add product</a><?php endif ?></div><?php endif ?>
        </section>
        <aside class="panel cart-panel" id="cart-panel" aria-labelledby="cart-title">
            <div class="cart-heading">
                <div class="cart-title-row"><span class="cart-heading-icon" aria-hidden="true"><?= icon('shopping-bag', 19) ?></span><div><h2 id="cart-title">Current order <span class="cart-count" data-cart-line-count>0</span></h2></div></div>
                <button class="text-link cart-clear" type="button" data-clear-cart disabled><?= icon('trash', 15) ?><span>Clear</span></button>
            </div>
            <p class="cart-feedback" data-cart-feedback aria-hidden="true" hidden></p>
            <div class="cart-empty" data-cart-empty><span class="cart-empty-icon" aria-hidden="true"><?= icon('shopping-bag', 30) ?></span><h3>Your order is empty</h3><p>Choose a product from the catalog to get started.</p></div>
            <ul class="cart-lines" data-cart-lines aria-label="Order items"></ul>
            <form action="<?= site_url('pos/checkout') ?>" method="post" data-checkout-form class="cart-footer">
                <?= csrf_field() ?><input type="hidden" name="request_key" value="<?= esc($requestKey, 'attr') ?>"><input type="hidden" name="cart" value="[]" data-cart-payload>
                <div class="field cart-customer-field"><label class="cart-customer-label" for="cart-customer"><span class="cart-customer-icon" aria-hidden="true"><?= icon('user', 15) ?></span>Customer <span class="optional">Optional</span></label><select id="cart-customer" name="customer_id" data-cart-customer<?= isset($errors['customer_id']) ? ' aria-invalid="true" aria-describedby="customer-error"' : '' ?>><option value="">Walk-in customer</option><?php foreach ($customers as $customer): ?><option value="<?= (int) $customer['id'] ?>"<?= $selectedCustomer === (string) $customer['id'] ? ' selected' : '' ?>><?= esc($customer['full_name']) ?></option><?php endforeach ?></select><?php if (isset($errors['customer_id'])): ?><p id="customer-error" class="field-error"><?= esc($errors['customer_id']) ?></p><?php endif ?></div>
                <div class="cart-breakdown"><div class="cart-subtotal"><span>Subtotal <span data-cart-units-label>(0 items)</span></span><strong data-cart-subtotal><?= money(0) ?></strong></div></div>
                <div class="cart-total"><div class="cart-total-label"><span>Total</span><span class="cart-total-caption">PHP</span></div><strong data-cart-total aria-live="polite"><?= money(0) ?></strong></div>
                <button class="button primary full-width cart-checkout" type="submit" data-checkout-button disabled><span data-checkout-button-label>Review order</span><?= icon('arrow-right', 18) ?></button>
                <p class="cart-note"><?= icon('shield', 13) ?><span>Prices and stock verified at checkout.</span></p>
            </form>
        </aside>
    </div>
    <a class="pos-mobile-cart" href="#cart-panel" data-mobile-cart><span><?= icon('shopping-bag', 18) ?> View order <span data-mobile-cart-count>0</span></span><strong data-mobile-cart-total><?= money(0) ?></strong><?= icon('arrow-down', 16) ?></a>
    <dialog class="checkout-dialog" data-checkout-dialog aria-labelledby="checkout-review-title" aria-describedby="checkout-review-description">
        <div class="checkout-review"><span class="checkout-review-icon" aria-hidden="true"><?= icon('receipt', 24) ?></span><p class="eyebrow">Order review</p><h2 id="checkout-review-title">Ready to record this sale?</h2><p class="muted" id="checkout-review-description">Check the products, quantities, and customer. Confirming this sale updates inventory immediately.</p><ul class="checkout-review-lines" data-review-lines></ul><dl class="summary-lines"><div><dt>Customer</dt><dd data-review-customer>Walk-in customer</dd></div><div><dt>Items</dt><dd data-review-quantity>0</dd></div></dl><div class="cart-total"><span>Total amount</span><strong data-review-total><?= money(0) ?></strong></div><div class="dialog-actions"><button class="button secondary" type="button" data-review-cancel autofocus>Keep editing</button><button class="button primary" type="button" data-review-confirm><?= icon('check', 17) ?> <span data-review-confirm-label>Confirm sale</span></button></div></div>
    </dialog>
    <template data-cart-line-template>
        <li class="cart-line"><img class="cart-line-image" data-line-image alt=""><div class="cart-line-details"><strong class="cart-line-name" data-line-name></strong><span class="cart-line-price" data-line-price></span><div class="cart-line-controls"><div class="cart-quantity"><button class="cart-quantity-button" type="button" data-line-decrease aria-label="Decrease quantity"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M5 12h14"/></svg></button><input class="cart-quantity-input" data-line-quantity type="number" min="1" step="1" inputmode="numeric" aria-label="Quantity"><button class="cart-quantity-button" type="button" data-line-increase aria-label="Increase quantity"><?= icon('plus', 14) ?></button></div><span class="cart-line-stock" data-line-stock></span></div></div><div class="cart-line-actions"><strong class="cart-line-total" data-line-total></strong><button class="cart-remove" type="button" data-line-remove aria-label="Remove product from order"><?= icon('x', 14) ?></button></div></li>
    </template>
    <script type="application/json" data-pos-catalog><?= json_encode($catalogData, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) ?></script>
    <script type="application/json" data-pos-initial><?= json_encode($initialCart ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) ?></script>
    <p class="sr-only" data-cart-announcement role="status" aria-live="polite" aria-atomic="true"></p>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script src="<?= base_url('assets/cart.js') ?>?v=cobalt-reference-7" defer></script>
<?= $this->endSection() ?>
