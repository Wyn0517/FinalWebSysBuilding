<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

/** Optional demonstration inventory. Never provisions a login or fictional sales. */
class DemoSeeder extends Seeder
{
    public function run(): void
    {
        $now = date('Y-m-d H:i:s');
        $products = [
            ['name' => 'Everyday tote', 'price' => '249.00', 'stock_quantity' => 24],
            ['name' => 'Ceramic cup', 'price' => '189.00', 'stock_quantity' => 16],
            ['name' => 'Pocket notebook', 'price' => '79.00', 'stock_quantity' => 4],
            ['name' => 'Steel water bottle', 'price' => '499.00', 'stock_quantity' => 12],
        ];
        foreach ($products as $product) {
            // Include archived records: rerunning the seeder must not recreate archived stock.
            if ($this->db->table('products')->where('name', $product['name'])->countAllResults() === 0) {
                $this->db->table('products')->insert($product + ['created_at' => $now, 'updated_at' => $now]);
            }
        }
        if ($this->db->table('customers')->where('email', 'sample@example.com')->countAllResults() === 0) {
            $this->db->table('customers')->insert([
                'full_name' => 'Sample customer', 'email' => 'sample@example.com',
                'phone' => null, 'created_at' => $now, 'updated_at' => $now,
            ]);
        }
    }
}
