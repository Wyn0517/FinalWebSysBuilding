<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/** The assignment schema, with archival and immutable sales receipts. */
class CreatePosTables extends Migration
{
    public function up(): void
    {
        $id = ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true];
        $time = ['type' => 'DATETIME'];
        $nullableTime = ['type' => 'DATETIME', 'null' => true];
        $options = $this->db->DBDriver === 'MySQLi' ? ['ENGINE' => 'InnoDB'] : [];

        $this->forge->addField([
            'id' => $id,
            'name' => ['type' => 'VARCHAR', 'constraint' => 100],
            'price' => ['type' => 'DECIMAL', 'constraint' => '10,2'],
            'stock_quantity' => ['type' => 'INT', 'unsigned' => true, 'default' => 0],
            'image' => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'created_at' => $time, 'updated_at' => $nullableTime, 'deleted_at' => $nullableTime,
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addField('CHECK (price >= 0 AND price <= 99999999.99 AND stock_quantity >= 0 AND stock_quantity <= 2147483647)');
        $this->forge->addKey('name');
        $this->forge->addKey('deleted_at');
        $this->forge->createTable('products', false, $options);

        $this->forge->addField([
            'id' => $id,
            'full_name' => ['type' => 'VARCHAR', 'constraint' => 100],
            'email' => ['type' => 'VARCHAR', 'constraint' => 100],
            'phone' => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'created_at' => $time, 'updated_at' => $nullableTime, 'deleted_at' => $nullableTime,
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('full_name');
        $this->forge->addKey('deleted_at');
        $this->forge->createTable('customers', false, $options);

        $this->forge->addField([
            'id' => $id,
            'username' => ['type' => 'VARCHAR', 'constraint' => 50],
            'full_name' => ['type' => 'VARCHAR', 'constraint' => 100],
            'password' => ['type' => 'VARCHAR', 'constraint' => 255],
            'avatar' => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'role' => ['type' => 'VARCHAR', 'constraint' => 20, 'default' => 'cashier'],
            'is_active' => ['type' => 'TINYINT', 'constraint' => 1, 'unsigned' => true, 'default' => 1],
            'created_at' => $time, 'updated_at' => $nullableTime, 'deleted_at' => $nullableTime,
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addField("CHECK (role IN ('admin', 'cashier') AND is_active IN (0, 1))");
        $this->forge->addUniqueKey('username');
        $this->forge->addKey(['role', 'is_active', 'deleted_at']);
        $this->forge->createTable('users', false, $options);

        $this->forge->addField([
            'id' => $id,
            'product_id' => ['type' => 'INT', 'unsigned' => true],
            'customer_id' => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'sold_by' => ['type' => 'INT', 'unsigned' => true],
            'quantity' => ['type' => 'INT', 'unsigned' => true],
            'unit_price' => ['type' => 'DECIMAL', 'constraint' => '10,2'],
            'total_price' => ['type' => 'DECIMAL', 'constraint' => '10,2'],
            'request_key' => ['type' => 'VARCHAR', 'constraint' => 64],
            'product_name' => ['type' => 'VARCHAR', 'constraint' => 100],
            'customer_name' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'staff_name' => ['type' => 'VARCHAR', 'constraint' => 100],
            'created_at' => $time,
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addField('CHECK (quantity > 0 AND quantity <= 2147483647 AND total_price >= 0 AND total_price <= 99999999.99 AND unit_price >= 0 AND unit_price <= 99999999.99)');
        $this->forge->addUniqueKey('request_key');
        $this->forge->addKey('created_at');
        $this->forge->addKey('product_id');
        $this->forge->addKey('customer_id');
        $this->forge->addKey('sold_by');
        $this->forge->addForeignKey('product_id', 'products', 'id', 'RESTRICT', 'RESTRICT');
        $this->forge->addForeignKey('customer_id', 'customers', 'id', 'RESTRICT', 'RESTRICT');
        $this->forge->addForeignKey('sold_by', 'users', 'id', 'RESTRICT', 'RESTRICT');
        $this->forge->createTable('sales', false, $options);
    }

    public function down(): void
    {
        foreach (['sales', 'users', 'customers', 'products'] as $table) {
            $this->forge->dropTable($table);
        }
    }
}
