<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Groups sale rows into immutable receipts without changing existing sales. */
class AddReceipts extends Migration
{
    public function up(): void
    {
        $id = ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true];
        $reference = ['type' => 'INT', 'unsigned' => true];
        $options = $this->db->DBDriver === 'MySQLi' ? ['ENGINE' => 'InnoDB'] : [];

        $this->forge->addField([
            'id' => $id,
            'customer_id' => $reference + ['null' => true],
            'sold_by' => $reference,
            'total_price' => ['type' => 'DECIMAL', 'constraint' => '10,2'],
            'quantity_total' => ['type' => 'INT', 'unsigned' => true],
            'created_at' => ['type' => 'DATETIME'],
            'request_key' => ['type' => 'VARCHAR', 'constraint' => 64],
            'customer_name' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'staff_name' => ['type' => 'VARCHAR', 'constraint' => 100],
        ]);
        $this->forge->addField('CHECK (total_price >= 0 AND total_price <= 99999999.99 AND quantity_total >= 1 AND quantity_total <= 2147483647)');
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('request_key');
        $this->forge->addKey('created_at');
        $this->forge->addKey('sold_by');
        $this->forge->addKey('customer_id');
        $this->forge->addForeignKey('customer_id', 'customers', 'id', 'RESTRICT', 'RESTRICT');
        $this->forge->addForeignKey('sold_by', 'users', 'id', 'RESTRICT', 'RESTRICT');
        $this->forge->createTable('receipts', false, $options);

        $this->forge->addField([
            'id' => $id,
            'receipt_id' => $reference,
            'sale_id' => $reference,
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('receipt_id');
        $this->forge->addUniqueKey('sale_id');
        $this->forge->addForeignKey('receipt_id', 'receipts', 'id', 'RESTRICT', 'RESTRICT');
        $this->forge->addForeignKey('sale_id', 'sales', 'id', 'RESTRICT', 'RESTRICT');
        $this->forge->createTable('receipt_lines', false, $options);
    }

    public function down(): void
    {
        $this->forge->dropTable('receipt_lines');
        $this->forge->dropTable('receipts');
    }
}
