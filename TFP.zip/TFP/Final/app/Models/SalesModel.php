<?php

namespace App\Models;

use CodeIgniter\Model;

class SalesModel extends Model
{
    protected $table = 'sales';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $allowedFields = ['product_id', 'customer_id', 'sold_by', 'quantity', 'unit_price', 'total_price', 'request_key', 'product_name', 'customer_name', 'staff_name', 'created_at'];
    protected $useTimestamps = false;
}
