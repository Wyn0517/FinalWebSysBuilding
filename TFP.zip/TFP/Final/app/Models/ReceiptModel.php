<?php

namespace App\Models;

use CodeIgniter\Model;

class ReceiptModel extends Model
{
    protected $table = 'receipts';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $allowedFields = [
        'customer_id', 'sold_by', 'total_price', 'quantity_total', 'created_at',
        'request_key', 'customer_name', 'staff_name',
    ];
    protected $useTimestamps = false;
}
