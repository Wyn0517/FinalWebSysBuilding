<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->setAutoRoute(false);
$routes->get('login', 'Auth::login');
$routes->post('login', 'Auth::authenticate');

// Keep the original CRUD URLs and expose admin aliases through the same controllers.
// Every registration below uses explicit HTTP verbs; automatic routing stays off.
$crud = static function (RouteCollection $routes, string $path, string $controller): void {
    $routes->get($path, $controller . '::index');
    $routes->get($path . '/new', $controller . '::create');
    $routes->post($path, $controller . '::store');
    $routes->get($path . '/(:num)/edit', $controller . '::edit/$1');
    $routes->post($path . '/(:num)', $controller . '::update/$1');
    $routes->post($path . '/(:num)/delete', $controller . '::delete/$1');
};

$routes->group('', ['filter' => 'auth'], static function ($routes) use ($crud) {
    $routes->get('/', 'Entry::index');
    $routes->post('logout', 'Auth::logout');
    $routes->get('media/(:segment)', 'Media::show/$1');
    $routes->get('pos', 'Checkout::index');
    $routes->post('pos/checkout', 'Checkout::store');
    $routes->get('pos/receipts/(:num)', 'Checkout::receipt/$1');
    $routes->get('profile', 'Profile::index');
    $routes->post('profile', 'Profile::update');

    // The legacy single-product sale form is retained. Sales::index scopes cashiers
    // to their own history, and receipt ownership is checked by Checkout itself.
    $routes->get('sales', 'Sales::index');
    $routes->get('sales/new', 'Sales::create');
    $routes->post('sales', 'Sales::store');

    $routes->group('', ['filter' => 'admin'], static function ($routes) use ($crud) {
        $crud($routes, 'products', 'Products');
        $crud($routes, 'customers', 'Customers');
        $crud($routes, 'staff', 'Staff');
    });
    $routes->group('admin', ['filter' => 'admin'], static function ($routes) use ($crud) {
        $routes->get('/', 'Entry::index');
        $routes->get('dashboard', 'Dashboard::index');
        $routes->get('sales', 'Sales::index');
        $crud($routes, 'products', 'Products');
        $crud($routes, 'customers', 'Customers');
        $crud($routes, 'users', 'Staff');
    });
});
