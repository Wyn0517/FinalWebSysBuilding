<?php

namespace App\Filters;

use App\Models\UserModel;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        $id = $session->get('user_id');
        $user = $id ? (new UserModel())->find($id) : null;
        if (!$user || !(bool) $user['is_active']) {
            $session->remove(['user_id', 'user']);
            return redirect()->to(site_url('login'))->with('error', 'Please sign in to continue.');
        }
        $session->set('user', array_intersect_key($user, array_flip(['id', 'username', 'full_name', 'role', 'avatar'])));
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        $response->setHeader('Cache-Control', 'no-store, private');
    }
}
