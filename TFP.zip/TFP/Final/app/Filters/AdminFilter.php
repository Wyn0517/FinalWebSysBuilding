<?php

namespace App\Filters;

use App\Models\UserModel;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AdminFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $user = (new UserModel())->find((int) session()->get('user_id'));
        if (!$user || !(bool) $user['is_active'] || $user['role'] !== 'admin') {
            return service('response')->setStatusCode(403)->setContentType('text/plain')
                ->setBody('Access denied. This management page is restricted to administrators. Use the POS workspace for sales.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {}
}
