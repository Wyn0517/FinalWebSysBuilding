<?php

namespace App\Commands;

use App\Models\UserModel;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use RuntimeException;
use Throwable;

/** Creates an administrator without shipping reusable default credentials. */
class CreateAdmin extends BaseCommand
{
    protected $group = 'POS';
    protected $name = 'pos:admin';
    protected $description = 'Create an administrator using an interactive, hidden password prompt.';
    protected $usage = 'pos:admin';

    public function run(array $params)
    {
        // Check setup before asking for credentials. A missing table used to cause
        // Model::first() to call getFirstRow() on a failed query result.
        try {
            $db = db_connect();
            if (!$db->tableExists('users')) {
                CLI::error('Database setup is incomplete. Run php spark migrate --all from this project folder, then try php spark pos:admin again.');
                return EXIT_ERROR;
            }
            $columns = $db->getFieldNames($db->prefixTable('users'));
            $required = ['id', 'username', 'full_name', 'password', 'avatar', 'role', 'is_active', 'created_at', 'updated_at', 'deleted_at'];
            if (!is_array($columns) || array_diff($required, array_map('strtolower', $columns)) !== []) {
                CLI::error('The staff database schema is incomplete. Back up your data, check the .env database settings, and run php spark migrate --all. Do not reset or delete an existing database.');
                return EXIT_ERROR;
            }
        } catch (Throwable $exception) {
            CLI::error('The database could not be checked. Verify the .env database settings and writable permissions, then run php spark migrate --all.');
            return EXIT_ERROR;
        }

        $username = strtolower(trim((string) (getenv('POS_ADMIN_USERNAME') ?: CLI::prompt('Username'))));
        $name = trim((string) (getenv('POS_ADMIN_NAME') ?: CLI::prompt('Full name')));
        $validation = service('validation');
        $validation->setRules([
            'username' => 'required|min_length[3]|max_length[50]|regex_match[/\A[a-z0-9_.-]+\z/]',
            'full_name' => 'required|max_length[100]',
        ]);
        if (!$validation->run(['username' => $username, 'full_name' => $name])) {
            foreach ($validation->getErrors() as $error) {
                CLI::error($error);
            }
            return EXIT_ERROR;
        }

        $users = new UserModel();
        try {
            if ($users->withDeleted()->where('username', $username)->first() !== null) {
                CLI::error('That username is already reserved. Choose another username.');
                return EXIT_ERROR;
            }
        } catch (Throwable $exception) {
            CLI::error('The staff account could not be checked. Verify database setup and run php spark migrate --all before retrying.');
            return EXIT_ERROR;
        }

        try {
            // Environment values support secret injection by a deployment platform or CI.
            // Never pass a password as a command argument or put one in the repository.
            $injected = getenv('POS_ADMIN_PASSWORD');
            $password = $injected !== false && $injected !== '' ? $injected : $this->hiddenPassword('Password');
            if ($injected === false || $injected === '') {
                $confirmation = $this->hiddenPassword('Confirm password');
                if (!hash_equals($password, $confirmation)) {
                    CLI::error('The passwords do not match.');
                    return EXIT_ERROR;
                }
                unset($confirmation);
            }
            putenv('POS_ADMIN_PASSWORD');
            if (mb_strlen($password, 'UTF-8') < 12 || strlen($password) > 72) {
                CLI::error('Use at least 12 characters and no more than 72 bytes. A long, unique passphrase is recommended.');
                return EXIT_ERROR;
            }
            $hash = password_hash($password, PASSWORD_DEFAULT);
            unset($password, $injected);
            $created = $users->insert([
                'username' => $username, 'full_name' => $name, 'password' => $hash,
                'role' => 'admin', 'is_active' => 1,
            ]);
            if ($created === false) {
                throw new RuntimeException('Account was not inserted.');
            }
            CLI::write('Administrator created. Sign in using the credentials you selected.', 'green');
            return EXIT_SUCCESS;
        } catch (Throwable $exception) {
            // Do not echo database errors or provisioning secrets to logs or the console.
            CLI::error('Could not create the account. Check database setup and terminal support.');
            return EXIT_ERROR;
        }
    }

    private function hiddenPassword(string $label): string
    {
        if (PHP_OS_FAMILY === 'Windows') {
            if (!function_exists('proc_open')) {
                throw new RuntimeException('Hidden input requires proc_open or a deployment secret.');
            }
            CLI::write($label . ' (hidden)');
            $script = '$s=Read-Host -AsSecureString; $p=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); try {[Console]::Out.Write([Runtime.InteropServices.Marshal]::PtrToStringBSTR($p))} finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p)}';
            $process = proc_open(['powershell', '-NoProfile', '-Command', $script], [0 => STDIN, 1 => ['pipe', 'w'], 2 => STDERR], $pipes);
            if (!is_resource($process)) {
                throw new RuntimeException('Cannot start hidden terminal input.');
            }
            $password = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            if (proc_close($process) !== 0 || $password === false) {
                throw new RuntimeException('Hidden terminal input failed.');
            }
            return rtrim($password, "\r\n");
        }

        if (!function_exists('shell_exec') || !function_exists('exec') || !stream_isatty(STDIN)) {
            throw new RuntimeException('Use a terminal or inject POS_ADMIN_PASSWORD through your deployment environment.');
        }
        $state = shell_exec('stty -g 2>/dev/null');
        if (!is_string($state) || trim($state) === '') {
            throw new RuntimeException('Cannot protect terminal password input.');
        }
        CLI::print($label . ': ');
        exec('stty -echo', $unused, $status);
        if ($status !== 0) {
            throw new RuntimeException('Cannot protect terminal password input.');
        }
        try {
            $password = fgets(STDIN);
            if ($password === false) {
                throw new RuntimeException('No password was entered.');
            }
            return rtrim($password, "\r\n");
        } finally {
            exec('stty ' . escapeshellarg(trim($state)));
            CLI::newLine();
        }
    }
}
