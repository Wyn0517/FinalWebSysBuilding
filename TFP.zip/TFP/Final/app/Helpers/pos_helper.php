<?php

function money($amount): string
{
    return '₱' . number_format((float) $amount, 2, '.', ',');
}

function media_url(?string $filename, string $kind = 'product'): string
{
    if ($filename && preg_match('/^[a-f0-9]{32}\.(?:png|jpg)$/D', $filename)
        && is_file(WRITEPATH . 'uploads/' . $filename)) {
        return site_url('media/' . $filename);
    }
    return base_url('assets/' . ($kind === 'avatar' ? 'avatar' : 'product') . '-placeholder.svg');
}

function icon(string $name, int $size = 20): string
{
    $paths = [
        'grid' => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'package' => '<path d="m12 3 9 5v9l-9 5-9-5V8zM3 8l9 5 9-5M12 13v9M7.5 5.5l9 5"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/><circle cx="9" cy="7" r="4"/>',
        'user' => '<circle cx="12" cy="7" r="4"/><path d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2"/>',
        'receipt' => '<path d="m4 3 2 1 2-1 2 1 2-1 2 1 2-1 2 1 2-1v18l-2-1-2 1-2-1-2 1-2-1-2 1-2-1-2 1zM8 8h8M8 12h8M8 16h4"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'search' => '<circle cx="10.5" cy="10.5" r="7.5"/><path d="m16 16 5 5"/>',
        'arrow-right' => '<path d="M5 12h14m-6-6 6 6-6 6"/>',
        'arrow-left' => '<path d="M19 12H5m6-6-6 6 6 6"/>',
        'arrow-up-right' => '<path d="M7 17 17 7M7 7h10v10"/>',
        'chevron-down' => '<path d="m6 9 6 6 6-6"/>',
        'chevron-left' => '<path d="m15 6-6 6 6 6"/>',
        'chevron-right' => '<path d="m9 6 6 6-6 6"/>',
        'edit' => '<path d="m16 3 5 5-12 12-6 1 1-6zM14 5l5 5"/>',
        'trash' => '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
        'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/>',
        'moon' => '<path d="M21 12.8A9 9 0 0 1 11.2 3 9 9 0 1 0 21 12.8Z"/>',
        'menu' => '<path d="M3 6h18M3 12h18M3 18h18"/>',
        'x' => '<path d="m6 6 12 12M6 18 18 6"/>',
        'log-out' => '<path d="M9 21H3V3h6M9 12h12m-4-4 4 4-4 4"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
        'alert-circle' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 17h.01"/>',
        'check-circle' => '<circle cx="12" cy="12" r="9"/><path d="m7 12 3 3 7-7"/>',
        'image' => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1"/><path d="m21 15-6-6L3 21"/>',
        'shopping-bag' => '<path d="M5 7h14l2 14H3zM8 7V5a4 4 0 0 1 8 0v2"/>',
        'shield' => '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6z"/>',
        'upload' => '<path d="M12 16V3m-5 5 5-5 5 5M3 16v5h18v-5"/>',
        'arrow-down' => '<path d="M12 4v16m-6-6 6 6 6-6"/>',
        'lock' => '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
        'info' => '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
        'minus' => '<path d="M5 12h14"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
        'chart' => '<path d="M3 3v18h18M7 14l4-4 4 2 5-6"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'filter' => '<path d="M4 5h16l-6 7v7l-4 2v-9z"/>',
        'eye' => '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    ];
    $aliases = ['layout-dashboard' => 'grid', 'dashboard' => 'grid', 'box' => 'package', 'pencil' => 'edit'];
    $name = $aliases[$name] ?? $name;
    $size = max(12, min(48, $size));
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size
        . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        . ($paths[$name] ?? $paths['package']) . '</svg>';
}

/** Redisplay only scalar form values, even after a malformed array submission. */
function form_value(string $key, $default = ''): string
{
    $value = old($key, $default, false);
    return is_scalar($value) ? (string) $value : '';
}
