<?php

namespace App\Controllers;

use App\Libraries\ImageUpload;
use App\Models\UserModel;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

/** Self-service profile updates never accept account IDs, roles or access flags. */
class Profile extends BaseController
{
    public function index()
    {
        $item = $this->current();
        if ($item === null) {
            return $this->signedOut();
        }
        unset($item['password']);
        return view('profile/index', ['title' => 'My profile', 'item' => $item]);
    }

    public function update()
    {
        $item = $this->current();
        if ($item === null) {
            return $this->signedOut();
        }
        $data = $this->request->getPost(['full_name', 'current_password', 'password', 'password_confirm']);
        if (is_string($data['full_name'])) {
            $data['full_name'] = trim($data['full_name']);
        }
        $changingPassword = ($data['password'] ?? '') !== '' && $data['password'] !== null;
        $rules = [
            'full_name' => 'required|max_length[100]',
            'current_password' => $changingPassword ? 'required|max_length[72]' : 'permit_empty|max_length[72]',
            'password' => $changingPassword ? 'required|min_length[12]|max_length[72]' : 'permit_empty',
            'password_confirm' => $changingPassword ? 'required|matches[password]' : 'permit_empty',
        ];
        $file = $this->request->getFile('avatar');
        if ($file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE) {
            $rules['avatar'] = 'uploaded[avatar]|is_image[avatar]|mime_in[avatar,image/jpeg,image/png,image/webp]|ext_in[avatar,jpg,jpeg,png,webp]|max_size[avatar,2048]|max_dims[avatar,6000,6000]';
        }
        if (!$this->validateData($data, $rules)) {
            return $this->failure($data, $this->validator->getErrors());
        }
        if (!$changingPassword && ($data['password_confirm'] ?? '') !== '' && $data['password_confirm'] !== null) {
            return $this->failure($data, ['password' => 'Enter the new password too, or leave all password fields empty.']);
        }
        if ($changingPassword && strlen($data['password']) > 72) {
            return $this->failure($data, ['password' => 'Use at most 72 bytes for the new password.']);
        }
        if ($changingPassword && !password_verify($data['current_password'], $item['password'])) {
            return $this->failure($data, ['current_password' => 'Your current password is incorrect.']);
        }

        $images = new ImageUpload();
        $image = null;
        try {
            $image = $images->store($file);
            $record = ['full_name' => $data['full_name'], 'updated_at' => date('Y-m-d H:i:s')];
            if ($image !== null) {
                $record['avatar'] = $image;
            }
            if ($changingPassword) {
                $record['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }

            // An administrator's simultaneous reset or account revocation must not
            // be overwritten by a form based on an older authenticated account.
            $db = db_connect();
            $ok = $db->table('users')->where('id', $item['id'])->where('deleted_at', null)
                ->where('is_active', 1)->where('password', $item['password'])->update($record);
            if (!$ok) {
                throw new RuntimeException('Profile update failed');
            }
            if ($db->affectedRows() === 0) {
                $unchanged = $this->current();
                if (!$unchanged || !hash_equals($item['password'], $unchanged['password'])) {
                    throw new RuntimeException('The account changed during profile update');
                }
            }
        } catch (InvalidArgumentException $e) {
            $images->remove($image);
            return $this->failure($data, ['avatar' => $e->getMessage()]);
        } catch (Throwable $e) {
            $images->remove($image);
            log_message('error', 'A self-service profile update could not be completed.');
            return $this->failure($data, [], 'Your profile could not be saved. Refresh the page and try again.');
        }
        if ($image !== null) {
            $images->remove($item['avatar']);
        }
        if ($changingPassword) {
            session()->regenerate(true);
            session()->remove(['sale_keys', 'checkout_keys']);
        }
        // Refresh only safe display fields. The next AuthFilter rechecks access.
        $safe = session('user') ?? [];
        $safe['full_name'] = $record['full_name'];
        if ($image !== null) {
            $safe['avatar'] = $image;
        }
        session()->set('user', $safe);
        return redirect()->to(site_url('profile'))->with('success', $changingPassword ? 'Profile and password updated.' : 'Profile updated.');
    }

    private function current(): ?array
    {
        return (new UserModel())->where('is_active', 1)->find((int) session('user_id'));
    }

    private function signedOut()
    {
        session()->remove(['user_id', 'user', 'sale_keys', 'checkout_keys']);
        return redirect()->to(site_url('login'))->with('error', 'Please sign in again to update your profile.');
    }

    /** Passwords, account IDs and role fields are never redisplayed from old input. */
    private function failure(array $data, array $errors, ?string $message = null)
    {
        $safe = ['full_name' => is_string($data['full_name'] ?? null) ? $data['full_name'] : ''];
        $response = redirect()->to(site_url('profile'))->with('_ci_old_input', ['post' => $safe, 'get' => []])->with('errors', $errors);
        return $message ? $response->with('error', $message) : $response;
    }
}
