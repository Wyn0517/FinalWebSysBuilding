<?php

namespace App\Controllers;

use CodeIgniter\Exceptions\PageNotFoundException;

class Media extends BaseController
{
    public function show(string $filename)
    {
        if (!preg_match('/\A[a-f0-9]{32}\.(?:png|jpg)\z/', $filename)) {
            throw PageNotFoundException::forPageNotFound();
        }
        $path = WRITEPATH . 'uploads/' . $filename;
        if (!is_file($path)) {
            throw PageNotFoundException::forPageNotFound();
        }
        return $this->response->setContentType(str_ends_with($filename, '.png') ? 'image/png' : 'image/jpeg')
            ->setHeader('X-Content-Type-Options', 'nosniff')
            ->setHeader('Cache-Control', 'private, no-store')
            ->setBody(file_get_contents($path));
    }
}
