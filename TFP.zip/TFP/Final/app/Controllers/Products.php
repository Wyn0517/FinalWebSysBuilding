<?php

namespace App\Controllers;

use App\Libraries\ImageUpload;
use App\Models\ProductModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use InvalidArgumentException;
use Throwable;

class Products extends BaseController
{
    public function index()
    {
        $q = $this->request->getGet('q');
        $q = is_string($q) ? mb_substr(trim($q), 0, 100) : '';
        $filter = $this->request->getGet('stock');
        $stockFilter = is_string($filter) && in_array($filter, ['all', 'available', 'low', 'out'], true) ? $filter : 'all';
        $model = new ProductModel();
        if ($stockFilter === 'available') {
            $model->where('stock_quantity >', 0);
        } elseif ($stockFilter === 'low') {
            $model->where('stock_quantity <=', 5);
        } elseif ($stockFilter === 'out') {
            $model->where('stock_quantity', 0);
        }
        if ($q !== '') {
            $model->like('name', $q);
        }
        return view('products/index', ['title' => 'Products', 'items' => $model->orderBy('name')->paginate(15), 'pager' => $model->pager, 'q' => $q, 'stockFilter' => $stockFilter]);
    }

    public function create()
    {
        return view('products/form', ['title' => 'Add product', 'item' => null]);
    }

    public function edit(int $id)
    {
        return view('products/form', ['title' => 'Edit product', 'item' => $this->find($id)]);
    }

    public function store()
    {
        return $this->persist();
    }

    public function update(int $id)
    {
        return $this->persist($this->find($id));
    }

    public function delete(int $id)
    {
        $item = $this->find($id);
        try {
            if (!(new ProductModel())->delete($item['id'])) {
                throw new \RuntimeException('Archive failed');
            }
        } catch (Throwable $e) {
            log_message('error', 'Product archive failed: {type}', ['type' => get_class($e)]);
            return redirect()->to(site_url('products'))->with('error', 'The product could not be archived. Please try again.');
        }
        return redirect()->to(site_url('products'))->with('success', 'Product archived. Existing sales remain available.');
    }

    private function find(int $id): array
    {
        $item = (new ProductModel())->find($id);
        if (!$item) {
            throw PageNotFoundException::forPageNotFound('Product not found.');
        }
        return $item;
    }

    private function persist(?array $item = null)
    {
        $data = $this->request->getPost(['name', 'price', 'stock_quantity', 'stock_original']);
        if (is_string($data['name'])) {
            $data['name'] = trim($data['name']);
        }
        $rules = [
            'name' => 'required|max_length[100]',
            'price' => ['label' => 'Price', 'rules' => ['required', 'regex_match[/\A(?:0|[1-9][0-9]{0,7})(?:\.[0-9]{1,2})?\z/]'], 'errors' => ['regex_match' => 'Use a nonnegative amount up to 99,999,999.99 with at most two decimal places.']],
            'stock_quantity' => 'required|is_natural|less_than_equal_to[2147483647]',
        ];
        $file = $this->request->getFile('image');
        if ($file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE) {
            $rules['image'] = 'uploaded[image]|is_image[image]|mime_in[image,image/jpeg,image/png,image/webp]|ext_in[image,jpg,jpeg,png,webp]|max_size[image,2048]|max_dims[image,6000,6000]';
        }
        if ($item !== null) {
            $rules['stock_original'] = 'required|is_natural|less_than_equal_to[2147483647]';
        }
        $target = $item ? 'products/' . $item['id'] . '/edit' : 'products/new';
        if (!$this->validateData($data, $rules)) {
            return redirect()->to(site_url($target))->withInput()->with('errors', $this->validator->getErrors());
        }
        $images = new ImageUpload();
        $newImage = null;
        try {
            $newImage = $images->store($this->request->getFile('image'));
            $record = ['name' => $data['name'], 'price' => $data['price']];
            if ($newImage !== null) {
                $record['image'] = $newImage;
            }
            $model = new ProductModel();
            if ($item === null) {
                $record['stock_quantity'] = (int) $data['stock_quantity'];
                $ok = $model->insert($record) !== false;
            } elseif ((int) $data['stock_quantity'] !== (int) $data['stock_original']) {
                // A concurrent sale must not be overwritten by a stale stock edit.
                $record['stock_quantity'] = (int) $data['stock_quantity'];
                $record['updated_at'] = date('Y-m-d H:i:s');
                $db = db_connect();
                $ok = $db->table('products')->where('id', $item['id'])->where('deleted_at', null)
                    ->where('stock_quantity', (int) $data['stock_original'])->update($record);
                if (!$ok || $db->affectedRows() !== 1) {
                    $images->remove($newImage);
                    return redirect()->to(site_url($target))->with('error', 'Stock changed while you were editing. Review the current stock and try again.');
                }
            } else {
                // Leaving the stock field alone preserves stock changes made by sales.
                $ok = $model->update($item['id'], $record);
            }
            if (!$ok) {
                throw new \RuntimeException('Product save failed');
            }
            if ($item && $newImage !== null) {
                $images->remove($item['image']);
            }
        } catch (InvalidArgumentException $e) {
            $images->remove($newImage);
            return redirect()->to(site_url($target))->withInput()->with('errors', ['image' => $e->getMessage()]);
        } catch (Throwable $e) {
            $images->remove($newImage);
            log_message('error', 'Product save failed: {type}', ['type' => get_class($e)]);
            return redirect()->to(site_url($target))->withInput()->with('error', 'The product could not be saved. Please check the image and try again.');
        }
        return redirect()->to(site_url('products'))->with('success', $item ? 'Product updated.' : 'Product added.');
    }
}
