<?php

namespace App\Controllers;

use App\Libraries\ImageUpload;
use App\Models\UserModel;
use CodeIgniter\Database\BaseConnection;
use CodeIgniter\Exceptions\PageNotFoundException;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

class Staff extends BaseController
{
    public function index()
    {
        $q = $this->request->getGet('q');
        $q = is_string($q) ? mb_substr(trim($q), 0, 100) : '';
        $model = new UserModel();
        $model->select('id, username, full_name, avatar, role, is_active, created_at');
        if ($q !== '') {
            $model->groupStart()->like('full_name', $q)->orLike('username', $q)->groupEnd();
        }
        return view('staff/index', ['title' => 'Staff', 'items' => $model->orderBy('full_name')->paginate(15), 'pager' => $model->pager, 'q' => $q]);
    }

    public function create()
    {
        return view('staff/form', ['title' => 'Add staff', 'item' => null]);
    }

    public function edit(int $id)
    {
        $item = $this->find($id);
        unset($item['password']);
        return view('staff/form', ['title' => 'Edit staff', 'item' => $item]);
    }

    public function store()
    {
        return $this->persist();
    }

    public function update(int $id)
    {
        return $this->persist($this->find($id));
    }

    public function delete(int $id)
    {
        $this->find($id);
        if ($id === (int) session()->get('user_id')) {
            return redirect()->to(site_url('staff'))->with('error', 'You cannot archive your own account.');
        }
        $db = db_connect();
        try {
            if (!$db->transBegin()) {
                throw new RuntimeException('Could not start account transaction');
            }
            $this->lockUsers($db);
            $this->assertAdministrator();
            $item = $this->find($id);
            $this->assertAdminRemains($item, 'cashier', false);
            if (!(new UserModel())->delete($id) || !$db->transStatus() || !$db->transCommit()) {
                throw new RuntimeException('Account archival failed');
            }
        } catch (InvalidArgumentException $e) {
            $db->transRollback();
            return redirect()->to(site_url('staff'))->with('error', $e->getMessage());
        } catch (Throwable $e) {
            $db->transRollback();
            log_message('error', 'Staff archive failed: {type}', ['type' => get_class($e)]);
            return redirect()->to(site_url('staff'))->with('error', 'The account could not be archived. Please try again.');
        }
        return redirect()->to(site_url('staff'))->with('success', 'Staff account archived. Its previous sales remain available.');
    }

    private function find(int $id): array
    {
        $item = (new UserModel())->find($id);
        if (!$item) {
            throw PageNotFoundException::forPageNotFound('Staff member not found.');
        }
        return $item;
    }

    private function persist(?array $item = null)
    {
        $data = $this->request->getPost(['username', 'full_name', 'password', 'password_confirm', 'role', 'is_active']);
        foreach (['username', 'full_name'] as $field) {
            if (is_string($data[$field])) {
                $data[$field] = trim($data[$field]);
            }
        }
        if (is_string($data['username'])) {
            $data['username'] = strtolower($data['username']);
        }
        $target = $item ? 'staff/' . $item['id'] . '/edit' : 'staff/new';
        $passwordRules = $item && ($data['password'] ?? '') === '' ? 'permit_empty' : 'required|min_length[12]|max_length[72]';
        $rules = [
            'username' => ['rules' => ['required', 'min_length[3]', 'max_length[50]', 'regex_match[/\A[a-z0-9_.-]+\z/]']],
            'full_name' => 'required|max_length[100]',
            'password' => $passwordRules,
            'password_confirm' => $item && ($data['password'] ?? '') === '' ? 'permit_empty' : 'required|matches[password]',
            'role' => 'required|in_list[admin,cashier]',
            'is_active' => 'required|in_list[0,1]',
        ];
        $file = $this->request->getFile('avatar');
        if ($file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE) {
            $rules['avatar'] = 'uploaded[avatar]|is_image[avatar]|mime_in[avatar,image/jpeg,image/png,image/webp]|ext_in[avatar,jpg,jpeg,png,webp]|max_size[avatar,2048]|max_dims[avatar,6000,6000]';
        }
        if (!$this->validateData($data, $rules)) {
            return $this->failure($target, $data, $this->validator->getErrors());
        }
        if (is_string($data['password']) && strlen($data['password']) > 72) {
            return $this->failure($target, $data, ['password' => 'Use a password no longer than 72 bytes.']);
        }
        $existing = (new UserModel())->withDeleted()->where('username', $data['username']);
        if ($item) {
            $existing->where('id !=', $item['id']);
        }
        if ($existing->first()) {
            return $this->failure($target, $data, ['username' => 'That username is already in use.']);
        }
        if ($item && (int) $item['id'] === (int) session()->get('user_id') && ($data['role'] !== 'admin' || $data['is_active'] !== '1')) {
            return $this->failure($target, $data, ['role' => 'Keep your own administrator account active. Ask another administrator to change its access.']);
        }
        $images = new ImageUpload();
        $image = null;
        $db = db_connect();
        $started = false;
        try {
            $image = $images->store($this->request->getFile('avatar'));
            $record = ['username' => $data['username'], 'full_name' => $data['full_name'], 'role' => $data['role'], 'is_active' => (int) $data['is_active']];
            if (($data['password'] ?? '') !== '') {
                $record['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            if ($image !== null) {
                $record['avatar'] = $image;
            }
            if (!$db->transBegin()) {
                throw new RuntimeException('Could not start account transaction');
            }
            $started = true;
            $this->lockUsers($db);
            $this->assertAdministrator();
            if ($item) {
                $current = $this->find($item['id']);
                $this->assertAdminRemains($current, $data['role'], (bool) $data['is_active']);
            }
            $model = new UserModel();
            $ok = $item ? $model->update($item['id'], $record) : $model->insert($record) !== false;
            if (!$ok || !$db->transStatus() || !$db->transCommit()) {
                throw new RuntimeException('Account save failed');
            }
            $started = false;
            if ($item && $image !== null) {
                $images->remove($item['avatar']);
            }
        } catch (InvalidArgumentException $e) {
            if ($started) {
                $db->transRollback();
            }
            $images->remove($image);
            return $this->failure($target, $data, [($started ? 'role' : 'avatar') => $e->getMessage()]);
        } catch (Throwable $e) {
            if ($started) {
                $db->transRollback();
            }
            $images->remove($image);
            log_message('error', 'Staff save failed: {type}', ['type' => get_class($e)]);
            return $this->failure($target, $data, [], 'The account could not be saved. Check that the username is unique and try again.');
        }
        return redirect()->to(site_url('staff'))->with('success', $item ? 'Staff account updated.' : 'Staff account added.');
    }

    /** Never place plaintext passwords in flash data or logs. */
    private function failure(string $target, array $data, array $errors, ?string $message = null)
    {
        $safe = array_intersect_key($data, array_flip(['username', 'full_name', 'role', 'is_active']));
        $safe = array_filter($safe, static fn($value) => is_scalar($value) || $value === null);
        $response = redirect()->to(site_url($target))->with('_ci_old_input', ['post' => $safe, 'get' => []])->with('errors', $errors);
        return $message ? $response->with('error', $message) : $response;
    }

    /** Serialize privilege changes, including two admins trying to remove each other. */
    private function lockUsers(BaseConnection $db): void
    {
        $table = $db->protectIdentifiers($db->prefixTable('users'));
        if ($db->DBDriver === 'MySQLi') {
            $db->query('SELECT id FROM ' . $table . ' ORDER BY id FOR UPDATE');
        } else {
            $db->query('UPDATE ' . $table . ' SET is_active = is_active WHERE id > 0');
        }
    }

    private function assertAdministrator(): void
    {
        $actor = (new UserModel())->find((int) session()->get('user_id'));
        if (!$actor || !$actor['is_active'] || $actor['role'] !== 'admin') {
            throw new InvalidArgumentException('Your account no longer has permission to manage staff.');
        }
    }

    private function assertAdminRemains(array $item, string $newRole, bool $active): void
    {
        if ($item['role'] === 'admin' && (bool) $item['is_active'] && ($newRole !== 'admin' || !$active)) {
            $count = (new UserModel())->where('role', 'admin')->where('is_active', 1)->countAllResults();
            if ($count <= 1) {
                throw new InvalidArgumentException('Keep at least one active administrator account.');
            }
        }
    }
}
