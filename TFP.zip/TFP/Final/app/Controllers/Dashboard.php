<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Models\ProductModel;
use App\Models\SalesModel;
use CodeIgniter\Database\BaseBuilder;
use DateTimeImmutable;

class Dashboard extends BaseController
{
    public function index()
    {
        $now = new DateTimeImmutable();
        $today = $now->setTime(0, 0);
        $tomorrow = $today->modify('+1 day');
        $requestedRange = $this->request->getGet('days');
        $rangeDays = is_scalar($requestedRange) && in_array((string) $requestedRange, ['7', '14', '30'], true)
            ? (int) $requestedRange : 7;
        $start = $today->modify('-' . ($rangeDays - 1) . ' days');
        $days = [];
        for ($day = $start; $day <= $today; $day = $day->modify('+1 day')) {
            $days[$day->format('Y-m-d')] = [
                'date' => $day->format('Y-m-d'),
                'label' => $day->format('D'),
                'fullDate' => $day->format('l, F j, Y'),
                'shortDate' => $day->format('M j'),
                'isToday' => $day == $today,
                'cents' => 0,
                'lineCount' => 0,
                'unitCount' => 0,
            ];
        }

        // Bucket stored sale lines in PHP so date grouping works identically on
        // SQLite and MySQL. Sum each stored decimal as cents, without float math.
        $db = db_connect();
        $result = $db->table('sales')->select('created_at, total_price, quantity')
            ->where('created_at >=', $start->format('Y-m-d H:i:s'))
            ->where('created_at <', $tomorrow->format('Y-m-d H:i:s'))->get();
        while ($sale = $result->getUnbufferedRow('array')) {
            $date = substr($sale['created_at'], 0, 10);
            if (!isset($days[$date])) {
                continue;
            }
            $days[$date]['cents'] += $this->toCents((string) $sale['total_price']);
            $days[$date]['lineCount']++;
            $days[$date]['unitCount'] += (int) $sale['quantity'];
        }
        $result->freeResult();
        $todayMetrics = $days[$today->format('Y-m-d')];

        // Old single-product sales are still individual transactions. New cart
        // transactions have one receipt and several linked sale lines; count
        // each receipt once, while retaining unlinked legacy sales in the total.
        $todayReceiptCount = $todayMetrics['lineCount'];
        $hasReceiptTables = $db->tableExists('receipts') && $db->tableExists('receipt_lines');
        if ($hasReceiptTables) {
            $receiptCount = $db->table('receipts')
                ->where('created_at >=', $today->format('Y-m-d H:i:s'))
                ->where('created_at <', $tomorrow->format('Y-m-d H:i:s'))->countAllResults();
            $legacyCount = $db->table('sales')
                ->where('created_at >=', $today->format('Y-m-d H:i:s'))
                ->where('created_at <', $tomorrow->format('Y-m-d H:i:s'))
                ->whereNotIn('id', static fn (BaseBuilder $builder) => $builder->select('sale_id')->from('receipt_lines'))
                ->countAllResults();
            $todayReceiptCount = $receiptCount + $legacyCount;
        }

        $periodCents = array_sum(array_column($days, 'cents'));
        $maxCents = max(array_column($days, 'cents'));
        $trend = [];
        foreach ($days as $day) {
            $day['total'] = $this->decimal($day['cents']);
            $day['height'] = $maxCents > 0 ? number_format($day['cents'] / $maxCents * 100, 3, '.', '') : '0';
            $trend[] = $day;
        }

        // A sale line links to one real receipt at most. Legacy single-product
        // sales remain readable without manufacturing a receipt identifier.
        $recentQuery = (new SalesModel())->select('sales.*');
        if ($hasReceiptTables) {
            $recentQuery->select('receipt_lines.receipt_id')
                ->join('receipt_lines', 'receipt_lines.sale_id = sales.id', 'left');
        } else {
            $recentQuery->select('NULL AS receipt_id', false);
        }
        $recentSales = $recentQuery->orderBy('sales.created_at', 'DESC')->orderBy('sales.id', 'DESC')->findAll(6);

        return view('dashboard', [
            'title' => 'Business overview',
            'greeting' => (int) $now->format('G') < 12 ? 'Good morning' : ((int) $now->format('G') < 18 ? 'Good afternoon' : 'Good evening'),
            'reportDate' => $today->format('l, F j, Y'),
            'reportTimezone' => $now->getTimezone()->getName(),
            'rangeDays' => $rangeDays,
            'todayDate' => $today->format('Y-m-d'),
            'periodStart' => $start->format('M j'),
            'periodEnd' => $today->format('M j, Y'),
            'trend' => $trend,
            'periodTotal' => $this->decimal($periodCents),
            'hasPeriodSales' => array_sum(array_column($days, 'lineCount')) > 0,
            'productCount' => (new ProductModel())->countAllResults(),
            'customerCount' => (new CustomerModel())->countAllResults(),
            'lowStockCount' => (new ProductModel())->where('stock_quantity <=', 5)->countAllResults(),
            'todayTotal' => $this->decimal($todayMetrics['cents']),
            'todaySaleCount' => $todayMetrics['lineCount'],
            'todayReceiptCount' => $todayReceiptCount,
            'todayUnitCount' => $todayMetrics['unitCount'],
            'recentSales' => $recentSales,
            'lowStockProducts' => (new ProductModel())->where('stock_quantity <=', 5)
                ->orderBy('stock_quantity')->orderBy('name')->findAll(6),
        ]);
    }

    private function toCents(string $amount): int
    {
        $parts = explode('.', $amount, 2);
        return (int) $parts[0] * 100 + (int) str_pad($parts[1] ?? '', 2, '0');
    }

    private function decimal(int $cents): string
    {
        return intdiv($cents, 100) . '.' . str_pad((string) ($cents % 100), 2, '0', STR_PAD_LEFT);
    }
}
