<?php

namespace App\Controllers;

use App\Libraries\CheckoutService;
use App\Models\CustomerModel;
use App\Models\ProductModel;
use App\Models\ReceiptModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use DomainException;
use JsonException;
use RuntimeException;

class Checkout extends BaseController
{
    public function index()
    {
        $keys = session('checkout_keys') ?? [];
        $keys = is_array($keys) ? array_filter($keys, static fn($issued) => is_int($issued) && $issued > time() - 7200) : [];
        $key = bin2hex(random_bytes(32));
        $keys[$key] = time();
        session()->set('checkout_keys', array_slice($keys, -20, null, true));
        $products = (new ProductModel())->select('id, name, price, stock_quantity, image')->orderBy('name')->findAll();
        $customers = (new CustomerModel())->select('id, full_name')->orderBy('full_name')->findAll();
        $available = array_fill_keys(array_map(static fn($product) => (int) $product['id'], $products), true);
        $initialCart = [];
        $draft = session()->getFlashdata('checkout_cart');
        if (is_array($draft)) {
            // Drafts contain IDs and quantities only. Reload names, prices, and stock from the DB.
            foreach ($draft as $item) {
                if (is_array($item) && is_int($item['product_id'] ?? null) && is_int($item['quantity'] ?? null)
                    && $item['quantity'] > 0 && isset($available[$item['product_id']])) {
                    $initialCart[] = ['product_id' => $item['product_id'], 'quantity' => $item['quantity']];
                }
            }
        }
        $customerId = session()->getFlashdata('checkout_customer_id');
        $customerIds = array_column($customers, 'id');
        $selectedCustomer = $customerId !== null && in_array((string) $customerId, array_map('strval', $customerIds), true) ? (string) $customerId : '';
        return view('pos/index', [
            'title' => 'Point of sale', 'products' => $products, 'customers' => $customers,
            'requestKey' => $key, 'initialCart' => $initialCart, 'selectedCustomer' => $selectedCustomer,
        ]);
    }

    public function store()
    {
        $data = $this->request->getPost(['cart', 'customer_id', 'request_key']);
        $valid = $this->validateData($data, [
            'cart' => 'required|max_length[32768]',
            'customer_id' => 'permit_empty|is_natural_no_zero|less_than_equal_to[2147483647]',
            'request_key' => 'required|regex_match[/\A[a-f0-9]{64}\z/]',
        ]);
        $items = [];
        try {
            if (!is_string($data['cart']) || strlen($data['cart']) > 32768) {
                throw new DomainException('The cart is invalid. Add your products again.');
            }
            $decoded = json_decode($data['cart'], true, 32, JSON_THROW_ON_ERROR);
            if (!is_array($decoded)) {
                throw new DomainException('The cart is invalid. Add your products again.');
            }
            $items = CheckoutService::normalizeItems($decoded);
        } catch (JsonException | DomainException $e) {
            return $this->failure([], null, 'The cart is invalid. Add products with valid whole-number quantities and try again.');
        }
        $customerId = is_scalar($data['customer_id']) && ctype_digit((string) $data['customer_id']) ? (int) $data['customer_id'] : null;
        if (!$valid) {
            return $this->failure($items, $customerId, 'Please review the checkout details.', $this->validator->getErrors());
        }
        $keys = session('checkout_keys') ?? [];
        $issued = is_array($keys) ? ($keys[$data['request_key']] ?? 0) : 0;
        if (!is_int($issued) || $issued < time() - 7200) {
            return $this->failure($items, $customerId, 'This checkout form has expired. Review your cart and submit again.');
        }
        try {
            $receipt = (new CheckoutService())->record($items, $customerId, (int) session('user_id'), $data['request_key']);
            return redirect()->to(site_url('pos/receipts/' . $receipt['id']))
                ->with('success', 'Sale completed. Inventory is up to date.');
        } catch (DomainException | RuntimeException $e) {
            return $this->failure($items, $customerId, $e->getMessage());
        }
    }

    public function receipt(int $id)
    {
        $receipt = (new ReceiptModel())->find($id);
        $user = session('user');
        if (!$receipt || (($user['role'] ?? '') !== 'admin' && (int) $receipt['sold_by'] !== (int) session('user_id'))) {
            throw PageNotFoundException::forPageNotFound('Receipt not found.');
        }
        $lines = db_connect()->table('receipt_lines rl')->select('s.*')
            ->join('sales s', 's.id = rl.sale_id')->where('rl.receipt_id', $id)->orderBy('s.id')->get()->getResultArray();
        return view('sales/receipt', ['title' => 'Receipt #' . $id, 'receipt' => $receipt, 'lines' => $lines]);
    }

    private function failure(array $items, ?int $customerId, string $message, array $errors = [])
    {
        return redirect()->to(site_url('pos'))->with('checkout_cart', $items)
            ->with('checkout_customer_id', $customerId)->with('error', $message)->with('errors', $errors);
    }
}
