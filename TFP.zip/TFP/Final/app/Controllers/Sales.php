<?php

namespace App\Controllers;

use App\Libraries\SaleService;
use App\Models\CustomerModel;
use App\Models\ProductModel;
use App\Models\SalesModel;
use DomainException;
use RuntimeException;

class Sales extends BaseController
{
    public function index()
    {
        $read = function (string $name, int $limit = 100): string {
            $value = $this->request->getGet($name);
            return is_string($value) ? mb_substr(trim($value), 0, $limit) : '';
        };
        $q = $read('q');
        $from = $read('from', 10);
        $to = $read('to', 10);
        $sort = $read('sort') === 'oldest' ? 'oldest' : 'newest';
        $filterError = null;
        foreach ([$from, $to] as $date) {
            if ($date !== '') {
                $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date);
                if (!$parsed || $parsed->format('Y-m-d') !== $date) {
                    $filterError = 'Choose valid dates using the date fields.';
                }
            }
        }
        if ($from !== '' && $to !== '' && $from > $to) {
            $filterError = 'The start date must be on or before the end date.';
        }
        $model = new SalesModel();
        $model->select('sales.*, receipt_lines.receipt_id')->join('receipt_lines', 'receipt_lines.sale_id = sales.id', 'left');
        if ((session('user')['role'] ?? '') !== 'admin') {
            $model->where('sales.sold_by', (int) session('user_id'));
        }
        if ($q !== '') {
            $model->groupStart()->like('sales.product_name', $q)->orLike('sales.customer_name', $q)
                ->orLike('sales.staff_name', $q)->groupEnd();
        }
        if ($filterError !== null) {
            $model->where('sales.id', 0);
        } else {
            if ($from !== '') {
                $model->where('sales.created_at >=', $from . ' 00:00:00');
            }
            if ($to !== '') {
                $end = (new \DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d');
                $model->where('sales.created_at <', $end . ' 00:00:00');
            }
        }
        return view('sales/index', [
            'items' => $model->orderBy('sales.created_at', $sort === 'oldest' ? 'ASC' : 'DESC')
                ->orderBy('sales.id', $sort === 'oldest' ? 'ASC' : 'DESC')->paginate(20),
            'pager' => $model->pager, 'q' => $q, 'from' => $from, 'to' => $to,
            'sort' => $sort, 'filterError' => $filterError,
            'title' => (session('user')['role'] ?? '') === 'admin' ? 'Sales history' : 'My sales',
        ]);
    }

    public function create()
    {
        $keys = session('sale_keys') ?? [];
        $keys = array_filter($keys, static fn ($issued) => $issued > time() - 7200);
        $key = bin2hex(random_bytes(32));
        $keys[$key] = time();
        session()->set('sale_keys', array_slice($keys, -20, null, true));
        return view('sales/create', [
            'products' => (new ProductModel())->orderBy('name')->findAll(),
            'customers' => (new CustomerModel())->orderBy('full_name')->findAll(),
            'requestKey' => $key, 'title' => 'Record a sale',
        ]);
    }

    public function store()
    {
        $data = $this->request->getPost(['product_id', 'customer_id', 'quantity', 'request_key']);
        if (!$this->validateData($data, [
            'product_id' => 'required|is_natural_no_zero|max_length[10]',
            'customer_id' => 'permit_empty|is_natural_no_zero|max_length[10]',
            'quantity' => 'required|is_natural_no_zero|less_than_equal_to[2147483647]',
            'request_key' => 'required|regex_match[/^[a-f0-9]{64}$/D]',
        ])) {
            return redirect()->to(site_url('sales/new'))->withInput()->with('errors', $this->validator->getErrors());
        }
        $issued = (session('sale_keys') ?? [])[$data['request_key']] ?? 0;
        if ($issued < time() - 7200) {
            return redirect()->to(site_url('sales/new'))->with('error', 'This sale form has expired. Review and submit a new sale.');
        }
        try {
            $sale = (new SaleService())->record((int) $data['product_id'],
                $data['customer_id'] === '' || $data['customer_id'] === null ? null : (int) $data['customer_id'],
                (int) session('user_id'), (int) $data['quantity'], $data['request_key']);
            return redirect()->to(site_url('sales'))->with('success', 'Sale #' . $sale['id'] . ' recorded for ' . money($sale['total_price']) . '. Inventory is up to date.');
        } catch (DomainException | RuntimeException $e) {
            return redirect()->to(site_url('sales/new'))->withInput()->with('error', $e->getMessage());
        }
    }
}
