<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use Throwable;

class Customers extends BaseController
{
    public function index()
    {
        $q = $this->request->getGet('q');
        $q = is_string($q) ? mb_substr(trim($q), 0, 100) : '';
        $model = new CustomerModel();
        if ($q !== '') {
            $model->groupStart()->like('full_name', $q)->orLike('email', $q)->orLike('phone', $q)->groupEnd();
        }
        return view('customers/index', ['title' => 'Customers', 'items' => $model->orderBy('full_name')->paginate(15), 'pager' => $model->pager, 'q' => $q]);
    }

    public function create()
    {
        return view('customers/form', ['title' => 'Add customer', 'item' => null]);
    }

    public function edit(int $id)
    {
        return view('customers/form', ['title' => 'Edit customer', 'item' => $this->find($id)]);
    }

    public function store()
    {
        return $this->persist();
    }

    public function update(int $id)
    {
        return $this->persist($this->find($id));
    }

    public function delete(int $id)
    {
        $item = $this->find($id);
        try {
            if (!(new CustomerModel())->delete($item['id'])) {
                throw new \RuntimeException('Archive failed');
            }
        } catch (Throwable $e) {
            log_message('error', 'Customer archive failed: {type}', ['type' => get_class($e)]);
            return redirect()->to(site_url('customers'))->with('error', 'The customer could not be archived. Please try again.');
        }
        return redirect()->to(site_url('customers'))->with('success', 'Customer archived. Existing sales retain their original details.');
    }

    private function find(int $id): array
    {
        $item = (new CustomerModel())->find($id);
        if (!$item) {
            throw PageNotFoundException::forPageNotFound('Customer not found.');
        }
        return $item;
    }

    private function persist(?array $item = null)
    {
        $data = $this->request->getPost(['full_name', 'email', 'phone']);
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $data[$key] = trim($value);
            }
        }
        $target = $item ? 'customers/' . $item['id'] . '/edit' : 'customers/new';
        if (!$this->validateData($data, [
            'full_name' => 'required|max_length[100]',
            'email' => 'required|valid_email|max_length[100]',
            'phone' => ['label' => 'Phone', 'rules' => ['permit_empty', 'max_length[20]', 'regex_match[/\A(?=.*[0-9])[+0-9().\s-]{5,20}\z/]']],
        ])) {
            return redirect()->to(site_url($target))->withInput()->with('errors', $this->validator->getErrors());
        }
        try {
            $model = new CustomerModel();
            $ok = $item ? $model->update($item['id'], $data) : $model->insert($data) !== false;
            if (!$ok) {
                throw new \RuntimeException('Customer save failed');
            }
        } catch (Throwable $e) {
            log_message('error', 'Customer save failed: {type}', ['type' => get_class($e)]);
            return redirect()->to(site_url($target))->withInput()->with('error', 'The customer could not be saved. Please try again.');
        }
        return redirect()->to(site_url('customers'))->with('success', $item ? 'Customer updated.' : 'Customer added.');
    }
}
