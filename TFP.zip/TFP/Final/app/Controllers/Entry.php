<?php

namespace App\Controllers;

/** One application, with an entry point suited to the signed-in staff role. */
class Entry extends BaseController
{
    public function index()
    {
        return redirect()->to(site_url((session('user')['role'] ?? '') === 'admin' ? 'admin/dashboard' : 'pos'));
    }
}
