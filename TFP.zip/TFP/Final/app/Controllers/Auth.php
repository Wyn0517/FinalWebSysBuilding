<?php

namespace App\Controllers;

use App\Models\UserModel;
use Throwable;

class Auth extends BaseController
{
    public function login()
    {
        if (session()->has('user_id')) {
            try {
                $user = (new UserModel())->find((int) session('user_id'));
                if ($user && (bool) $user['is_active']) {
                    return redirect()->to(site_url($user['role'] === 'admin' ? 'admin/dashboard' : 'pos'));
                }
            } catch (Throwable $e) {
                // A stale session must not trap a user in a login/entry redirect loop.
                log_message('error', 'The saved staff session could not be checked.');
            }
            session()->remove(['user_id', 'user', 'sale_keys', 'checkout_keys']);
        }
        return view('auth/login', ['title' => 'Sign in']);
    }

    public function authenticate()
    {
        $data = $this->request->getPost(['username', 'password']);
        if (is_string($data['username'])) {
            $data['username'] = strtolower(trim($data['username']));
        }
        if (!$this->validateData($data, [
            'username' => 'required|max_length[50]',
            'password' => 'required|max_length[72]',
        ])) {
            return redirect()->to(site_url('login'))->with('errors', $this->validator->getErrors())
                ->with('_ci_old_input', ['post' => ['username' => is_string($data['username']) ? $data['username'] : ''], 'get' => []]);
        }
        // Cache keys contain a digest, never passwords or raw account identifiers.
        $key = 'login_' . hash('sha256', $this->request->getIPAddress() . '|' . strtolower($data['username']));
        $cache = cache();
        $attempts = (int) ($cache->get($key) ?? 0);
        if ($attempts >= 5) {
            return redirect()->to(site_url('login'))->with('error', 'Too many sign-in attempts. Please try again in 15 minutes.');
        }
        try {
            $user = (new UserModel())->where('username', $data['username'])->first();
        } catch (Throwable $e) {
            log_message('error', 'The login database query could not be completed.');
            return redirect()->to(site_url('login'))->with('error', 'The workspace database is unavailable. Ask the administrator to check setup and migrations.');
        }
        // Verify a fixed valid dummy hash too, to reduce account-existence timing differences.
        $hash = $user['password'] ?? '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
        $valid = password_verify($data['password'], $hash);
        if (!$user || !$valid || !(bool) $user['is_active']) {
            $cache->save($key, $attempts + 1, 900);
            return redirect()->to(site_url('login'))->with('error', 'The username or password is incorrect.')
                ->with('_ci_old_input', ['post' => ['username' => $data['username']], 'get' => []]);
        }
        $cache->delete($key);
        session()->regenerate(true);
        session()->remove(['sale_keys', 'checkout_keys']);
        session()->set('user_id', $user['id']);
        session()->set('user', array_intersect_key($user, array_flip(['id', 'username', 'full_name', 'role', 'avatar'])));
        if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
            try {
                (new UserModel())->update($user['id'], ['password' => password_hash($data['password'], PASSWORD_DEFAULT)]);
            } catch (Throwable $e) {
                log_message('error', 'A verified staff password could not be upgraded to the current hash settings.');
            }
        }
        return redirect()->to(site_url($user['role'] === 'admin' ? 'admin/dashboard' : 'pos'))->with('success', 'You are signed in.');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(site_url('login'));
    }
}
