# Verification record

Updated 27 October 2026 for the reference-inspired Counterpoint interface. The PHP application has **not** been executed in the authoring workspace. The offline preview expands templates using sample fixtures; it is not PHP execution or a browser screenshot.

## Executed application checks

- `node --check public/assets/app.js` and `node --check public/assets/cart.js` passed.
- `node --test tests/frontend.test.cjs tests/cart.test.cjs` passed **33 tests**: 16 shared-controller checks and 17 cart/search/feedback checks.
- Shared tests cover synchronized sidebar buttons, usable compact desktop navigation, legacy preference mapping, storage failure, mobile focus trapping/dismissal/restoration, breakpoint changes, theme persistence, sale-preview totals/stock feedback and repeated-submit prevention. They use mocked DOM objects and do not verify rendered layout or actual assistive technology.
- Cart tests cover exact product ID/name search, F2 guards, merged items, stock bounds, malformed quantities, line/quantity/amount limits, integer-cent calculations, restricted submitted payloads and stale-order restoration. New feedback tests use a controlled clock to verify visible text and one persistent live-announcement channel, replacement/expiry, pending checkout persistence and reset.
- Both CSS files passed source checks for balanced delimiters, comments and strings. All 71 referenced CSS variables resolve. This is not a CSS layout engine.
- The 73 non-view PHP application files match the pre-refinement source byte for byte. Controllers, models, services, filters, commands, configuration, authentication, routes and migrations are unchanged.

## Preview checks

`UI-PREVIEW.html` embeds the current application views, app.css, studio.css, app.js, cart.js and SVG placeholders, using static sample fixtures. A manifest records hashes of those sources. It contains dashboard ranges for 7/14/30 days, checkout and sign-in.

Generated HTML/JSON and embedded JavaScript are parsed and syntax-checked. IDs and aria-controls references are checked within each page. The preview's route, chart-range, theme and submission guards pass their Node VM check. Content security policy blocks connections and form actions; captured submissions and native checkout submission are replaced with sample notices. No sale, stock deduction or sign-in can be committed through the preview.

The preview is an implementation review surface, not proof of PHP or browser behavior. System fonts serve as the offline fallback. The bundled preview contains no real accounts, credentials or customer data.

## Interface source review

The dashboard uses one grid for today's revenue, revenue chart, store summary, recent sale items and stock attention. Every displayed metric and destination retains the existing POS data/route meaning. Finance-specific labels and invented wallet/credit data from the inspiration are not introduced. Empty catalog, period, sales and stock states expand successfully in the fixture renderer. The date range remains limited by the existing controller to 7, 14 or 30 days.

Desktop navigation uses expanded/compact states. Compact links remain usable and retain accessible labels; hover and keyboard labels are styled beside the rail. The before-paint bootstrap maps old hidden/visible choices to compact/expanded. At 980px and below, mobile open/closed state is separate: a closed drawer is hidden and inert, an open drawer is modal, its background frame is inert, Tab wraps inside, and Escape/close/backdrop restore header focus. Navigation scrolls in a min-height:0 middle row between separate header/footer rows, keeping Checkout and account controls inside the sidebar at limited heights. The compact rail has sufficient inner width for its 44px controls. Tooltip labels render in a fixed portal outside the scroll region, remain viewport-bounded, preserve existing aria-describedby values and dismiss on scroll/resize/Escape/state changes. Three new mocked-DOM tests cover those tooltip contracts.

Cart outcomes use one visible message plus one persistent sr-only live region. The visible copy is hidden from assistive technology to prevent duplicate announcements; text changes do not rely on announcing a newly revealed live region. Errors clear stale success feedback, pending checkout remains visible until navigation/reset, and restored pages reset button labels and busy state. Financial calculations and serialized fields are preserved.

Glass blur is limited to major surfaces. Solid fallbacks, reduced transparency/motion handling, print behavior, focus indicators and opaque inputs/menus remain. Source review fixed inherited summary-column wrapping, duplicate busy spinners, fixed mobile-cart width and the mobile drawer close control. Real visual alignment, clipping, contrast over composited surfaces, pointer behavior and assistive-technology output remain pending browser checks.

## Earlier transaction-strategy experiment

The preceding cart release passed the separate SQLite experiment below through Python SQL. The UI revision does not change those write paths, and this experiment was not rerun for this interface-only change.

| SQL experiment | Observed result |
| --- | --- |
| 32 buyers compete for 10 units | 10 receipts; stock 0 |
| 32 two-product carts compete for stocks 10 and 6 | 6 receipts; 12 sale lines; stocks 4 and 0 |
| 8 attempts share one request key | 1 receipt; 2 lines; stocks 9 and 5 |
| Later product lacks stock | Earlier deduction rolled back; no receipt/sale persisted |
| Later sale/link insertion fails | All deductions, receipt, sales and links rolled back |

This supports the SQL strategy, not the PHP implementation or MySQL behavior.

## Runtime checks still pending

PHP, Composer, MySQL and usable browser executables are unavailable in this workspace. Playwright modules alone do not provide a browser. PHP lint, all PHPUnit tests, actual HTTP flows, GD image processing, application-level concurrency, MySQL, rendered desktop/mobile layouts and real keyboard/screen-reader behavior remain unverified. No hosted deployment or remote CI execution is claimed.

The supplied 42 POS-focused PHPUnit methods remain pending: 14 PosFlowTest, 15 CheckoutFlowTest and 13 AccessControlTest methods. They target the isolated test database. `tests/http_smoke.py` exercises a disposable running installation including role access, CRUD, image validation, cart receipts, server price validation, duplicate keys, stock rollback, CSRF, history, profile changes and logout. Never run the HTTP writer against real store data.

The retained CI workflow installs PHP/extensions, lints PHP, runs PHPUnit and the Node tests, creates a disposable SQLite installation and runs HTTP/SQL checks. To finish verification on a PHP-enabled test host, run these checks and inspect dashboard, sign-in, checkout, CRUD, profile, history and receipts at desktop/tablet/mobile sizes in both themes, with expanded/compact/drawer navigation, loading/errors and long data. Preserve `.env` and `writable`; this update requires no new migration if the cart/receipts release is already installed.

Final packaging checks: all six generated HTML documents parsed, their IDs were unique and aria-controls targets resolved; JSON fixtures parsed and 17 embedded scripts passed syntax checks. ZIP integrity and byte comparisons against the final views, styles, scripts, guides and bundled preview passed.

## Sidebar containment correction

The user screenshot showed Checkout extending outside the rounded sidebar. The previous fixed-height flex layout allowed its total content to overflow. The sidebar now uses grid rows `auto minmax(0,1fr) auto`; its middle `.sidebar-scroll` owns vertical scrolling, and the surrounding panel clips its content. Footer actions use a compact uniform stack. Compact and mobile styles retain the same row structure. Tests cover tooltip behavior alongside the existing navigation persistence, focus and dismissal checks.

The source review also added wrapping/width guards for large amounts and unbroken stock names, a height-bounded account dropdown and a separate amount/action row for carts at narrow widths. These are CSS/source-reviewed layout fixes; a real browser is still unavailable here, so the supplied screenshot case and other viewport sizes require visual confirmation on the user's machine. The 73 non-view PHP application files are unchanged.
