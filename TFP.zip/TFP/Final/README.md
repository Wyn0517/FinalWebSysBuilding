# Counterpoint POS

A CodeIgniter 4.7.5 application for the IT0049 midterm assignment, with one database and separate administrator and cashier experiences. The reference-inspired interface keeps the original Graphite + Cobalt dark theme and Porcelain + Cobalt light theme, with softly frosted surfaces, an expanded or compact icon sidebar, a revenue-led dashboard, image-led checkout and a focused sign-in screen. Space Grotesk handles display text and Inter handles interface text.

**Existing installation:** follow [UI-UPDATE.md](UI-UPDATE.md). Keep `.env` and `writable` and copy the updated application files. This interface revision needs no new migration if the preceding cart release is already installed. Do not recreate your accounts or reset your database.

**Verification:** 33 JavaScript tests and a separate SQLite transaction-strategy experiment passed. PHP lint, the 42 POS-focused PHPUnit tests, actual HTTP flows, MySQL and rendered browser layouts remain unexecuted in this authoring environment. See [docs/VERIFICATION.md](docs/VERIFICATION.md). No hosted deployment or remote CI result is claimed.

## Review the design first

Open **UI-PREVIEW.html** directly in a browser to explore the redesigned dashboard, checkout and login with sample data. Switch themes, collapse the sidebar into its icon rail, try the cart feedback and change chart ranges. This single-file preview embeds the actual view markup, CSS and browser scripts, with static fixture expansion and writes disabled. It does not connect to your database or verify the PHP app. Offline fonts use your system fallback.

## Local setup

Requirements: **64-bit PHP 8.2 or later**, Composer 2, and PHP `intl`, `mbstring`, `fileinfo`, `gd`, `sqlite3`, `dom`, `xml` and `xmlwriter`. GD must decode JPEG, PNG and WebP. SQLite is the default; a separate database server is not required. The archive retains the starter's bundled vendor dependencies; a fresh Git checkout needs `composer install`.

Open a terminal in this project folder, which contains `spark`, `app`, `public` and `composer.json`.

```sh
composer install
cp .env.example .env
php spark migrate --all
php spark pos:admin
php spark serve --host 127.0.0.1 --port 8080
```

On Windows PowerShell with XAMPP, use:

```powershell
cd C:\xampp\htdocs\Final
# Only for a fresh installation without an existing .env:
Copy-Item .env.example .env
& "C:\xampp\php\php.exe" .\spark migrate --all
# Only when you need a new initial administrator:
& "C:\xampp\php\php.exe" .\spark pos:admin
& "C:\xampp\php\php.exe" .\spark serve --host 127.0.0.1 --port 8080
```

At the account prompts, enter only the requested username, full name and password. Passwords need at least 12 characters and no more than 72 bytes. No shared default account is shipped. The account command checks schema readiness before asking for credentials and gives migration guidance if setup is incomplete.

Visit **http://localhost:8080/login**. Keep the server terminal open. `127.0.0.1` binds the development server to the local machine. To stop it, press Ctrl+C. If a Windows background PHP listener remains, the following PowerShell command stops only PHP processes listening on port 8080:

```powershell
Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue |
ForEach-Object { Get-Process -Id $_.OwningProcess } |
Where-Object { $_.ProcessName -eq 'php' } |
Stop-Process
```

For optional sample products and one sample customer:

```sh
php spark db:seed DemoSeeder
```

The seeder creates no staff password or fictitious sale and can be rerun without duplicating its sample records. Local data is stored in `writable/pos.sqlite`. The default reporting timezone is `Asia/Manila`.

## Roles and routes

| Capability | Cashier | Administrator |
| --- | --- | --- |
| Search catalog and record checkout | Yes | Yes |
| View sales history | Own sales | All sales |
| Open grouped receipts | Own receipts | All receipts |
| Edit own name/avatar/password | Yes | Yes |
| Manage inventory and products | No | Yes |
| Manage customers | No | Yes |
| Manage staff, roles and account status | No | Yes |
| Business dashboard and revenue trend | No | Yes |

Administrators land at `/admin/dashboard`; cashiers land at `/pos`. Administrator aliases are `/admin/products`, `/admin/customers`, `/admin/users` and `/admin/sales`. Original `/products`, `/customers` and `/staff` routes remain available with the same administrator filter. `/sales` scopes cashier results on the server. `/profile` always edits the authenticated account and never accepts account IDs, usernames, roles or access flags from submitted fields. Password changes require the current password; blank password edits preserve the hash.

Authentication uses hashed passwords, regenerated login sessions, active-account checks on every protected request, login throttling, POST logout and session-based CSRF protection. Automatic routing is disabled. Staff operations protect the current administrator and ensure at least one active administrator remains. Account roles are rechecked on the server; hidden navigation is not the authorization mechanism.

## Checkout and original assignment sales

The checkout displays active products with images, names, prices and available stock. Search by product name or existing product ID, a clear-search button, the F2 search shortcut and stock filters work with the existing schema; no unsupported category fields are invented. The cart supports adding, typing or stepping quantities, removing items, clearing the order and optional customer selection. A confirmation dialog shows the order before submission. Desktop keeps the cart alongside the product grid; mobile stacks the cart and offers a View order link. The cart stores no credentials or customer data in browser storage.

`CheckoutService` validates an integer-only cart, merges duplicate product IDs, locks products in sorted order through guarded stock updates, reads database prices, calculates totals in integer centavos, and saves the receipt, original assignment sales rows and links in one transaction. Failure at any line rolls everything back. Stock cannot be deducted below zero through the guarded update. A unique request key makes repeated submissions of the same form return one receipt. The checkout allows up to 50 distinct products, 2,147,483,647 total units and PHP 99,999,999.99 per receipt.

The server ignores browser prices, totals and staff IDs. Checkout reloads current prices and stock from the database; the recorded receipt is authoritative. Forms retain up to 20 issued keys for two hours per session. Separate new forms intentionally represent separate sales.

The original `SaleService` and `/sales/new` workflow remain available, including as a JavaScript-free fallback. Each original `sales` row continues to reference one product, optional customer and responsible staff member. Cart receipts link multiple required sale rows without changing their existing columns or relationships. Historical prices and names are snapshots; completed sales have no edit endpoint.

## Database and migrations

1. `2026-10-22-000001_CreatePosTables.php` retains the original assignment tables: products, customers, users and sales, with restrictive foreign keys and archival fields.
2. `2026-10-23-000002_AddReceipts.php` adds only `receipts` and `receipt_lines`. It leaves original tables, accounts, hashes and old sales unchanged.

Products, customers and staff are archived rather than destructively removed. Original names and prices remain readable on past sales. Usernames remain reserved after archival. Unarchived staff accounts can be disabled and reenabled through Edit. Stale inventory forms do not overwrite intervening stock deductions.

Back up existing data before upgrading. Do not use migration reset, refresh, rollback or database deletion on data you want to keep. A fresh starter schema is supported; this is not an importer for some unrelated preexisting POS database.

### MySQL configuration

Use MySQL 8.0.16+ with InnoDB, enable PHP `mysqli`, and create an empty UTF-8 database. Set these values in your private `.env`:

```ini
database.default.DBDriver = MySQLi
database.default.hostname = 127.0.0.1
database.default.port = 3306
database.default.database = counterpoint
database.default.username = your_database_user
database.default.password = 'your_private_database_password'
```

Then run migrations. MySQL 8.0.16+ enforces the CHECK constraints; migrations create InnoDB tables for transactions and row locking. MySQL must be verified on the target server. Changing drivers does not transfer SQLite data to MySQL.

## Dashboard and sales history

The administrator dashboard shows today's recorded revenue, transaction count, unit count, active products, actual daily revenue over selectable 7/14/30-day ranges, recent sale items, customer count and low-stock products. Metrics open meaningful filtered pages; chart days provide exact-date tooltips and links to that day's history. Compact shortcuts open existing create and history routes. A cart counts as one transaction; unlinked original sales count individually. Revenue is summed from actual sale lines, so grouped receipts are not counted twice. Empty periods are explicitly described and no trend percentages are fabricated.

History supports text search, inclusive date ranges, newest/oldest sorting and pagination. Product and history filters expose removable active-filter chips. Cashiers see only their own rows. Cart items link to a shared receipt; old rows remain identifiable without a fabricated receipt. A receipt displays original product, customer and staff names, original prices, quantities, totals and time.

## Uploads and forms

Product and avatar uploads accept matching JPEG, PNG or WebP extensions and detected MIME types, up to 2 MiB, 6000 pixels per dimension and 20 megapixels. CodeIgniter file rules and manual image checks run before GD reencodes a fresh image up to 1200 pixels on its longest side. WebP becomes PNG; JPEG orientation metadata is not retained.

Random filenames are stored under `writable/uploads`, outside the public document root. Authenticated media responses set an explicit image content type and nosniff. SVG placeholders cover absent files. The web user needs write access to writable/uploads, session, cache and logs. Avoid 777 permissions. Enable `file_uploads`, set `upload_max_filesize >= 2M`, `post_max_size >= 4M` and sufficient memory for GD decoding (256M recommended).

Names, emails, phone strings, usernames, money, stock, IDs and quantities are validated on the server; output is escaped. Product prices accept up to two decimal places; stock is a nonnegative integer. Passwords and confirmation fields are never redisplayed through old-input flash data. Phone formats allow common international punctuation; there is no letters-only restriction on personal names.

## Design system

`public/assets/app.css` centralizes the original theme and functional component styles. `public/assets/studio.css` adds the reference-inspired presentation layer: a rounded revenue card, central chart, grouped store summary, recent activity and stock attention; uniform controls and tables; softly frosted surfaces; and responsive layouts. Menu buttons switch between expanded desktop navigation and an accessible icon rail, remembering the choice. The menu scrolls within its own constrained row while the sidebar header and checkout/account footer stay contained. Rail labels render outside the scroll area. Mobile navigation uses a separate modal drawer with focus trapping and background dismissal. Cart changes report visible outcomes, with one persistent screen-reader status channel and a pending checkout label. Major panels use backdrop blur when supported, with solid fallbacks and reduced-transparency support. Dark uses the original background #101114, surface #191B20, text #F4F5F8 and accent #7195FF. Light uses the original background #F4F5F8, white surfaces, text #20232B and accent #4268E8. Interactive states share these tokens, including marked product selections, keyboard focus, active ranges, tooltips, filter chips and brief change feedback.

The shared layout has role-aware sidebar navigation, account/profile controls, theme switching, notices and a native confirmation dialog. On smaller screens the navigation becomes a disclosure: it focuses the first link when opened, closes on outside click, and restores trigger focus when dismissed with Escape or its close button. Theme choice persists using browser local storage; unsaved preferences follow the operating system. An early head script prevents a noticeable wrong-theme flash. Google Fonts loads only 400/500/600/700 weights with swap; system fonts remain usable offline. Icons are one local inline-SVG system. Animations respect reduced-motion preferences.

## Test commands

```sh
# PHP-enabled host
find app tests -name '*.php' -print0 | xargs -0 -n1 php -l
php vendor/bin/phpunit

# Node 18+, no npm install needed
node --check public/assets/app.js
node --check public/assets/cart.js
node --test tests/frontend.test.cjs tests/cart.test.cjs

# Separate SQL strategy experiment through Python, not the PHP app
python3 tests/algorithm_check.py
```

The 42 POS-focused PHPUnit methods comprise 14 original sale tests,15 multi-product checkout tests and 13 role/profile/receipt access tests. They use the isolated tests database group rather than live data. The bundled starter framework tests remain included.

For real HTTP smoke testing, migrate a disposable database, provision a QA administrator, start the PHP server and inject `POS_QA_PASSWORD` privately:

```sh
python3 tests/http_smoke.py --base-url http://localhost:8080 --username your_qa_admin
```

The runner creates staff, inventory, customers and transactions, including archival and password changes. Run only against disposable data. The GitHub workflow installs PHP 8.3 and runs lint, PHPUnit, Node checks and live HTTP smoke tests with a temporary SQLite database and masked generated credentials. No remote workflow run has occurred in this session.

## GitHub and deployment

Commit raw source, migrations, seeders, tests, docs, composer.json, composer.lock, spark, public, writable placeholders, .env.example and .gitignore. Never commit `.env`, live databases, uploads, sessions, logs, credentials or vendor. The downloadable archive includes vendor for convenience; Composer installs it from the lockfile for a Git checkout.

For deployment:

1. Use a PHP 8.2+64-bit host with the required extensions and persistent writable storage. Use a single instance for file sessions/local SQLite; configure MySQL and suitable shared session/upload storage before scaling.
2. Install production dependencies with `composer install --no-dev --optimize-autoloader`. Set the document root to **public/**, never the project root. Use the included Apache rewrite rules or equivalent Nginx routing.
3. Set a private `.env` with `CI_ENVIRONMENT = production`, the HTTPS baseURL with trailing slash, `app.forceGlobalSecureRequests = true`, `cookie.secure = true` and `database.default.DBDebug = false`. Configure persistent writable permissions and your database.
4. Back up data and run `php spark migrate --all`. For initial provisioning only, run `php spark pos:admin`. Deployment-secret injection supports POS_ADMIN_USERNAME, POS_ADMIN_NAME and POS_ADMIN_PASSWORD; remove provisioning secrets afterward. Never pass passwords as shell arguments or commit them.
5. Verify actual login/logout, both roles and direct forbidden URLs, uploads, multi-product sales, rollback, duplicate submission, receipt ownership, old history, date filters, profile changes, both themes and mobile layouts. Confirm database persistence after restarts, HTTPS and private production errors.

The assignment still requires your own GitHub URL and verified hosted URL. Neither is supplied by the archive. `spark serve` is a development server.

## Limits

This student POS records inventory transactions. It does not process payments or provide taxes, discounts, product categories, refunds, voids, receipt printing or a complete stock-adjustment audit trail. Catalog/customer selectors load active records and target a small dataset. Cart drafts are memory-only and reset on ordinary page navigation. A validated draft is redisplayed after checkout errors. PHP, browser and MySQL runtime checks remain required before deployment or submission.
